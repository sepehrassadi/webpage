run(ID0, ID1,FileName):-
     myretractall,
     get_time(TT),
     assert(filename(FileName)),
     assert(start_time(TT)),
     assert(start(1)),
     X is random(2),

     write1(ID0),write1(' '),write1(ID1),write1(' '),write1(X),write1('\n'),

     assert(turn(X)),
     assert(id0(ID0)),
     assert(id1(ID1)),
     D1 is random(6)+1,
     D2 is random(6)+1,
     writeDice(D1,D2),
     get_time(T),
     assert(prev(T)),
     (
        (X==0,!, move(ID0, [],D1,D2),!);
        (X==1,!, move(ID1, [],D1,D2),!)
     ).

myretractall:-
     retractall(prev(_)),
     retractall(turn(_)),
     retractall(id1(_)),
     retractall(id0(_)),
     retractall(start_time(_)),
     retractall(start(_)),
     retractall(filename(_)).

checkTime(T2, T1):-
   T3 is T2-T1,
   (
      (T3>=5.01,turn(X),((X==0,!,id0(ID)); (X==1,!,id1(ID))),write1(ID), write1(' is loser'),write1('\n'),fail);
      T3 < 5.01
   ).

checkWinner(Winner):-
   (
      (Winner==1,!,turn(X),((X==0,!,id0(ID)); (X==1,!,id1(ID))),write1(ID), write1(' is winner'),write1('\n'),fail);
      Winner==0
   ).

writeDice(D1,D2):-
     write1(D1),
     write1(' '),
     write1(D2),
     write1(' '),
     start_time(T0),
     get_time(T),
     DeltaT is T-T0,
     write1(DeltaT),
     write1('\n').

done(L,Winner):-
    get_time(T2),
    prev(T1),
    checkTime(T2, T1),
    retract(prev(_)),
    mywrite0(L),
    checkWinner(Winner),
    turn(X),
    retract(turn(_)),
    Y is 1-X,
    assert(turn(Y)),
    get_time(T),
    assert(prev(T)),
    D1 is random(6)+1,
    D2 is random(6)+1,
    writeDice(D1,D2),
    (
       (Y==0,!,id0(ID), move(ID, L,D1,D2),!);
       (Y==1,!,id1(ID), move(ID, L,D1,D2),!)
    ).

write1(X):-
     filename(FileName),
     start(Y),
     (
        (Y==1,!,tell(FileName),retractall(start(_)),assert(start(0)));
        (Y==0,!,append(FileName))
     ),
     write(X),
     told.

mywrite0([]):-
     !,
     write1('30\n').
mywrite0(L):-
     mywrite(L).

mywrite([Head|Tail]):-
     write1(Head),
     write1(' '),
     mywrite(Tail).
mywrite([]):-
     write1('\n').

% D1 and D2 are the dices.
%move(X,Y,D1,D2):-(start_time(TT),get_time(T1),DeltaT is T1-TT,DeltaT>1.5,write(DeltaT),!,done([3,6,3],0));move(X,Y,D1,D2).

%move(X,Y,D1,D2):-done([1,5,4,2,3,1],0).


% ---------------- First Team -------------------------
% tools
% max:
my_max_87100515(X,Y,Y):- Y > X , !.
my_max_87100515(X,Y,X).
% min:
my_min_87100515(X,Y,Y):- Y < X , !.
my_min_87100515(X,Y,X).
% member:
my_member_87100515(X,[X|_]).
my_member_87100515(X,[Y|Tail]):- my_member_87100515(X,Tail).
% furthest piece
furthest_piece_87100515(Board,Num):- furthest_piece_87100515(Board,Num,0).
furthest_piece_87100515([X|Board],Num,Num):- X>0,!.
furthest_piece_87100515([X|Board],Num,I):- NewI is I + 1 , furthest_piece_87100515(Board,Num,NewI).
% don't have piece
dont_have_piece_87100515(_,0):-!.
dont_have_piece_87100515([0|Board],Range):- NewRange is Range-1 , dont_have_piece_87100515(Board,NewRange).
% append to all
append_to_all_87100515(_,[],[]):-!.
append_to_all_87100515(Move,[X|List],[New|Ans]):- append(Move,X,New) , append_to_all_87100515(Move,List,Ans).

:-dynamic board_87100515/1.
:-dynamic en_board_87100515/1.

middle_my_board_87100515([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,5,0]).
middle_en_board_87100515([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,15]).
%move(1,[],6,3).
init_board_87100515([0,2,0,0,0,0,0,0,0,0,0,0,5,0,0,0,0,3,0,5,0,0,0,0,0,0]).

board_87100515(   [0,2,0,0,0,0,0,0,0,0,0,0,5,0,0,0,0,3,0,5,0,0,0,0,0,0]).
en_board_87100515([0,0,0,0,0,0,5,0,3,0,0,0,0,5,0,0,0,0,0,0,0,0,0,0,2,0]).
% related to game
is_winner_87100515(Board,1):- have_all_out_87100515(Board),!.
is_winner_87100515(Board,0).

% related to piece:
have_piece_87100515(X,Board) :- nth0(X,Board,Num) , Num > 0.
have_one_piece_87100515(X,Board):- nth0(X,Board,1).
have_strong_piece_87100515(X,Board):- nth0(X,Board,Num) , Num > 1.

have_bigger_out_87100515(18,Board):-!.
have_bigger_out_87100515(X,Board):-Y is X-1 , nth0(X,Board,0),have_bigger_out_87100515(Y,Board).
% related to Board
have_up_piece_87100515([X|Board]):- X > 0 .
have_all_in_home_87100515([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,_,_,_,_,_,_,_]).
have_all_out_87100515(Board):- nth0(25,Board,15).
have_unsafe_piece_87100515(Board):- nth0(X,Board,1).
have_unsafe_piece_in_home_87100515(Board):- nth0(X,Board,1),is_in_my_home_87100515(X).
number_of_strong_point_87100515(Board,Len):- findall(X,have_strong_piece_87100515(X,Board),List) , length(List,Len).

% related to positions
is_in_my_home_87100515(X):- X > 18 , X < 25.
is_in_my_near_mid_87100515(X):- X > 12 , X < 19.
is_in_my_far_mid_87100515(X) :- X > 6  , X < 13.
is_in_my_en_home_87100515(X):- X > 0 , X < 7 .

% related to moves
is_attack_87100515([X,Y,Dice],MyBoard,EnBoard):- have_one_piece_87100515(Y,EnBoard).
is_attack_move_87100515([Moves|List],MyBoard,EnBoard):- is_attack_87100515(Moves,MyBoard,EnBoard),!.
is_attack_move_87100515([Temp|List],MyBoard,EnBoard):- is_attack_move_87100515(List,MyBoard,EnBoard).

is_safe_move_87100515(Move,MyBoard,EnBoard):- update_all_my_moves_87100515(Move,MyBoard,M1,EnBoard,E1), not(have_unsafe_piece_87100515(M1)).
is_safe_move_in_home_87100515(Move,MyBoard,EnBoard):- update_all_my_moves_87100515(Move,MyBoard,M1,EnBoard,E1),not(have_unsafe_piece_in_home_87100515(M1)).
number_of_strong_point_move_87100515(Move,MyBoard,EnBoard,Num):- update_all_my_moves_87100515(Move ,MyBoard,M1,EnBoard,E1) ,number_of_strong_point_87100515(M1,Num).
number_of_attacked_move_87100515(Move,MyBoard,EnBoard,Num):- update_all_my_moves_87100515(Move,MyBoard,M1,EnBoard,E1) , nth0(25,E1,Num).
is_dest_unsafe_87100515([X,Y,Dice],MyBoard,EnBoard):- nth0(Y,MyBoard,0).
is_src_unsafe_87100515([X,Y,Dice],MyBoard,EnBoard):- nth0(X,MyBoard,2).
make_dest_safe_87100515([X,Y,Dice],MyBoard,EnBoard):- have_one_piece_87100515(Y,MyBoard).

% related to up pieces they should be puted out before.
put_pieces_from_bar_87100515(MyBoard,EnBoard,Dice,Dice,[Move,NewDiceList],[]):- ! ,put_pieces_from_bar_87100515(MyBoard,EnBoard,[Dice,Dice,Dice,Dice],Move,NewDiceList).
put_pieces_from_bar_87100515(MyBoard,EnBoard,Dice1,Dice2,[Move1,DiceList1],[Move2,DiceList2]):- nth0(0,MyBoard,1) ,!, put_pieces_from_bar_87100515(MyBoard,EnBoard,[Dice1,Dice2],Move1,DiceList1) % when there is just one order is important.
                                                                                        ,put_pieces_from_bar_87100515(MyBoard,EnBoard,[Dice2,Dice1],Move2,DiceList2).
put_pieces_from_bar_87100515(MyBoard,EnBoard,Dice1,Dice2,[Move1,DiceList1],[]):-put_pieces_from_bar_87100515(MyBoard,EnBoard,[Dice1,Dice2],Move1,DiceList1).

% put them on table from bar.
put_pieces_from_bar_87100515(_,_,[],[],[]):-!.
put_pieces_from_bar_87100515(MyBoard,EnBoard,[Dice|DiceList],[Move|MoveList],NewDiceList):- put_one_piece_87100515(MyBoard,EnBoard,Dice,Move) ,!,update_my_move_87100515(Move,MyBoard,M1,EnBoard,E1) ,  put_pieces_from_bar_87100515(M1,E1,DiceList,MoveList,NewDiceList).
put_pieces_from_bar_87100515(MyBoard,EnBoard,[Dice|DiceList],MoveList,[Dice|NewDiceList]):- put_pieces_from_bar_87100515(MyBoard,EnBoard,DiceList,MoveList,NewDiceList).
put_one_piece_87100515(MyBoard,EnBoard,Dice,[0,Dice,Dice]):- can_go_piece_87100515(0,Dice,MyBoard,EnBoard).
% related to moves with one dice.
can_move_piece_87100515(X,D1,MyBoard,EnBoard):- have_piece_87100515(X,MyBoard), Y is X+D1 ,  not(have_piece_87100515(Y,EnBoard)).                 % can move.
can_attack_piece_87100515(X,D1,MyBoard,EnBoard):- have_piece_87100515(X,MyBoard) , Y is X+D1, have_one_piece_87100515(Y,EnBoard).                 % can attack.
can_pick_piece_87100515(X,D1,MyBoard,EnBoard):- X is 25-D1 , ! , have_piece_87100515(X,MyBoard) , not(have_up_piece_87100515(MyBoard)) , have_all_in_home_87100515(MyBoard).               % can be picked normally.
can_pick_piece_87100515(X,D1,MyBoard,EnBoard):- have_piece_87100515(X,MyBoard) , Z is X - 1 ,   have_bigger_out_87100515(Z,MyBoard) , not(have_up_piece_87100515(MyBoard)) , have_all_in_home_87100515(MyBoard).   % can be picked via larger dice.

% No piece can be played out of the board.
can_go_piece_87100515(25,D1,MyBoard,EnBoard):- ! , fail.
% A piece that can be moved out only if all the others piece are in home.
can_go_piece_87100515(X,D1,MyBoard,EnBoard):- Y is X + D1 , Y > 24 , ! , can_pick_piece_87100515(X,D1,MyBoard,EnBoard).
% A usual piece can only played when there is no up piece. ( This is check completely before hand)
can_go_piece_87100515(X,D1,MyBoard,EnBoard):- can_attack_piece_87100515(X,D1,MyBoard,EnBoard) , ! ; can_move_piece_87100515(X,D1,MyBoard,EnBoard), ! .
% related to moves with two dice.
%------------------------------
% First and Second can be played with D1 and D2 , respectively.
can_move_two_dice_without_order_87100515(First,Second,D1,D2,MyBoard,EnBoard):- can_go_piece_87100515(First,D1,MyBoard,EnBoard) ,  Y is First+D1 , update_my_move_87100515([First,Y,D1],MyBoard,MyBoard1,EnBoard,EnBoard1),can_go_piece_87100515(Second,D2,MyBoard1,EnBoard1),!.
% First can be played with D1 and D2 in straight.
can_move_straight_two_dice_87100515(First,D1,D2,MyBoard,EnBoard):- can_go_piece_87100515(First,D1,MyBoard,EnBoard) , Y is First+D1 ,update_my_move_87100515([First,Y,D1],MyBoard,MyBoard1,EnBoard,EnBoard1) , can_go_piece_87100515(Y,D2,MyBoard1,EnBoard1).
%------------------------------
can_move_double_dice_87100515(First,Second,Third,Fourth,Dice,MyBoard,EnBoard):- can_go_piece_87100515(First,Dice,MyBoard,EnBoard) ,Y1 is First+Dice , update_my_move_87100515([First,Y1,Dice],MyBoard,MyBoard1,EnBoard,EnBoard1), can_go_piece_87100515(Second,Dice,MyBoard1,EnBoard1),Y2 is Second + Dice , update_my_move_87100515([Second,Y2,Dice],MyBoard1,MyBoard2,EnBoard1,EnBoard2),can_go_piece_87100515(Third,Dice,MyBoard2,EnBoard2),Y3 is Third + Dice , update_my_move_87100515([Third,Y3,Dice],MyBoard2,MyBoard3,EnBoard2,EnBoard3), can_go_piece_87100515(Fourth,Dice,MyBoard3,EnBoard3).
can_move_double_dice_87100515(First,Second,Third,Dice,MyBoard,EnBoard):- can_go_piece_87100515(First,Dice,MyBoard,EnBoard) ,Y1 is First+Dice , update_my_move_87100515([First,Y1,Dice],MyBoard,MyBoard1,EnBoard,EnBoard1), can_go_piece_87100515(Second,Dice,MyBoard1,EnBoard1),Y2 is Second + Dice , update_my_move_87100515([Second,Y2,Dice],MyBoard1,MyBoard2,EnBoard1,EnBoard2),can_go_piece_87100515(Third,Dice,MyBoard2,EnBoard2).
% Just when you have double dice.
% ----------------
% Is it possible to play these four dice accordingly.
can_move_four_dice_87100515(First,Second,Third,Fourth,Dice,MyBoard,EnBoard,[[First,Y1,Dice],[Second,Y2,Dice],[Third,Y3,Dice],[Fourth,Y4,Dice]]):- Y1 is First + Dice, Y2 is Second + Dice , Y3 is Third + Dice , Y4 is Fourth + Dice , can_move_double_dice_87100515(First,Second,Third,Fourth,Dice,MyBoard,EnBoard).
% Is it possible to play these three dice accordingly.
can_move_three_dice_87100515(First,Second,Third,Dice,MyBoard,EnBoard,[[First,Y1,Dice],[Second,Y2,Dice],[Third,Y3,Dice]]):- Y1 is First + Dice, Y2 is Second + Dice , Y3 is Third + Dice , can_move_double_dice_87100515(First,Second,Third,Dice,MyBoard,EnBoard).
% ----------------
% Is it possible to play these two Dice accordingly.
can_move_two_dice_87100515(First,Second,D1,D2,MyBoard,EnBoard, [[First,Second,D1],[Second,Z,D2]]):- Second is First + D1 , Z is Second + D2 , can_move_straight_two_dice_87100515(First,D1,D2,MyBoard,EnBoard).
can_move_two_dice_87100515(First,Second,D1,D2,MyBoard,EnBoard, [[First,Second,D2],[Second,Z,D1]]):- Second is First + D2 , Z is Second + D1 , can_move_straight_two_dice_87100515(First,D2,D1,MyBoard,EnBoard).
can_move_two_dice_87100515(First,Second,D1,D2,MyBoard,EnBoard,[[First,Y,D1],[Second,Z,D2]]):- Y is First + D1 , Z is Second + D2 , can_move_two_dice_without_order_87100515(First,Second,D1,D2,MyBoard,EnBoard).

% Is it possible to playe this Dice.
can_move_one_dice_87100515(First,Dice,MyBoard,EnBoard,[[First,Y,Dice]]):- Y is First+Dice , can_go_piece_87100515(First,Dice,MyBoard,EnBoard).
can_move_one_dice2_87100515(First,Dice,MyBoard,EnBoard,[First,Y,Dice]):- Y is First+Dice , can_go_piece_87100515(First,Dice,MyBoard,EnBoard).
% All the possible moves.
% Moves with double dices _87100515( an N^4 Loop over all pieces. )

all_four_dice_moves_87100515(MyBoard,EnBoard,Dice,List):- all_four_dice_moves1_87100515(MyBoard,EnBoard,Dice,[],List,1).
all_four_dice_moves1_87100515(_,_,_,CL,CL,26):-!.
all_four_dice_moves1_87100515(MyBoard,EnBoard,Dice,CL,List,I):- can_move_one_dice2_87100515(I,Dice,MyBoard,EnBoard,Move)
                                                    ,!
                                                    ,update_my_move_87100515(Move,MyBoard,NMyBoard,EnBoard,NEnBoard)
                                                    ,all_four_dice_moves2_87100515(NMyBoard,NEnBoard,Dice,[Move],CL,List2,I,I)
                                                    ,NI is I+1
                                                    ,all_four_dice_moves1_87100515(MyBoard,EnBoard,Dice,List2,List,NI).
all_four_dice_moves1_87100515(MyBoard,EnBoard,Dice,CL,List,I):- NI is I+1
                                                    ,all_four_dice_moves1_87100515(MyBoard,EnBoard,Dice,CL,List,NI).
all_four_dice_moves2_87100515(MyBoard,EnBoard,Dice,_,CL,CL,I,26):- ! , true.
all_four_dice_moves2_87100515(MyBoard,EnBoard,Dice,Moves,CL,List,I,J):- can_move_one_dice2_87100515(J,Dice,MyBoard,EnBoard,Move)
                                                            ,!
                                                            ,update_my_move_87100515(Move,MyBoard,NMyBoard,EnBoard,NEnBoard)
                                                            ,all_four_dice_moves3_87100515(NMyBoard,NEnBoard,Dice,[Move|Moves],CL,List2,I,J,J)
                                                            ,NJ is J+1
                                                            , all_four_dice_moves2_87100515(MyBoard,EnBoard,Dice,Moves,List2,List,I,NJ).
all_four_dice_moves2_87100515(MyBoard,EnBoard,Dice,Moves,CL,List,I,J):- NJ is J+1
                                                            , all_four_dice_moves2_87100515(MyBoard,EnBoard,Dice,Moves,CL,List,I,NJ).
all_four_dice_moves3_87100515(MyBoard,EnBoard,Dice,_,CL,CL,_,I,26):- ! , true.
all_four_dice_moves3_87100515(MyBoard,EnBoard,Dice,Moves,CL,List,I,J,K):- can_move_one_dice2_87100515(K,Dice,MyBoard,EnBoard,Move)
                                                              ,!
                                                              ,update_my_move_87100515(Move,MyBoard,NMyBoard,EnBoard,NEnBoard)
                                                              ,all_four_dice_moves4_87100515(NMyBoard,NEnBoard,Dice,[Move|Moves],CL,List1,I,J,K,K)
                                                              , NK is K+1
                                                              , all_four_dice_moves3_87100515(MyBoard,EnBoard,Dice,Moves,List1,List2,I,J,NK)
                                                              ,List = [[Move|Moves]|List2].
all_four_dice_moves3_87100515(MyBoard,EnBoard,Dice,Moves,CL,List,I,J,K):- NK is K+1
                                                              , all_four_dice_moves3_87100515(MyBoard,EnBoard,Dice,Moves,CL,List,I,J,NK).
all_four_dice_moves4_87100515(MyBoard,EnBoard,Dice,_,CL,CL,I,J,K,26):- !,true.
all_four_dice_moves4_87100515(MyBoard,EnBoard,Dice,Moves,CL,List,I,J,K,L):- can_move_one_dice2_87100515(L,Dice,MyBoard,EnBoard,Move),  ! , NewL is L + 1
                                                                ,  all_four_dice_moves4_87100515(MyBoard,EnBoard,Dice,Moves,CL,List2,I,J,K,NewL)
                                                                , List = [[Move|Moves]|List2].
all_four_dice_moves4_87100515(MyBoard,EnBoard,Dice,Moves,CL,List,I,J,K,L):- NewL is L + 1, all_four_dice_moves4_87100515(MyBoard,EnBoard,Dice,Moves,CL,List,I,J,K,NewL).

% Moves with both two dice _87100515( an N^2 Loop over all pieces. )
%all_two_dice_moves_87100515(MyBoard,EnBoard,D1,D2,List):- !,L = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25] , setof(Moves,(my_member_87100515(X,L),my_member_87100515(Y,L),can_move_two_dice_87100515(X,Y,D1,D2,MyBoard,EnBoard,Moves)),List).
all_two_dice_moves_87100515(MyBoard,EnBoard,D1,D2,List):- all_two_dice_moves_87100515(MyBoard,EnBoard,D1,D2,[],TempList,1,1),sort(TempList,List).
all_two_dice_moves_87100515(_,_,_,_,[],_,26,_):-! , fail. % we fail it for further use in one dice mode.
all_two_dice_moves_87100515(_,_,_,_,CurrentList,CurrentList,26,_):-!.
all_two_dice_moves_87100515(MyBoard,EnBoard,D1,D2,CurrentList,List,Iiterator,_):- NewI is Iiterator + 1
                                                                           ,have_piece_87100515(Iiterator,MyBoard),!
                                                                           ,L = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25]
                                                                           ,findall(Moves,(my_member_87100515(Y,L),can_move_two_dice_87100515(Iiterator,Y,D1,D2,MyBoard,EnBoard,Moves)),TempList)
                                                                           ,append(TempList,CurrentList,NewList)
                                                                           ,all_two_dice_moves_87100515(MyBoard,EnBoard,D1,D2,NewList,List,NewI,1).
all_two_dice_moves_87100515(MyBoard,EnBoard,D1,D2,CurrentList,List,Iiterator,_):- NewI is Iiterator + 1 ,all_two_dice_moves_87100515(MyBoard,EnBoard,D1,D2,CurrentList,List,NewI,1).
/*all_two_dice_moves_87100515(MyBoard,EnBoard,D1,D2,CurrentList,List,Iiterator,26):- !, NewI is Iiterator + 1  ,all_two_dice_moves_87100515(MyBoard,EnBoard,D1,D2,CurrentList,List,NewI,1).
all_two_dice_moves_87100515(MyBoard,EnBoard,D1,D2,CurrentList,List,Iiterator,Jiterator):- can_move_two_dice_87100515(Jiterator,Iiterator,D1,D2,MyBoard,EnBoard,Moves),!, NewJ is Jiterator + 1 , all_two_dice_moves_87100515(MyBoard,EnBoard,D1,D2,[Moves|CurrentList],List,Iiterator,NewJ).
all_two_dice_moves_87100515(MyBoard,EnBoard,D1,D2,CurrentList,List,Iiterator,Jiterator):- NewJ is Jiterator + 1 , all_two_dice_moves_87100515(MyBoard,EnBoard,D1,D2,CurrentList,List,Iiterator,NewJ).
*/% Moves with just one dice _87100515( an N Loop over all pieces. )
all_one_dice_moves_87100515(MyBoard,EnBoard,Dice,List):- all_one_dice_moves_87100515(MyBoard,EnBoard,Dice,[],List,1).
all_one_dice_moves_87100515(_,_,_,[],_,26):- ! , fail. % we fail it for further use in possible moves.
all_one_dice_moves_87100515(MyBoard,EnBoard,Dice,List,List,26):- !.
all_one_dice_moves_87100515(MyBoard,EnBoard,Dice,CurrentList,List,Iterator):- can_move_one_dice_87100515(Iterator,Dice,MyBoard,EnBoard,Moves) , ! , NextIter is Iterator + 1 ,all_one_dice_moves_87100515(MyBoard,EnBoard,Dice,[Moves|CurrentList],List,NextIter).
all_one_dice_moves_87100515(MyBoard,EnBoard,Dice,CurrentList,List,Iterator):- NextIter is Iterator + 1 ,all_one_dice_moves_87100515(MyBoard,EnBoard,Dice,CurrentList,List,NextIter).

% change N element in List1 to Y in List2.
change_list_87100515(Y,[X|List1],[Y|List1],0):-!.
change_list_87100515(Y,[X|List1],[X|List2],N):- M is N-1, change_list_87100515(Y,List1,List2,M).

% inc Nth element of List1.
inc_list_87100515([X|List1],[Y|List1],0):- Y is X+1,!.
inc_list_87100515([X|List1],[X|List2],N):- M is N-1, inc_list_87100515(List1,List2,M).

% dec Nth element of List1.
dec_list_87100515([X|List1],[Y|List1],0):- Y is X-1,!.
dec_list_87100515([X|List1],[X|List2],N):- M is N-1, dec_list_87100515(List1,List2,M).
% standardize the moves.
standard_move_87100515([X,Y,Dice],[X,25,Dice]):- Y > 25 , !.
standard_move_87100515(X,X).

standard_all_moves_87100515([],[]).
standard_all_moves_87100515([Move|List],[SMove|List2]):- standard_move_87100515(Move,SMove) , standard_all_moves_87100515(List,List2).

standard_list_of_all_moves_87100515([],[]).
standard_list_of_all_moves_87100515([Move|List],[SMove|List2]):- standard_all_moves_87100515(Move,SMove) , standard_list_of_all_moves_87100515(List,List2).

% update my moves to board.
update_my_move_87100515([],MyBoard,MyBoard,EnBoard,EnBoard).% doesn't need any change.
update_my_move_87100515([X,Y,Dice],MyBoard1,MyBoard2,EnBoard1,EnBoard2):- Y > 25 , ! , update_my_move_87100515([X,25,Dice],MyBoard1,MyBoard2,EnBoard1,EnBoard2).
update_my_move_87100515([X,Y,Dice],MyBoard1,MyBoard3,EnBoard1,EnBoard2):- dec_list_87100515(MyBoard1,S1,X) , inc_list_87100515(S1,MyBoard2,Y) , update_en_my_move_87100515([X,Y,Dice],MyBoard2,MyBoard3,EnBoard1,EnBoard2).
% update enemy moves based on mine.
update_en_my_move_87100515([X,0,Dice],MyBoard,MyBoard,EnBoard,EnBoard):-!. % going to zero doesn't affect enemy.
update_en_my_move_87100515([X,25,Dice],MyBoard,MyBoard,EnBoard,EnBoard):-!. % going to 25 doesn't affect enemy.
update_en_my_move_87100515([X,OldY,Dice],MyBoard1,MyBoard2,EnBoard1,EnBoard2):-  Y is 25-OldY , have_one_piece_87100515(OldY,EnBoard1),!,update_en_move_87100515([Y,0,Dice],MyBoard1,MyBoard2,EnBoard1,EnBoard2). % if I attack enemy, he should go to its 0 cell.
update_en_my_move_87100515([X,Y,Dice],MyBoard,MyBoard,EnBoard,EnBoard).


update_all_my_moves_87100515([],MyBoard,MyBoard,EnBoard,EnBoard).
update_all_my_moves_87100515([H|T],MyBoard1,MyBoard2,EnBoard1,EnBoard2):- update_my_move_87100515(H,MyBoard1,NewMyBoard,EnBoard1,NewEnBoard) , update_all_my_moves_87100515(T,NewMyBoard,MyBoard2,NewEnBoard,EnBoard2).

% update enemy moves to board.
update_en_move_87100515([],MyBoard,MyBoard,EnBoard,EnBoard).
update_en_move_87100515([OldX,OldY,Dice],MyBoard1,MyBoard2,EnBoard1,EnBoard3):- X is 25-OldX , Y is 25 - OldY ,dec_list_87100515(EnBoard1,S1,X) , inc_list_87100515(S1,EnBoard2,Y) , update_my_en_move_87100515([X,Y,Dice],MyBoard1,MyBoard2,EnBoard2,EnBoard3).
% update my moves based on enemy's.
update_my_en_move_87100515([X,0,Dice],MyBoard,MyBoard,EnBoard,EnBoard):-!. % going to zero doesn't affect enemy.
update_my_en_move_87100515([X,25,Dice],MyBoard,MyBoard,EnBoard,EnBoard):-!. % going to 25 doesn't affect enemy.
update_my_en_move_87100515([X,Y,Dice],MyBoard1,MyBoard2,EnBoard1,EnBoard2):- have_one_piece_87100515(Y,MyBoard1) ,!, update_my_move_87100515([Y,0,Dice],MyBoard1,MyBoard2,EnBoard1,EnBoard2).  % if enemy attack me , I should go to my 0 cell.
update_my_en_move_87100515([X,Y,Dice],MyBoard,MyBoard,EnBoard,EnBoard).

update_all_en_moves_87100515([],MyBoard,MyBoard,EnBoard,EnBoard).
update_all_en_moves_87100515([H|T],MyBoard1,MyBoard2,EnBoard1,EnBoard2):-update_en_move_87100515(H,MyBoard1,NewMyBoard,EnBoard1,NewEnBoard) ,update_all_en_moves_87100515(T,NewMyBoard,MyBoard2,NewEnBoard,EnBoard2).

% initial each step.
init_step_87100515(Moves,MyBoard,EnBoard):- retract(en_board_87100515(FirstEnBoard)),retract(board_87100515(FirstMyBoard)),update_all_en_moves_87100515(Moves,FirstMyBoard,MyBoard,FirstEnBoard,EnBoard)
                                   ,heruistic_changer_87100515(MyBoard,EnBoard).
% end all step.
end_step_87100515(Moves,MyBoard,EnBoard):- update_all_my_moves_87100515(Moves,MyBoard,NewMyBoard,EnBoard,NewEnBoard) , assert(board_87100515(NewMyBoard)) , assert(en_board_87100515(NewEnBoard)).

:- dynamic started_87100515/1.
started_87100515(false).

% start
start_87100515:- started_87100515(false),!,retractall(started_87100515(_)) , assert(started_87100515(true)),retractall(board_87100515(_)) , retractall(en_board_87100515(_)), retractall(all_of_dice_87100515(_)) , init_board_87100515(X) , reverse(X,Y), asserta(board_87100515(X)) , asserta(en_board_87100515(Y)) , create_dice_list_87100515(List) , assert(all_of_dice_87100515(List)).
start_87100515:- started_87100515(true).
% test
test_1:- retractall(board_87100515(_)) , retractall(en_board_87100515(_)), retractall(all_of_dice_87100515(_)) , middle_my_board_87100515(X) ,middle_en_board_87100515(Y), asserta(board_87100515(X)) , asserta(en_board_87100515(Y)) , create_dice_list_87100515(List) , assert(all_of_dice_87100515(List)).

% find all possible actions of the game.
list_of_possible_actions_87100515(0,Board,EnBoard,Dice1,Dice2,List):- list_of_possible_actions_87100515(Board,EnBoard,Dice1,Dice2,List).
list_of_possible_actions_87100515(1,Board,EnBoard,Dice1,Dice2,List):- reverse(EnBoard,NEnBoard),reverse(Board,NBoard),list_of_possible_actions_87100515(NEnBoard,NBoard,Dice1,Dice2,List).
list_of_possible_actions_87100515(MyBoard,EnBoard,Dice1,Dice2,List):- have_up_piece_87100515(MyBoard) ,!,put_pieces_from_bar_87100515(MyBoard,EnBoard,Dice1,Dice2,InfoList1,InfoList2),handle_bar_and_board_87100515(MyBoard,EnBoard,InfoList1,InfoList2,TempList),standard_list_of_all_moves_87100515(TempList,List).
list_of_possible_actions_87100515(MyBoard,EnBoard,Dice1,Dice2,List):- list_of_in_board_possible_actions_87100515(MyBoard,EnBoard,Dice1,Dice2,List).

% all the pieces except the ones in bar
list_of_in_board_possible_actions_87100515(MyBoard,EnBoard,Dice1,Dice2,List):- get_list_of_possible_actions_87100515(MyBoard,EnBoard,Dice1,Dice2,TempList),standard_list_of_all_moves_87100515(TempList,List).
% handle pieces after playing the bars.
handle_bar_and_board_87100515(MyBoard,EnBoard,[],[],[]):-!.
handle_bar_and_board_87100515(MyBoard,EnBoard,[Move,Dice],[],List):-!,update_all_my_moves_87100515(Move,MyBoard,M1,EnBoard,E1),handle_bar_and_board_2_87100515(M1,E1,Move,Dice,List).
handle_bar_and_board_87100515(MyBoard,EnBoard,[Move1,Dice1],[Move2,Dice2],List):-!,update_all_my_moves_87100515(Move1,MyBoard,M1,EnBoard,E1) , handle_bar_and_board_2_87100515(M1,E1,Move1,Dice1,List1),update_all_my_moves_87100515(Move2,MyBoard,M2,EnBoard,E2) , handle_bar_and_board_2_87100515(M2,E2,Move2,Dice2,List2) , append(List1,List2,List).

handle_bar_and_board_2_87100515(MyBoard,EnBoard,List,DiceList,[List]):- have_up_piece_87100515(MyBoard),!.  % still there are some piece on bar.
handle_bar_and_board_2_87100515(MyBoard,EnBoard,MoveList,DiceList,List):- find_with_dice_87100515(MyBoard,EnBoard,DiceList,TempList) , append_to_all_87100515(MoveList,TempList,List).
% find answer with dice
find_with_dice_87100515(MyBoard,EnBoard,[Dice],List):-all_one_dice_moves_87100515(MyBoard,EnBoard,Dice,List),!.
find_with_dice_87100515(MyBoard,EnBoard,[Dice,Dice],List):- all_two_dice_moves_87100515(MyBoard,EnBoard,Dice,Dice,List) ,!.
find_with_dice_87100515(MyBoard,EnBoard,[Dice,Dice],List):- all_one_dice_moves_87100515(MyBoard,EnBoard,Dice,List) , ! .
find_with_dice_87100515(MyBoard,EnBoard,[Dice1,Dice2],List):- list_of_in_board_possible_actions_87100515(MyBoard,EnBoard,Dice1,Dice2,List),!.
find_with_dice_87100515(MyBoard,EnBoard,[Dice,Dice,Dice],List):-all_four_dice_moves_87100515(MyBoard,EnBoard,Dice,List1) ,setof(X,(my_member_87100515(X,List1),length(X,3)),List),!.
find_with_dice_87100515(MyBoard,EnBoard,[Dice,Dice,Dice],List):- all_two_dice_moves_87100515(MyBoard,EnBoard,Dice,Dice,List) ,!.
find_with_dice_87100515(MyBoard,EnBoard,[Dice,Dice,Dice],List):- all_one_dice_moves_87100515(MyBoard,EnBoard,Dice,List) , ! .
find_with_dice_87100515(_,_,_,[[]]).

% list of possible board actions ( without any bar ).
get_list_of_possible_actions_87100515(MyBoard,EnBoard,Dice,Dice,List):- all_four_dice_moves_87100515(MyBoard,EnBoard,Dice,List1) , fillter_three_or_four_87100515(List1,List3,List4), three_or_four_87100515(List3,List4,List), !.
get_list_of_possible_actions_87100515(MyBoard,EnBoard,Dice1,Dice2,List):- all_two_dice_moves_87100515(MyBoard,EnBoard,Dice1,Dice2,List) , !.
get_list_of_possible_actions_87100515(MyBoard,EnBoard,Dice1,Dice2,List):- my_max_87100515(Dice1,Dice2,Dice) , all_one_dice_moves_87100515(MyBoard,EnBoard,Dice,List) , !.
get_list_of_possible_actions_87100515(MyBoard,EnBoard,Dice1,Dice2,List):- my_min_87100515(Dice1,Dice2,Dice) , all_one_dice_moves_87100515(MyBoard,EnBoard,Dice,List) , !.
get_list_of_possible_actions_87100515(MyBoard,EnBoard,Dice1,Dice2,[]).

fillter_three_or_four_87100515([],[],[]).
fillter_three_or_four_87100515([H|List],List3,List4):- length(H,4),!,fillter_four_87100515(List,List4p),List4=[H|List4p],List3=[].
fillter_three_or_four_87100515([H|List],List3,List4):- length(H,3),!,fillter_three_or_four_87100515(List,List3p,List4),List3=[H|List3p].
fillter_four_87100515([],[]).
fillter_four_87100515([H|List],List4):-length(H,4),!,fillter_four_87100515(List,List1),List4=[H|List1].
fillter_four_87100515([H|List],List4):-fillter_four_87100515(List,List4).
three_or_four_87100515(_,List4,List2):- not(List4==[]),!,List2=List4.
three_or_four_87100515(List3,[],List2):- not(List3==[]),!,List2=List3.

% tools for heruistics:
list_of_strong_actions_87100515(MyBoard,EnBoard,[],[]).
list_of_strong_actions_87100515(MyBoard,EnBoard,[Move|MoveList],[X/Move|List]):- number_of_strong_point_move_87100515(Move,MyBoard,EnBoard,X) ,list_of_strong_actions_87100515(MyBoard,EnBoard,MoveList,List).
% strategy and playing part.

play_87100515(MyBoard,EnBoard,Dice1,Dice2,Moves):-list_of_possible_actions_87100515(MyBoard,EnBoard,Dice1,Dice2,List)
                                           ,sort_move_87100515(MyBoard,EnBoard,2,List,Moves).


% Move =>
move(87100515,RuleMoves,Dice1,Dice2):- %stmv(RuleMoves1,RuleMoves)
                              %   writeln('team 87100515: ')
                        %        ,get_time(T1)
                                start_87100515
                                ,standard_to_mine_87100515(RuleMoves,Moves)
                                ,init_step_87100515(Moves,MyBoard,EnBoard)
                                ,heruistic_87100515(MyBoard,EnBoard,H)
                                % Uncomment to print game situations
                              % ,writeln('Dice is :') , writeln(Dice1),writeln(Dice2)
                              % ,write('MyBoard: '),writeln(MyBoard),write('EnBoard: '),writeln(EnBoard)
                                ,play_87100515(MyBoard,EnBoard,Dice1,Dice2,MyMoves)
                                ,standard_all_moves_87100515(MyMoves,SMoves)
                                ,end_step_87100515(SMoves,MyBoard,EnBoard)
                                ,board_87100515(LastMyBoard)
                                ,is_winner_87100515(LastMyBoard,Win)
                              % ,write('MyMove: ') , writeln(SMoves),write('MyBoard: '),writeln(LastMyBoard)
                                ,msort(SMoves,SSMoves)
                                ,mine_to_standard_87100515(SSMoves,ResultMove)
                         %       ,get_time(T2)
                          %      ,T3 is T2-T1
                      %          ,writeln('time 87100515:')
                       %         ,writeln(T3)
                                ,done(ResultMove,Win).


% standarding the moves to match the rules
standard_to_mine_87100515([],[]).
standard_to_mine_87100515([X,Y,Z|Tail],[[X,Y,Z]|Tail2]):- standard_to_mine_87100515(Tail,Tail2).
mine_to_standard_87100515([],[]).
mine_to_standard_87100515([[X,Y,Z]|Tail],[X,Y,Z|Tail2]):- mine_to_standard_87100515(Tail,Tail2).
% heruistic alpha - betha
% heruistic const
:-dynamic hconst_87100515/2.

hconst_87100515(attacked,+1). % it is more than 6 times bigger in value than attack so it is not going to attack in home.
hconst_87100515(attack,+1).
hconst_87100515(filled,+1).
hconst_87100515(blot,+1).
hconst_87100515(pick,+1).
hconst_87100515(diff,+1).

hconst_87100515(end,+1).
% heruistic changer
all_are_past_87100515(MyBoard,EnBoard):- furthest_piece_87100515(MyBoard,X),reverse(EnBoard,TempBoard), furthest_piece_87100515(TempBoard,Z), Y is 25 - Z , Y < X ,!.

heruistic_changer_87100515(MyBoard,EnBoard):- hconst_87100515(end,1),all_are_past_87100515(MyBoard,EnBoard),!
                                       ,retractall(hconst_87100515(end,_)),assert(hconst_87100515(end,0)).%,writeln('H changed here!').
heruistic_changer_87100515(MyBoard,EnBoard).

% 1.number of up pieces - 2.number of blot _87100515( one piece cells )
heruistic_87100515(MyBoard,EnBoard,Num):- reverse(EnBoard,NewEnBoard) , evaluate_87100515(MyBoard,NewEnBoard,Num).

% board is from 1 to end._87100515( do not consisted of attacked piece )
evaluate_87100515([B1|MyBoard],[B2|EnBoard],H):-  number_of_home_filled_87100515(EnBoard,EnemyHomeFilled)
                                           ,number_of_home_filled_87100515(MyBoard,HomeFilled)
                                           ,number_of_blots_87100515(MyBoard,EnBoard,Attacked)
                                           ,number_of_blots_87100515(EnBoard,MyBoard,Attacke)
                                           ,evaluate_fortified_87100515(MyBoard,Filled)
                                           ,MyFired is B1*EnemyHomeFilled*EnemyHomeFilled
                                           ,EnemyFired is B2*HomeFilled*HomeFilled
                                           ,evaluate_pick_87100515(MyBoard,Pick)
                                           ,evaluate_piece_in_place_87100515(MyBoard,EnBoard,Diff)
                                           ,hconst_87100515(end,End)
,H is Filled*10*End + HomeFilled*12*End - MyFired*40*End + EnemyFired*End + Pick*20 + Diff/2 +25*25*B2/2 - 25*25*B1/2 - Attacked*EnemyHomeFilled*EnemyHomeFilled*End .
% distinguish between the cell pros and cons.
evaluate_a_cell_87100515(I,1):- I < 7  , !.     % in my enemy home.
evaluate_a_cell_87100515(I,1):- I < 13 , !.     % in my far mid.
evaluate_a_cell_87100515(I,3):- I < 19 , !.     % in my near mid.
evaluate_a_cell_87100515(I,3):- I < 25 , !.     % in my home.

% evaluate a blot
have_enemy_in_front_87100515(Begin,EnBoard,Num):- have_enemy_in_front_87100515(Begin,0,EnBoard,Num).
have_enemy_in_front_87100515(Begin,6,_,0):-!.
have_enemy_in_front_87100515(Begin,I,EnBoard,0):- X is Begin + I , X > 25 , ! .
have_enemy_in_front_87100515(Begin,I,EnBoard,Num):- X is Begin + I , nth0(X,EnBoard,0),! ,NewI is I + 1 , have_enemy_in_front_87100515(Begin,NewI,EnBoard,Num).
have_enemy_in_front_87100515(Begin,I,EnBoard,Num):- NewI is I + 1 , have_enemy_in_front_87100515(Begin,NewI,EnBoard,Temp) , Num is Temp+1.

% number of one piece cells.
number_of_blots_87100515(List,EnB,Num):- number_of_blots_87100515(List,EnB,Num,1).
number_of_blots_87100515(_,_,0,25):-!.
number_of_blots_87100515([1|Board],EnB,Num,I):- ! , NewI is I + 1 , hconst_87100515(blot,Blot) , have_enemy_in_front_87100515(I,EnB,X), NX is X+1 , number_of_blots_87100515(Board,EnB,Temp,NewI) , evaluate_a_cell_87100515(I,ND),  Num is Temp + Blot*ND*NX.
number_of_blots_87100515([X|Board],EnB,Num,I):- NewI is I + 1 , number_of_blots_87100515(Board,EnB,Num,NewI).

% evaluate all of fortified cells.
evaluate_fortified_87100515(Board,Num):- evaluate_fortified_87100515(Board,Num,1).
evaluate_fortified_87100515(_,0,25):-!.
evaluate_fortified_87100515([H|Board],Num,I):- H > 1 , ! , NewI is I + 1, hconst_87100515(filled,Filled) , evaluate_fortified_87100515(Board,Temp,NewI) ,evaluate_a_cell_87100515(I,Eval) ,  Num is Temp + Eval*Filled.
evaluate_fortified_87100515([H|Board],Num,I):- NewI is I + 1 , evaluate_fortified_87100515(Board,Num,NewI).

% number of fortified cells in home.
number_of_home_filled_87100515(Board,Num):- reverse(Board,TempBoard) , number_of_home_filled_87100515(TempBoard,Num,0).
number_of_home_filled_87100515(_,0,7):-!.

number_of_home_filled_87100515([H|Board],Num,I):- H > 1 , ! , NewI is I + 1, number_of_home_filled_87100515(Board,Temp,NewI) , Num is Temp + 1.
number_of_home_filled_87100515([H|Board],Num,I):- NewI is I + 1 , number_of_home_filled_87100515(Board,Num,NewI).
% number of each piece in place
number_of_piece_in_place_87100515(Board,Num):- number_of_piece_in_place_87100515(Board,Num,1).
number_of_piece_in_place_87100515(_,0,25):-!.
number_of_piece_in_place_87100515([H|Board],Num,I):- NewI is I + 1 , number_of_piece_in_place_87100515(Board,Temp,NewI) , NI is 25-NewI,NI2 is (NI), Num is H*NI*NI2 + Temp. % in order to make it cubic important.
% evaluate places
evaluate_piece_in_place_87100515(MyBoard,EnBoard,Num) :- number_of_piece_in_place_87100515(MyBoard,Num1) , number_of_piece_in_place_87100515(EnBoard,Num2) ,  hconst_87100515(diff,Diff) , TempNum is Num2 - Num1 , Num is TempNum * Diff.
% evaluate pick moves
evaluate_pick_87100515(Board,Num):- nth0(24,Board,X) , hconst_87100515(pick,Pick) , Num is Pick * X.

% All dice
small_eq_87100515(X,Y) :- X < Y ; X == Y .
dice_87100515(X,Y):- my_member_87100515(X,[1,2,3,4,5,6]) , my_member_87100515(Y,[1,2,3,4,5,6]) , small_eq_87100515(X,Y). % doesn't consider double dice.
all_dice_87100515(List):- setof(X/Y,dice_87100515(X,Y),List).
create_dice_list_87100515(List):- all_dice_87100515(L) , create_dice_list_87100515(L,List).
create_dice_list_87100515([],[]).
create_dice_list_87100515([X/X|Tail],[X/X/0.02778|Tail2]):- ! , create_dice_list_87100515(Tail,Tail2).
create_dice_list_87100515([X/Y|Tail],[X/Y/0.05555|Tail2]):- create_dice_list_87100515(Tail,Tail2).
%create_dice_list_87100515([X/Y|Tail],[X/Y/0.06666|Tail2]):- create_dice_list_87100515(Tail,Tail2).



get_max_best_current_moves_87100515(MyBoard,EnBoard,Moves,TopMoves,Count):- sort_based_on_h_87100515(MyBoard,EnBoard,Moves,TempMoves), reverse(TempMoves,TempMoves1) , get_count_max_h_87100515(TempMoves1,TopMoves,Count).
get_min_best_current_moves_87100515(MyBoard,EnBoard,Moves,TopMoves,Count):- sort_based_on_h_87100515(MyBoard,EnBoard,Moves,TempMoves) , get_count_max_h_87100515(TempMoves,TopMoves,Count).

get_count_max_h_87100515([],[],_):-!.
get_count_max_h_87100515(_,[],0):-!.
get_count_max_h_87100515([Move|Moves],[Move|TopMoves],Count):- NewC is Count-1 , get_count_max_h_87100515(Moves,TopMoves,NewC).

sort_based_on_h_87100515(MyBoard,EnBoard,Moves,SortMoves):- find_all_h_87100515(MyBoard,EnBoard, Moves,HMoves) , sort(HMoves,TempSortMoves) , clear_moves_from_h_87100515(TempSortMoves,SortMoves).

find_all_h_87100515(_,_,[],[]).
find_all_h_87100515(MyBoard,EnBoard,[Move|ListMoves],[H/Move|ListMoves1]):- update_all_my_moves_87100515(Move,MyBoard,M1,EnBoard,E1), heruistic_87100515(M1,E1,H) , find_all_h_87100515(MyBoard,EnBoard,ListMoves,ListMoves1).

clear_moves_from_h_87100515([],[]).
clear_moves_from_h_87100515([H/Move|List1],[Move|List2]):- clear_moves_from_h_87100515(List1,List2).


max_move_87100515(Num1,M1,Num2,M2,Move):-Num2>Num1,!,Move = M2.
max_move_87100515(Num1,M1,Num2,M2,Move):-Move=M1.

update_all_moves_87100515(1,State,EState,Move,NState,NEState):- ! , update_all_en_moves_87100515(Move,State,NState,EState,NEState).
update_all_moves_87100515(0,State,EState,Move,NState,NEState):- ! , update_all_my_moves_87100515(Move,State,NState,EState,NEState).

sort_move_87100515(State,EState,D,List,Moves):- get_time(T1)
                                        ,get_max_best_current_moves_87100515(State,EState,List,TList,100)
                                         ,choose_move_87100515(T1,State,EState,D,TList,-100000000,100000000,Moves,Num).

choose_move_87100515(T,_,_,_,_,_,_,[],-100000000):-get_time(T2),T3 is T2-T,T3>4.
choose_move_87100515(_,State,EState,D,[],_,_,[],-1000000).
choose_move_87100515(T,State,EState,D,[H|Moves],Alpha,Betha,Move,Num):-
                                                 %writeln('here')
                                                 get_time(T1)
                                                 ,update_all_moves_87100515(0,State,EState,H,NState,NEState)
                                                 ,all_of_dice_87100515(Dices)
                                                 ,ND is D-1
                                                 ,chance_node_87100515(Dices,NState,NEState,ND,1,Alpha,Betha,0,Num1,1)
                                                 ,my_max_87100515(Alpha,Num1,NAlpha)
                                                 ,get_time(T2)
                                                 ,T3 is T2-T1
                                                 ,heruistic_87100515(NState,NEState,X)
                                                 ,choose_move_87100515(T,State,EState,D,Moves,NAlpha,Betha,Move1,Num2)
                                                 ,max_move_87100515(Num1,H,Num2,Move1,Move)
                                                 ,my_max_87100515(Num1,Num2,Num).

chance_node_87100515([],_,_,_,_,_,_,Num,Num,_):-!.
chance_node_87100515(_,State,EState,0,Who,_,_,_,Num,_):-!,heruistic_87100515(State,EState,Num).
chance_node_87100515([X/Y/P|Dices],State,EState,D,Who,Alpha,Betha,ONum,Num,P2):-alpha_betha_87100515(Who,State,EState,D,X,Y,Alpha,Betha,Num1)
                                                                     ,Num2 is Num1*P + ONum
                                                                     ,NP2 is P2-P
                                                                     ,cut_chance_node_87100515(Dices,State,EState,D,Who,Alpha,Betha,Num2,Num,NP2).

cut_chance_node_87100515(Dices,State,EState,D,0,Alpha,Betha,ONum,100000000,P1):- my_max_87100515(P1,0,P) , Betha < ONum+P*(-1000000) , !.
cut_chance_node_87100515(Dices,State,EState,D,1,Alpha,Betha,ONum,-100000000,P1):- my_max_87100515(P1,0,P), Alpha > ONum+P*(1000000) , !.
cut_chance_node_87100515(Dices,State,EState,D,Who,Alpha,Betha,ONum,Num,P):-chance_node_87100515(Dices,State,EState,D,Who,Alpha,Betha,ONum,Num,P).

alpha_betha_87100515(Who,State,EState,D,Dice1,Dice2,Alpha,Betha,Num):- list_of_possible_actions_87100515(Who,State,EState,Dice1,Dice2,Moves1)
                                                             ,alpha_betha_p_87100515(Who,State,EState,D,Alpha,Betha,Moves1,Num).

alpha_betha_p_87100515(Who,State,EState,D,Alpha,Betha,[],Num):- !
                                                       ,all_of_dice_87100515(Dices)
                                                       ,NWho is 1-Who
                                                       ,ND is D-1
                                                       ,chance_node_87100515(Dices,State,EState,ND,NWho,Alpha,Betha,0,Num,1).
alpha_betha_p_87100515(Who,State,EState,D,Alpha,Betha,Moves,Num):- ! , choose_move_p_87100515(Who,State,EState,D,Moves,Alpha,Betha,Num).


choose_move_p_87100515(Who,State,Estate,D,[],Alpha,Betha,Num):- !,return_what_87100515(Who,Alpha,Betha,Num).
choose_move_p_87100515(0,State,EState,D,[H|Moves],Alpha,Betha,Num):- !
                                                            ,update_all_moves_87100515(0,State,EState,H,NState,NEState)
                                                            ,all_of_dice_87100515(Dices)
                                                            ,ND is D-1
                                                            ,chance_node_87100515(Dices,NState,NEState,ND,1,Alpha,Betha,0,Num1,1)
                                                            ,my_max_87100515(Num1,Alpha,NAlpha)
                                                            ,cut_choose_move_p_87100515(0,State,EState,D,Moves,NAlpha,Betha,Num).
choose_move_p_87100515(1,State,EState,D,[H|Moves],Alpha,Betha,Num):- !
                                                            ,update_all_moves_87100515(1,State,EState,H,NState,NEState)
                                                            ,all_of_dice_87100515(Dices)
                                                            ,ND is D-1
                                                            ,chance_node_87100515(Dices,NState,NEState,ND,0,Alpha,Betha,0,Num1,1)
                                                            ,my_min_87100515(Num1,Betha,NBetha)
                                                            ,cut_choose_move_p_87100515(1,State,EState,D,Moves,Alpha,NBetha,Num).

cut_choose_move_p_87100515(Who,State,EState,D,Moves,Alpha,Betha,Num):- choose_move_p_87100515(Who,State,EState,D,Moves,Alpha,Betha,Num).

return_what_87100515(0,L,K,L):-!.
return_what_87100515(1,L,K,K):-!.
