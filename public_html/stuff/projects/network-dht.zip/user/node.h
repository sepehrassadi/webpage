//			In the name of GOD
/**
 * Copyright (C) 2009-2011 Behnam Momeni.
 * All rights reserved.
 *
 * This file is part of the HVNS project.
 */


#ifndef NODE_H
#define NODE_H

#include "sm.h"


// node code specific declarations...

/* Just an example...
class Node {

};
*/

#endif /* node.h */

