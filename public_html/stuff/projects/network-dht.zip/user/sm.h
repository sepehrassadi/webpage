//			In the name of GOD
/**
 * Copyright (C) 2009-2011 Behnam Momeni.
 * All rights reserved.
 *
 * This file is part of the HVNS project.
 */


#ifndef S_M_H
#define S_M_H

#include "machine.h"

class SimulatedMachine : public Machine {
public:
	SimulatedMachine (const ClientFramework *cf, int count);
	virtual ~SimulatedMachine ();

	virtual void initialize ();
	virtual void run ();
	virtual void processFrame (Frame frame, int ifaceIndex);
	
	static void parseArguments (int argc, char *argv[]);
};

#endif /* sm.h */

