/*
 * common.h
 *
 *  Created on: May 25, 2010
 *      Author: amir
 */

#ifndef COMMON_H_
#define COMMON_H_

#include "sr_protocol.h"
#include "hvnsdef.h"

// header file for your utilities like calculating hash value, mac class, etc.

#endif /* common.h */

