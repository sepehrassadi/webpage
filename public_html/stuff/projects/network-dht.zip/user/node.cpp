//			In the name of GOD
/**
 * Copyright (C) 2009-2011 Behnam Momeni.
 * All rights reserved.
 *
 * This file is part of the HVNS project.
 *
 * Place code of "Node"s in this file.
 */

#include "node.h"
#include "frame.h"
#include "interface.h"
#include "common.h"
#include <openssl/sha.h>
#include <netinet/in.h>
#include <map>
#include <vector>
#include <algorithm>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <ctime>
#include <iomanip>
using namespace std;

#define ALL_HEADER_SIZE (sizeof(sr_ethernet_hdr)+sizeof(ip)+sizeof(sr_udp)+sizeof(sr_data_type))
#define DEBUG_MODE 
#undef DEBUG_MODE
void getID(const char* query,unsigned char* id){
	SHA1((unsigned char*)query,strlen(query),id);
}
bool comp(const unsigned char* t1,const unsigned char* t2){
	for ( int i = 0 ; i < 20 ; i++)
		if ( t1[i] < t2[i] )
			return true;
		else if ( t1[i] > t2[i])
			return false;
	return true;
}
struct FileEntry{
	string filename,ip,port;
};
// joining
#define DATA_JOIN			1
#define DATA_JOIN_ACK		2
#define DATA_PUT_PRED		3
#define DATA_PUT_SUCC		4

#define DATA_PUT_FILE		5

#define DATA_GET_FILE		6
#define DATA_GET_FILE_ACK	7

struct sr_data_type
{
	uint16_t command;	
}__attribute__ ((packed));

struct sr_data_join
{
	uint32_t src_ip;
}__attribute__ ((packed));

struct sr_data_join_ack
{
	uint32_t succ_ip;
	uint32_t pred_ip;
}__attribute__ ((packed));

#define FILENAME_SIZE 100 

struct sr_data_file{
	char filename[FILENAME_SIZE];
	uint32_t ip;
	uint16_t port;
}__attribute__ ((packed));

struct sr_data_get_file{
	uint32_t src_ip;
	char filename[FILENAME_SIZE];
}__attribute__ ((packed));

// Tools:
void printFrame(byte* data, int length) {
	cout << hex;
	for(int i = 0; i < length; i++) {
		if(data[i] < 16) cout << "0";
		cout << (int)data[i]<< ' ';
	}
	cout << dec << endl;
}
uint8_t* string_to_mac(string str){
	istringstream iss( str );
	char temp;
	iss >> hex;
	uint8_t* mac = new uint8_t[ETHER_ADDR_LEN];
	
	for ( int i = 0 ; i < ETHER_ADDR_LEN ; i++){
		int next;
		iss >> next;
		mac[i] = next;
		if ( i < ETHER_ADDR_LEN-1)
			iss >> temp; // garbage.
	}
	return mac;
}

/*
 **************************************************************************
 Function: tcp_sum_calc()
 **************************************************************************
 Description: 
 Calculate TCP checksum
 Used from:  http://www.netfor2.com/tcpsum.htm
 ***************************************************************************
 */

typedef unsigned short u16;
typedef unsigned long u32;

u16 tcp_sum_calc(u16 len_tcp, uint8_t src_addr[],uint8_t dest_addr[], bool padding, uint8_t buff[])
{
	u16 prot_tcp=6;
	u16 padd=0;
	u16 word16;
	u32 sum;	
	
	// Find out if the length of data is even or odd number. If odd,
	// add a padding byte = 0 at the end of packet
	if (padding&1==1){
		padd=1;
		buff[len_tcp]=0;
	}
	
	//initialize sum to zero
	sum=0;
	u16 i;	
	// make 16 bit words out of every two adjacent 8 bit words and 
	// calculate the sum of all 16 vit words
	for (i=0;i<len_tcp+padd;i=i+2){
		word16 =((buff[i]<<8)&0xFF00)+(buff[i+1]&0xFF);
		sum = sum + (unsigned long)word16;
	}	
	// add the TCP pseudo header which contains:
	// the IP source and destinationn addresses,
	for (i=0;i<4;i=i+2){
		word16 =((src_addr[i]<<8)&0xFF00)+(src_addr[i+1]&0xFF);
		sum=sum+word16;	
	}
	for (i=0;i<4;i=i+2){
		word16 =((dest_addr[i]<<8)&0xFF00)+(dest_addr[i+1]&0xFF);
		sum=sum+word16; 	
	}
	// the protocol number and the length of the TCP packet
	sum = sum + prot_tcp + len_tcp;
	
	// keep only the last 16 bits of the 32 bit calculated sum and add the carries
	while (sum>>16)
		sum = (sum & 0xFFFF)+(sum >> 16);
	
	// Take the one's complement of sum
	sum = ~sum;
	
	return ((unsigned short) sum);
}
/*
 **************************************************************************
 Function: ip_sum_calc
 Description: Calculate the 16 bit IP sum.
 Used from: http://www.netfor2.com/ipsum.htm
 ***************************************************************************
 */

u16 ip_sum_calc(u16 len_ip_header, uint8_t* buff)
{
	u16 word16;
	u32 sum=0;
	u16 i;
	
	// make 16 bit words out of every two adjacent 8 bit words in the packet
	// and add them up
	for (i=0;i<len_ip_header;i=i+2){
		word16 =((buff[i]<<8)&0xFF00)+(buff[i+1]&0xFF);
		sum = sum + (u32) word16;	
	}
	
	// take only 16 bits out of the 32 bit sum and add up the carries
	while (sum>>16)
		sum = (sum & 0xFFFF)+(sum >> 16);
	
	// one's complement the result
	sum = ~sum;
	
	return ((u16) sum);
}


/*
 **************************************************************************
 Function: udp_sum_calc()
 Description: Calculate UDP checksum
 Used from: http://www.netfor2.com/udpsum.htm
 ***************************************************************************
 */

u16 udp_sum_calc(u16 len_udp, uint8_t* src_addr,uint8_t* dest_addr,bool padding,uint8_t* buff)
{
	u16 prot_udp=17;
	u16 padd=0;
	u16 word16;
	u32 sum;	
	len_udp = ntohs(len_udp);		
	// Find out if the length of data is even or odd number. If odd,
	// add a padding byte = 0 at the end of packet
	if (padding&1==1){
		padd=1;
		buff[len_udp]=0;
	}
	
	//initialize sum to zero
	sum=0;
	
	// make 16 bit words out of every two adjacent 8 bit words and 
	// calculate the sum of all 16 vit words
	int i;
	for ( i=0;i<len_udp+padd;i=i+2){
		word16 =((buff[i]<<8)&0xFF00)+(buff[i+1]&0xFF);
		sum = sum + (unsigned long)word16;
	}	
	// add the UDP pseudo header which contains the IP source and destinationn addresses
	for (i=0;i<4;i=i+2){
		word16 =((src_addr[i]<<8)&0xFF00)+(src_addr[i+1]&0xFF);
		sum=sum+word16;	
	}
	for (i=0;i<4;i=i+2){
		word16 =((dest_addr[i]<<8)&0xFF00)+(dest_addr[i+1]&0xFF);
		sum=sum+word16; 	
	}
	// the protocol number and the length of the UDP packet
	sum = sum + prot_udp + len_udp;
	// keep only the last 16 bits of the 32 bit calculated sum and add the carries
   	while (sum>>16)
		sum = (sum & 0xFFFF)+(sum >> 16);
	
	// Take the one's complement of sum
	sum = ~sum;
	return ((u16) sum);
}

// Constants:
const uint16_t udp_port = 2000;
// parser:
string mac_of_the_router;
vector<string> candidate_ip_address;
// states:
string successor_ip = "0.0.0.0";
string predecessor_ip = "0.0.0.0";
vector<FileEntry> fileEntry; 

int findFile(string filename){
	for ( unsigned int i = 0 ; i < fileEntry.size() ; i++)
		if ( fileEntry[i].filename == filename )
			return i;
	return -1;
}

// parser_arguments: 

int lastToken = 0;

string nextToken(string input){ // extract next Token from input.
	int pos= input.find('\n',lastToken);
	if ( pos == -1 )
		return "$"; // act as my EOF.
	string token = input.substr(lastToken,pos-lastToken);
	lastToken = pos+1;
	return token;
}
uint32_t getIPfromString(string dst_ip){
	in_addr temp; 
	inet_aton(dst_ip.c_str(),&temp);
	uint32_t ip_dst = htonl(temp.s_addr);
	return ip_dst;
}
string getStringfromIP(uint32_t ip){
	in_addr temp;
	temp.s_addr = ip;
	return inet_ntoa(temp);
}

// UDP Frames: 
// Packet creatings:

Frame getUDPFrame(uint8_t* src_mac,uint8_t* dst_mac,uint32_t ip_src,uint32_t ip_dst,uint16_t src_port,uint16_t dst_port,char* data,int data_size){
	// maybe problem in size of ip.
	int all_header_size = sizeof(sr_ethernet_hdr) + sizeof(ip) + sizeof(sr_udp);

	byte* cp = new byte[all_header_size + data_size ];
	bzero(cp,all_header_size+data_size);
	Frame frame(all_header_size+data_size,cp);
	
	sr_ethernet_hdr* ether_part = (sr_ethernet_hdr*) frame.data;
	ip* ip_part = (ip*) (frame.data+sizeof(sr_ethernet_hdr));
	sr_udp* udp_part = (sr_udp*)(frame.data+sizeof(sr_ethernet_hdr)+sizeof(ip));
	
	char* udp_data = (char*)(frame.data + all_header_size );	
	// DATA part:
	bcopy(data,udp_data,data_size);
	// UDP part:
	udp_part->port_src = htons(src_port);
	udp_part->port_dst = htons(dst_port);
	udp_part->length = htons(sizeof(sr_udp)+data_size);
	// IP part:
	ip_part->ip_v = 4;
	ip_part->ip_hl = 5;
	ip_part->ip_tos = 0;
	ip_part->ip_id = 0;
	ip_part->ip_off = 0;
	ip_part->ip_src.s_addr = ip_src;
	ip_part->ip_dst.s_addr = ip_dst;
	ip_part->ip_ttl = 0x00ff;
	ip_part->ip_len = htons(sizeof(ip)+sizeof(sr_udp)+data_size);
	ip_part->ip_p = IPPROTO_UDP;
	// ETHERNET part:
	for ( int i = 0 ; i < ETHER_ADDR_LEN ; i++){
		ether_part->ether_dhost[i] = dst_mac[i];
		ether_part->ether_shost[i] = src_mac[i];
	}
	ether_part->ether_type = 8 ;
	// CHECKSUM part:
	udp_part->udp_sum = 0;
	udp_part->udp_sum = htons(udp_sum_calc(udp_part->length, (uint8_t*)(&(ip_src)), (uint8_t*)(&(ip_dst)),1,(uint8_t*)udp_part));
	ip_part->ip_sum = 0;
	ip_part->ip_sum = htons(ip_sum_calc((ip_part->ip_hl)*4,(uint8_t*)(ip_part)));
	return frame;
}
Frame createUDPRequest(Interface iface,string dst_ip,char* data,int data_size){
	uint32_t ip_src = htonl(iface.getIP());
	uint32_t ip_dst = htonl(getIPfromString(dst_ip));
	Frame frame = getUDPFrame(iface.mac,string_to_mac(mac_of_the_router.c_str()),ip_src,ip_dst,udp_port,udp_port,data,data_size);
#ifdef DEBUG_MODE
	printFrame(frame.data,frame.length);
#endif
	return frame;
}
Frame create_join_packet(Interface iface,string dst_ip,uint32_t sender_ip){
	sr_data_type* sr_type = new sr_data_type();
	sr_type->command = DATA_JOIN;
	sr_data_join* sr_join = new sr_data_join();
	sr_join->src_ip = sender_ip;
	int data_size = sizeof(sr_data_type)+sizeof(sr_data_join)+1;
	char* data =new char[data_size];
	bcopy(sr_type,data,sizeof(sr_data_type));
	bcopy(sr_join,data+sizeof(sr_data_type),sizeof(sr_data_join));
	data[data_size-1]=NULL;
	return createUDPRequest(iface,dst_ip,data,data_size);
}
Frame create_join_ack_packet(Interface iface,string dst_ip){
	sr_data_type* sr_type = new sr_data_type();
	sr_type->command = DATA_JOIN_ACK;
	sr_data_join_ack* join_ack = new sr_data_join_ack();
	join_ack->pred_ip = htonl(iface.getIP());
	join_ack->succ_ip = htonl( successor_ip =="0.0.0.0" ? iface.getIP() : getIPfromString(successor_ip) ) ;
	int data_size = sizeof(sr_data_type)+sizeof(sr_data_join_ack)+1;
	char* data =new char[data_size];
	bcopy(sr_type,data,sizeof(sr_data_type));
	bcopy(join_ack,data+sizeof(sr_data_type),sizeof(sr_data_join_ack));
	data[data_size-1]=NULL;
	return createUDPRequest(iface,dst_ip,data,data_size);
}
Frame create_put_pred_packet(Interface iface,uint32_t src_ip,string dst_ip){
	sr_data_type* sr_type = new sr_data_type();
	sr_type->command = DATA_PUT_PRED;
	sr_data_join* sr_join = new sr_data_join();
	sr_join->src_ip = src_ip;
	int data_size = sizeof(sr_data_type)+sizeof(sr_data_join)+1;
	char* data =new char[data_size];
	bcopy(sr_type,data,sizeof(sr_data_type));
	bcopy(sr_join,data+sizeof(sr_data_type),sizeof(sr_data_join));
	data[sizeof(sr_data_type)+sizeof(sr_data_join)]=NULL;
	return createUDPRequest(iface,dst_ip,data,data_size);
}
Frame create_put_succ_packet(Interface iface,uint32_t src_ip,string dst_ip){
	sr_data_type* sr_type = new sr_data_type();
	sr_type->command = DATA_PUT_SUCC;
	sr_data_join* sr_join = new sr_data_join();
	sr_join->src_ip = src_ip;
	int data_size = sizeof(sr_data_type)+sizeof(sr_data_join)+1;
	char* data =new char[data_size];
	bcopy(sr_type,data,sizeof(sr_data_type));
	bcopy(sr_join,data+sizeof(sr_data_type),sizeof(sr_data_join));
	data[sizeof(sr_data_type)+sizeof(sr_data_join)]=NULL;
	return createUDPRequest(iface,dst_ip,data,data_size);
	
}
Frame create_put_packet(Interface iface,string dst_ip,FileEntry f){
	sr_data_type* sr_type = new sr_data_type();
	sr_type->command = DATA_PUT_FILE;
	sr_data_file* data_file = new sr_data_file();
	bcopy(f.filename.c_str(),data_file->filename,f.filename.size());
	data_file->ip = getIPfromString(f.ip);
	data_file->port = atoi(f.port.c_str());
	int data_size = sizeof(sr_data_type)+sizeof(sr_data_file)+1;
	char* data =new char[data_size];
	bcopy(sr_type,data,sizeof(sr_data_type));
	bcopy(data_file,data+sizeof(sr_data_type),sizeof(sr_data_file));
	data[sizeof(sr_data_type)+sizeof(sr_data_file)]=NULL;
	return createUDPRequest(iface,dst_ip,data,data_size);	
}
Frame create_get_packet(Interface iface,string dst_ip,string filename,uint32_t src_ip){
	sr_data_type* sr_type = new sr_data_type();
	sr_type->command = DATA_GET_FILE;
	sr_data_get_file* data_file = new sr_data_get_file();
	
	data_file->src_ip = src_ip;
	bcopy(filename.c_str(),data_file->filename,filename.size());
	
	int data_size = sizeof(sr_data_type)+sizeof(sr_data_get_file);
	char* data =new char[data_size];
	bcopy(sr_type,data,sizeof(sr_data_type));
	bcopy(data_file,data+sizeof(sr_data_type),sizeof(sr_data_get_file));
	return createUDPRequest(iface,dst_ip,data,data_size);	
}
Frame create_get_ack_packet(Interface iface,string dst_ip,FileEntry f){
	sr_data_type* sr_type = new sr_data_type();
	sr_type->command = DATA_GET_FILE_ACK;
	sr_data_file* data_file = new sr_data_file();
	bcopy(f.filename.c_str(),data_file->filename,f.filename.size());
	data_file->ip = getIPfromString(f.ip);
	data_file->port = atoi(f.port.c_str());
	int data_size = sizeof(sr_data_type)+sizeof(sr_data_file)+1;
	char* data =new char[data_size];
	bcopy(sr_type,data,sizeof(sr_data_type));
	bcopy(data_file,data+sizeof(sr_data_type),sizeof(sr_data_file));
	data[sizeof(sr_data_type)+sizeof(sr_data_file)]=NULL;
	return createUDPRequest(iface,dst_ip,data,data_size);		
}
// Utility:
bool next_hop_here(uint32_t _goal,uint32_t myip){
	string __goal = getStringfromIP(_goal);
	string __ip = getStringfromIP(myip);
	
	unsigned char goal[20];  getID(__goal.c_str(),goal);
	unsigned char ip  [20];  getID(__ip.c_str(),ip);
	unsigned char succ[20];  getID(successor_ip.c_str(),succ);
	unsigned char pred[20];  getID(predecessor_ip.c_str(),pred);
	// anomaly mode:
	if ( successor_ip == "0.0.0.0")
		return true;
	if ( comp(succ,ip) ){
		if ( comp(ip , goal) || comp(goal , succ)  )
			return true;
		return false;
	}
	// normal mode:
	if ( comp(ip , goal) && comp(goal , succ) )
		return true;
	return false;
}
bool next_file_here(string filename,uint32_t myip){
	string __goal = filename;
	string __ip = getStringfromIP(myip);
	
	unsigned char goal[20];  getID(__goal.c_str(),goal);
	unsigned char ip  [20];  getID(__ip.c_str(),ip);
	unsigned char succ[20];  getID(successor_ip.c_str(),succ);
	unsigned char pred[20];  getID(predecessor_ip.c_str(),pred);
	// anomaly mode:
	if ( successor_ip == "0.0.0.0")
		return true;
	if ( comp(succ,ip) ){
		if ( comp(ip , goal) || comp(goal , succ) )
			return true;
		return false;
	}
	// normal mode:
	if ( comp(ip , goal) && comp(goal , succ) )
		return true;
	return false;
}
FileEntry get_file_data(sr_data_file* file){
	char filename[FILENAME_SIZE];
	bcopy(file->filename,filename,FILENAME_SIZE);
	uint32_t ip = htonl(file->ip);
	uint16_t port = file->port;
	FileEntry f;
	f.filename = string(filename);
	f.ip = getStringfromIP(ip);
	stringstream temp; temp << port;
	f.port = temp.str();
	return f;
}
// Joining methods:
bool JOINING_PART = true;
bool IS_CONNECTED = false;
void join_to_network(SimulatedMachine* machine,Interface iface){
	JOINING_PART = true;
	for ( int i = 0 ; i < 5*candidate_ip_address.size() && JOINING_PART ; i++){
		if ( i%5 == 0){
			cout << "\nTrying to join to: " << candidate_ip_address[i/5] << ' ';
			machine->sendFrame(create_join_packet(iface,candidate_ip_address[i/5],htonl(iface.getIP())),0);
		}
		cout << '.' << flush;
		sleep(1);
	}
	cout << "\nSuccessfuly connected to P2P network" << endl;
	JOINING_PART = false;
	IS_CONNECTED = true; // just in case it is the first node.

}
void send_join_information(SimulatedMachine* machine,Interface iface,uint32_t goal){
	int counter = 0;
	for ( int i = 0 ; i < fileEntry.size();i++){
		if ( !next_file_here(fileEntry[i].filename,htonl(iface.getIP()))){
			Frame frame = create_put_packet(iface,getStringfromIP(goal),fileEntry[i]);
			machine->sendFrame(frame,0);
			swap(fileEntry[i],fileEntry[counter++]);
		}
	}
	fileEntry.erase(fileEntry.begin(),fileEntry.begin()+counter); // remove these files from current node.
}
// send to its successor or call it backward to sender.
void proccess_join_to_network(SimulatedMachine* machine,Interface iface,Frame frame){
	sr_data_join* join = (sr_data_join*) ( frame.data + ALL_HEADER_SIZE );
	uint32_t goal = join->src_ip;
	bool next_hop = next_hop_here(goal,htonl(iface.getIP()));	// get next hop (1): succ (2):pred (3):sender.
	
	if ( next_hop == true ){				// node is here.
		Frame newFrame = create_join_ack_packet(iface,getStringfromIP(goal));
		successor_ip = getStringfromIP(goal);
		machine->sendFrame(newFrame,0);
		send_join_information(machine,iface,goal);
	}else{
		Frame newFrame = create_join_packet(iface,successor_ip,goal);
		machine->sendFrame(newFrame,0);
	}
}
void get_data_join_ack_info(SimulatedMachine* machine,Interface iface, Frame frame){
	sr_data_join_ack* ack = ( sr_data_join_ack*)(frame.data+ALL_HEADER_SIZE);
	uint32_t succ = ack->succ_ip;
	successor_ip = getStringfromIP(succ);
	uint32_t pred = ack->pred_ip;
	predecessor_ip = getStringfromIP(pred);
	// inform its successor its new predecessor:
	Frame newFrame = create_put_pred_packet(iface,htonl(iface.getIP()),successor_ip);
	machine->sendFrame(newFrame,0);
}

void get_from_network(SimulatedMachine* machine,Interface iface,string filename,uint32_t src_ip){
	if (next_file_here(filename,htonl(iface.getIP()))){
		int index = findFile(filename);
		if ( index == -1 ){
			FileEntry f; 
			f.filename="$";
			machine->sendFrame(create_get_ack_packet(iface,getStringfromIP(src_ip),f),0);
			return;
		}
		machine->sendFrame(create_get_ack_packet(iface,getStringfromIP(src_ip),fileEntry[index]),0);
	}else{
		Frame frame = create_get_packet(iface,successor_ip,filename,src_ip);
		machine->sendFrame(frame,0);
	}
}
void proccess_get_from_network(SimulatedMachine* machine,Interface iface,Frame frame){
	sr_data_get_file* file = (sr_data_get_file*) (frame.data+ALL_HEADER_SIZE);
	string filename(file->filename);
	uint32_t src_ip = file->src_ip;
	get_from_network(machine,iface,filename,src_ip);
}
void put_to_network(SimulatedMachine* machine,Interface iface,FileEntry f){
	if ( next_file_here(f.filename,htonl(iface.getIP()))){
		fileEntry.push_back(f);
#ifdef DEBUG_MODE
		cerr << "Information Gained: " << endl;
		cerr << f.filename << ' ' << f.ip << ' ' << f.port << endl;
		cerr << "End Information Gained: " << endl;		
#endif
		
	}else{
		Frame frame = create_put_packet(iface,successor_ip,f);
		machine->sendFrame(frame,0);
	}
}
void proccess_put_to_network(SimulatedMachine* machine,Interface iface,Frame frame){
	sr_data_file* file = (sr_data_file*)(frame.data+ALL_HEADER_SIZE);
	FileEntry f = get_file_data(file);
	put_to_network(machine,iface,f);
}

void get_data_put_pred(Frame frame){
	sr_data_join* put = (sr_data_join*)(frame.data+ALL_HEADER_SIZE);
	uint32_t src_ip = put->src_ip;
	predecessor_ip = getStringfromIP(src_ip);
}
void get_data_put_succ(Frame frame){
	sr_data_join* put = (sr_data_join*)(frame.data+ALL_HEADER_SIZE);
	uint32_t src_ip = put->src_ip;
	successor_ip = getStringfromIP(src_ip);
}
void get_data_ack(Frame frame){
	sr_data_file* file = (sr_data_file*)(frame.data+ALL_HEADER_SIZE);
	FileEntry f = get_file_data(file);
	if ( f.filename == "$"){
		cout << "File not found" << endl;
		return;
	}
	cout << "File found: " << endl;
	cout << f.filename << '\t' << f.ip << '\t' << f.port << endl;
}
void leave(SimulatedMachine* machine,Interface iface){
	
	// inform its predecessor its leave:
	
	Frame frame = create_put_succ_packet(iface,htonl(getIPfromString(successor_ip==predecessor_ip? "0.0.0.0" : successor_ip)),predecessor_ip);
	machine->sendFrame(frame,0);
	// inform its successor its leave:
	frame = create_put_pred_packet(iface,htonl(getIPfromString(predecessor_ip==successor_ip? "0.0.0.0" : predecessor_ip)),successor_ip);
	machine->sendFrame(frame,0);
	
	// sends all the files:
	for ( int i = 0 ; i < fileEntry.size() ; i++){
		Frame frame = create_put_packet(iface,predecessor_ip,fileEntry[i]);
		machine->sendFrame(frame,0);
	}
	fileEntry.erase(fileEntry.begin(),fileEntry.end());
	cout << "Successfuly left the P2P network" << endl;
	IS_CONNECTED = false;
}
uint16_t get_frame_type(Frame frame){
	sr_data_type* sr_type = (sr_data_type*)(frame.data+sizeof(sr_ethernet_hdr)+sizeof(ip)+sizeof(sr_udp));
	return sr_type->command;
}

SimulatedMachine::SimulatedMachine(const ClientFramework *cf, int count) :
	Machine(cf, count) {
	// The machine instantiated.
	// Interfaces are not valid at this point.
}

SimulatedMachine::~SimulatedMachine() {
	// destructor...
}

void SimulatedMachine::initialize() {
	// TODO: Initialize your program here; custom information and interfaces are valid now.
	string info = getCustomInformation();
	
	info = info+"\n";
	
	// find mac of router:
	
	mac_of_the_router = nextToken(info);
	
	// find candidates ip: 
	
	string temp_id = nextToken(info);
	
	while ( temp_id != "$"){
		candidate_ip_address.push_back(temp_id);
		temp_id = nextToken(info);
	}
	
}

/**
 * This method is called from the main thread.
 * Also ownership of the data of the frame is not with you.
 * If you need it, make a copy for yourself.
 *
 * You can also send frames using:
 * <code>
 *     bool synchronized sendFrame (Frame frame, int ifaceIndex) const;
 * </code>
 * which accepts one frame and the interface index (counting from 0) and
 * sends the frame on that interface.
 * The Frame class used here, encapsulates any kind of network frame.
 * <code>
 *     class Frame {
 *     public:
 *       uint32 length;
 *       byte *data;
 *
 *       Frame (uint32 _length, byte *_data);
 *       virtual ~Frame ();
 *     };
 * </code>
 */
void SimulatedMachine::processFrame(Frame frame, int ifaceIndex) {
	// TODO: process the raw frame; frame.data points to the frame's byte stream
#ifdef DEBUG_MODE
	cout << "Frame received at iface " << ifaceIndex << " with length "
			<< frame.length << endl;
#endif
	uint16_t type = get_frame_type(frame);
#ifdef DEBUG_MODE
	printFrame(frame.data,frame.length);
	cerr << "TYPE: " << type << endl;
#endif
	if ( type != DATA_JOIN_ACK && !IS_CONNECTED ) // drop packet which are not yours since you are not connected.
		return;
	switch ( type ) {
		case DATA_JOIN:			// they are yours or pass to go.
			proccess_join_to_network(this,iface[0],frame);
			break;
		case DATA_JOIN_ACK:		// they are just yours and you should inform your successor.
			// you are now really connected:
			IS_CONNECTED = true;
			get_data_join_ack_info(this,iface[0],frame);
			JOINING_PART = false;
			break;
		case DATA_PUT_PRED:		// they are just yours.
			get_data_put_pred(frame);
			break;
		case DATA_PUT_SUCC:		// they are just yours.
			get_data_put_succ(frame);
			break;
		case DATA_PUT_FILE:		// they are yours or pass to go.
			proccess_put_to_network(this,iface[0],frame);
			break;
		case DATA_GET_FILE:		// they are yours or pass to go.
			proccess_get_from_network(this,iface[0],frame);
			break;
		case DATA_GET_FILE_ACK:	// they are yours.
			get_data_ack(frame);
			break;
		default:
			break;
	}
#ifdef DEBUG_MODE
	cerr << "Current State" << endl;
	cerr << "SUCCESSOR_IP: " << successor_ip << endl;
	cerr << "PREDECESSOR_IP: " << predecessor_ip << endl;
	cerr << "FILES: " << endl;
	for ( int i = 0 ; i < fileEntry.size() ; i++)
		cerr << fileEntry[i].filename << endl;
#endif 
}

/**
 * This method will be run from an independent thread. Use it if needed or simply return.
 * Returning from this method will not finish the execution of the program.
 */
void SimulatedMachine::run() {
	// TODO: write your business logic here...
	string input; 
	while ( true ){
		cin >> input;
		if ( input == "join" ){
			join_to_network(this,iface[0]);
		}else if ( input == "put"){
			FileEntry f;
			cin >> f.filename >> f.ip >> f.port;
			put_to_network(this,iface[0],f);
		}else if ( input == "get"){
			string filename;
			cin >> filename;
			get_from_network(this,iface[0],filename,htonl(iface[0].getIP()));
		}else if ( input == "leave"){
			leave(this,iface[0]);
		}else if ( input == "print") {
			cout << "successor-ip= " << successor_ip << endl;
			cout << "predecessor-ip= " << predecessor_ip << endl;
			cout << "table: "<<endl;
			for ( int i = 0 ; i < fileEntry.size();i++)
				cout << fileEntry[i].filename <<"\t"<< fileEntry[i].ip <<"\t" << fileEntry[i].port << endl;
		}else if ( input == "exit"){
			exit(0);
		}
	}
}

/**
 * You could ignore this method if you are not interested on custom arguments.
 */
void SimulatedMachine::parseArguments(int argc, char *argv[]) {
	// TODO: parse arguments which are passed via --args
}

