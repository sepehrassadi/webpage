#include "common.h"
#include "stdio.h"

#include "sm.h"
#include "interface.h"

#include <stdlib.h>
#include <openssl/sha.h>

using namespace std;

// implementation of your utilities ...

