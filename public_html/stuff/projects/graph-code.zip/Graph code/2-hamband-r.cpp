#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
#define N 1000
#define pb push_back
vector<int> V[N];
int n,e,t=1;
int low[N],ch[N],p[N],ccount[N],part[N];
bool cut[N];

void dfs(int v){
	ch[v] = low[v] = t ;
	for ( int i = 0 ; i < V[v].size() ; i++){
		int u = V[v][i];
		t++;
		if ( !ch[u] ){
			ccount[v]++;
			p[u] = v;
			dfs(u);
			low[v] = min ( low[v],low[u]);
		}
		else if ( p[v] != u ){
			low[v] = min ( low[v] , ch[u] );
		}
		t--;
	}
	if ( low[v] == ch[v] && ccount[v] )
		cut[v] = true;
}
void dfs2(int v){
	if ( cut[v] )
		return;
	ch[v] = 1;
	part[v] = t;
	for ( int i = 0 ; i < V[v].size() ; i++)
		if ( !ch[V[v][i]])
			dfs2(V[v][i]);
}
int main(){
	cin >> n >> e;
	fill(ch,ch+n,0);
	fill(low,low+n,N);
	fill(ccount,ccount+n,0);
	for ( int i = 0 ; i < e ;i++){
		int a,b;
		cin >> a >> b ;
		a--;b--;
		V[a].pb(b);
		V[b].pb(a);
	}
	for ( int i = 0 ; i < n ; i++){
		if ( !ch[i] ){
			dfs(i);
			if ( ccount[i] == 1 )
			cut[i] = false;
		}
	}
	fill(ch,ch+n,0);
	t = 0;
	for ( int i = 0 ; i < n ; i++){
		if ( cut[i] ){
			part[i] = t++;
			continue;
		}
		if ( !ch[i] ){
			dfs2(i);
			t++;
		}
				
	}
	for ( int i = 0 ; i < n ; i++)
		cout << cut[i] << ' ' ;
	cout << endl;
	for ( int i = 0 ; i < n ; i++)
		cout << part[i] << ' ';
	cout << endl;
	return 0;
}

