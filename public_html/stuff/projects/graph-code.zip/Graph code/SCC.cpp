#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
#define N 1000
#define pb push_back
pair<int,int> f[N];
vector<int> V1[N];
bool ch1[N]={false};
int t=0;
void dfs1(int v){
	ch1[v] = true;
	for ( int i = 0 ; i < V1[v].size() ; i++)
		if ( !ch1[V1[v][i]] )
			dfs1(V1[v][i]);
	f[v].first = t++;
	f[v].second = v;
}
vector<int> V2[N];
bool ch2[N]={false};
int part[N];
int counter=0;
void dfs2(int v){
	ch2[v] = true;
	part[v] = counter;
	for ( int i = 0 ; i < V2[v].size() ; i++)
		if ( !ch2[V2[v][i]] )
			dfs2(V2[v][i]);
}
int main(){
	int n,e;
	cin >> n >> e;
	for ( int i = 0 ; i < e ; i++){
		int a,b;
		cin >> a >> b ; a--;b--;
		V1[a].pb(b);
	}
	for ( int i = 0 ; i < n ; i++)
		if ( !ch1[i])
			dfs1(i);
	sort(f,f+n);
	cout << "FIRST" << endl;
	for ( int i = 0 ; i < n ; i++)
		for ( int j = 0 ; j < V1[i].size() ; j++)
			V2[V1[i][j]].pb(i);
	cout << "SECOND" << endl;
	for ( int i = n-1 ; i>=0 ; i--)
		if ( !ch2[f[i].second]){
			dfs2(f[i].second);
			counter++;
		}
	for ( int i = 0 ; i < n ; i++)
		cout << part[i] << ' ';
	cout << endl;
	return 0;
}

