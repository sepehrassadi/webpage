#include <iostream>
#include <vector>
using namespace std;
#define N 100
vector<int> V[N];
int ch[N] ={0};
void dfs(int v){
	cout << v << endl;
	ch[v] = 1 ;
	for ( int i = 0; i < V[v].size() ; i++)
		if( ch[V[v][i]] == 0 )
			dfs(V[v][i]);
	
}
int main(){
	return 0;
}
