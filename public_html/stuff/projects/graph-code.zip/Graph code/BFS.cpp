#include <iostream>
#include <queue>
#include <vector>
using namespace std;
#define N 100
#define pb push_back

vector<int> V[N];
bool ch[N]={0};
int d[N];
int parent[N];
void bfs(){
	queue<int> Q;
	parent[0] = -1;
	ch[0]=true;
	d[0] = 0 ;
	Q.push(0);
	while ( !Q.empty()){
		int v = Q.back(); Q.pop();
		cout << v << endl;
		for ( int i = 0 ; i < V[v].size() ;i++){
			if ( ch[V[v][i]] == false ){
				ch[V[v][i]] = true;
				Q.push(V[v][i]);
				parent[V[v][i]] = v ;
				d[V[v][i]] = d[v] + 1 ;
			}

		}
	}
}
int main(){
	int n,e;
	cin >> n >> e;
	for ( int i = 0 ; i < e ; i++){
		int a,b;
		cin >> a >> b ; 
		a--;b--;
		V[a].pb(b);
		V[b].pb(a);
	}
	bfs();
	for ( int i = 0 ; i < n ; i++)
		cout << d[i] << ' ' ;
	cout << endl;
	return 0;
}

