#include <iostream>
#include <cmath>
using namespace std;
#define N 1000
#define pb push_back
#define INF 0xffff
int w[N][N],l[N][N];
int main(){
	int n,e;
	cin >> n >> e;
	for ( int i = 0 ; i < n ; i++)
		for ( int j = 0 ; j < n ; j++)
			l[i][j] = w[i][j] = INF;
	for ( int i = 0 ; i < e ; i++){
		int a,b,c;
		cin >> a >> b >> c ;
		a--;b--;
		w[a][b]=l[a][b] = c;
		w[b][a]=l[b][a] = c;
	}
	for ( int k = 0 ; k < n ; k++)
		for ( int i = 0 ; i < n ; i++)
			for ( int j = 0 ; j < n ; j++)
				l[i][j] = ( i==j ? 0 :  min(l[i][j],l[i][k]+l[k][j]) );
	for ( int i = 0 ; i < n ; i++){
		for ( int j = 0 ; j < n ; j++)
			cout << l[i][j] << ' ' ;
		cout << endl;
	}
	return 0;
}

