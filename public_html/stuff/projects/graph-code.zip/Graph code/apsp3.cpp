#include <iostream>
#include <cmath>
using namespace std;
#define N 1000
#define INF 0xffff
int w[N][N],l1[N][N],l2[N][N];
int n,e;
void apsp(){
	for ( int i = 0 ; i < n ; i++)
		for ( int j = 0 ; j < n ; j++){
			l2[i][j] = 0;
			for ( int k = 0 ; k < n ; k++)
				l2[i][j]+= l1[i][k]*w[k][j];
		}
	for ( int i = 0 ; i < n ; i++)
		for ( int j = 0 ; j < n ; j++)
			l1[i][j] = l2[i][j];
}
int main(){
	cin >> n >> e;
	for ( int i = 0 ; i < n ; i++)
		for ( int j = 0 ; j < n ; j++)
			w[i][j] = l1[i][j] = 0;
	for ( int i = 0 ; i < e; i++){
		int a,b,c;
		cin >> a>>b>>c;
		a--;b--;
		w[a][b] = w[b][a] = l1[a][b] = l1[b][a] = c;
	}
	for ( int i = 0 ; i < n-1 ; i++)
		apsp();
	for ( int i = 0 ; i < n ; i++){
		for ( int j = 0 ; j < n ; j++)
			cout << ( i == j ? 0 : l1[i][j] ) << ' ' ;
		cout << endl;
	}
	return 0;
}
