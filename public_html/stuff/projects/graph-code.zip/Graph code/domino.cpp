#include <iostream>
#include <vector>
using namespace std;
#define N (6)
#define pb push_back

int V[N][N]={{0}};
int n;
typedef pair<int,int> Edge;
vector<Edge> domino;

bool check(){
	for ( int i = 0 ; i < N ; i++){
		int sum = 0 ;
		for ( int j = 0 ; j < N ; j++)
			sum+=V[i][j];
		if ( sum % 2 )
			return true;
	}
	return false;
}
void dfs(int v){
	for ( int i = 0 ; i < N ; i++)
		if ( V[v][i] ){
			Edge e;e.first=v+1;e.second=i+1;
			domino.pb(e);
			V[v][i]--;
			V[i][v]--;
			dfs(i);
		}
}
int main(){
	cin >>n ;
	for ( int i = 0 ; i < n ; i++){
		int a,b;
		cin >> a >> b ; a--;b--;
		V[a][b]++;
		V[b][a]++;
	}
	if ( check()){
		cout << "Impossible" << endl;
		return 0;
	}
	dfs(0);
	for ( int i = 0 ; i < domino.size();i++)
		cout << domino[i].first << ' ' << domino[i].second << endl;
	return 0;
}

