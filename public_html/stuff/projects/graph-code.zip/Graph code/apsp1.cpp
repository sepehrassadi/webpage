#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
#define N 1000
#define INF 0xffff
#define pb push_back

int n,e;
int l1[N][N],l2[N][N],w[N][N];
int d[N];
void apsp(){
	for ( int i = 0 ; i < n ; i++){
		for ( int j = 0 ; j < n ; j++){
			l2[i][j] = l1[i][j];
			for ( int k = 0 ; k < n ; k++){
				l2[i][j] = min ( l2[i][j],l1[i][k]+w[k][j]);
			}
		}
	}
	for ( int i = 0 ; i < n ; i++)
		for ( int j = 0 ; j < n ; j++)
			l1[i][j] = l2[i][j];
}
int main(){
	cin >> n >> e;
	for ( int i = 0 ; i < n ; i++)
		for ( int j = 0 ; j < n ; j++)
			l1[i][j] = w[i][j] = INF;
	for ( int i = 0 ; i < e ; i++){
		int a,b,c;
		cin >> a >> b >> c; a--;b--;
		l1[a][b] = w[a][b] = c;
		l1[b][a] = w[b][a] = c;
	}
	for ( int i = 0 ; i < n ; i++)
		apsp();
	for ( int i = 0 ; i < n ; i++){
		for ( int j = 0 ; j < n ; j++)
			cout << l1[i][j] << ' ';
		cout << endl;
	}
	return 0;
}

