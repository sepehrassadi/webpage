package edu.sharif.mir.crawler.content;

import org.junit.Assert;
import org.junit.Test;

import java.util.List;

/**
 * @author Mohammad Milad Naseri (m.m.naseri@gmail.com)
 * @since 1.0 (4/22/12, 16:37)
 */
public class SimilarityAnalyzerTest {

    @Test
    public void test() throws Throwable{
        final ContentAnalyzer analyzer = new DefaultContentAnalyzer();
        final List<Shingle> firstShingles =  analyzer.getShingles("sepehr salam khoobi $");
        final List<Shingle> secondShingles = analyzer.getShingles("sepehr agha salam $");
        System.out.println(firstShingles);
        System.out.println(secondShingles);
        System.out.println(analyzer.getSimilarityRatio(firstShingles,secondShingles));
    }
    @Test
    public void analyzeDissimilarContentTest() throws Exception {
        final ContentAnalyzer analyzer = new DefaultContentAnalyzer();
        final List<Shingle> firstShingles = analyzer.getShingles("a b c d e f g");
        final List<Shingle> secondShingles = analyzer.getShingles("h i j k l m n");
        Assert.assertFalse(firstShingles.isEmpty());
        Assert.assertFalse(secondShingles.isEmpty());
        Assert.assertEquals(0d, analyzer.getSimilarityRatio(firstShingles, secondShingles), 0.0001);
    }

    @Test
    public void analyzeDuplicateContentTest() throws Exception {

        final ContentAnalyzer analyzer = new DefaultContentAnalyzer();
        final List<Shingle> firstShingles = analyzer.getShingles("a b c d e f g");
        final List<Shingle> secondShingles = analyzer.getShingles("a b c d e f g");
        Assert.assertFalse(firstShingles.isEmpty());
        Assert.assertFalse(secondShingles.isEmpty());
        Assert.assertEquals(1d, analyzer.getSimilarityRatio(firstShingles, secondShingles), 0.0001);
    }

    @Test
    public void analyzeSemiSimilarContentTest() throws Exception {

        final ContentAnalyzer analyzer = new DefaultContentAnalyzer();
        final List<Shingle> firstShingles = analyzer.getShingles("a b c d e f g");
        final List<Shingle> secondShingles = analyzer.getShingles("a b c d h i j k");
        Assert.assertFalse(firstShingles.isEmpty());
        Assert.assertFalse(secondShingles.isEmpty());
        Assert.assertTrue(analyzer.getSimilarityRatio(firstShingles, secondShingles) > 0);
        Assert.assertEquals(analyzer.getSimilarityRatio(firstShingles, secondShingles), analyzer.getSimilarityRatio(secondShingles, firstShingles),0.1f);
    }

}
