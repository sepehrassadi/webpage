package edu.sharif.mir.crawler.scanner;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Mohammad Milad Naseri (m.m.naseri@gmail.com)
 * @since 1.0 (4/22/12, 16:13)
 */
public class TextResourceScanner implements ResourceScanner {

    private final ArrayList<URL> urls;

    public TextResourceScanner(String resource) throws MalformedURLException {
        final Matcher matcher = Pattern.compile("(?:https?|ftp|file)://\\S+", Pattern.DOTALL | Pattern.MULTILINE).matcher(resource);
        urls = new ArrayList<URL>();
        while (matcher.find()) {
            urls.add(new URL(matcher.group(0)));
        }
    }

    @Override
    public List<URL> getCandidateUrls() {
        return urls;
    }

}
