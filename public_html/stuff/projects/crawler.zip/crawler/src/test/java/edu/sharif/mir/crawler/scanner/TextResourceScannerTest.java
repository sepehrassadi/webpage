package edu.sharif.mir.crawler.scanner;

import org.junit.Assert;
import org.junit.Test;

import java.net.URL;

/**
 * @author Mohammad Milad Naseri (m.m.naseri@gmail.com)
 * @since 1.0 (4/22/12, 16:03)
 */
public class TextResourceScannerTest {

    @Test
    public void scanTextResourceWithoutAnchorsTest() throws Exception {
        final ResourceScanner scanner = new TextResourceScanner("This is a test");
        Assert.assertTrue(scanner.getCandidateUrls().isEmpty());
    }

    @Test
    public void scanTextResourceWithAnchorsTest() throws Exception {
        final ResourceScanner scanner = new TextResourceScanner("Hello file:///var/www/index.html " +
                "to ftp://cabinet.ce.sharif.edu/");
        Assert.assertEquals(2, scanner.getCandidateUrls().size());
    }

}
