package edu.sharif.mir.crawler.url;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author Mohammad Milad Naseri (m.m.naseri@gmail.com)
 * @since 1.0 (4/22/12, 15:34)
 */
public class UrlParserTest {

    @Test
    public void simpleUrlTest() throws Exception {
        final UrlParser parser = new SimpleUrlParser("http://www.domain.com");
        Assert.assertEquals(parser.toString(), parser.toURI().toString());
        Assert.assertEquals(parser.toString(), parser.toURL().toString());
        Assert.assertEquals(Protocol.HTTP, parser.getProtocol());
        Assert.assertEquals("www.domain.com", parser.getDomain());
        Assert.assertEquals(Protocol.HTTP.getPort(), parser.getPort());
        Assert.assertEquals("/", parser.getContext());
        Assert.assertEquals(null, parser.getQueryString());
        Assert.assertEquals(null, parser.getAnchor());
        Assert.assertEquals("http://www.domain.com:80/", parser.getRoot());
    }

    @Test
    public void parseUrlTest() throws Exception {
        final UrlParser parser = new SimpleUrlParser("https://a.b.domain.com:90/some/context/path?id=1&var=xyz#anchor");
       // Assert.assertEquals(parser.toString(), parser.toURI().toString());
       // Assert.assertEquals(parser.toString(), parser.toURL().toString());
        Assert.assertEquals(Protocol.HTTPS, parser.getProtocol());
        Assert.assertEquals("a.b.domain.com", parser.getDomain());
        Assert.assertEquals(90, parser.getPort());
        Assert.assertEquals("/some/context/path", parser.getContext());
        Assert.assertEquals("id=1&var=xyz", parser.getQueryString());
        Assert.assertEquals("anchor", parser.getAnchor());
        Assert.assertEquals("https://a.b.domain.com:90/", parser.getRoot());
    }

}
