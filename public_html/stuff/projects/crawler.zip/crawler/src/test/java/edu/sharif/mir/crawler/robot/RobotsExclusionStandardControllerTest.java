package edu.sharif.mir.crawler.robot;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author Mohammad Milad Naseri (m.m.naseri@gmail.com)
 * @since 1.0 (4/22/12, 15:47)
 */
public class RobotsExclusionStandardControllerTest {

    @Test
    public void controlRobotExistsTest() throws Exception {
        final RobotController controller = new DefaultRobotController("User-agent: NPBot\n" +
                "Disallow: /");
        Assert.assertTrue(controller.knows("NPBot"));
        Assert.assertFalse(controller.knows("NPBot2"));
    }

    @Test
    public void allowedTest() throws Exception {
        final RobotController controller = new DefaultRobotController("User-agent: NPBot\n" +
                "Disallow: /\n" +
                "Allow: /abc/");
        Assert.assertTrue(controller.isAllowed("MyAgent", "/"));
        Assert.assertTrue(controller.isAllowed("NPBot", "/abc/123"));
    }

    @Test
    public void disallowedTest() throws Exception {
        final RobotController controller = new DefaultRobotController("User-agent: NPBot\n" +
                "Disallow: /\n" +
                "Allow: /abc/");

        Assert.assertFalse(controller.isAllowed("NPBot", "/a/123"));
        Assert.assertFalse(controller.isAllowed("NPBot", "/"));
    }

    @Test
    public void disallowAllTest() throws Exception {
        final RobotController controller = new DefaultRobotController("User-agent: *\n" +
                "Disallow: /");
        Assert.assertFalse(controller.isAllowed("MyAgent", "/"));
        Assert.assertFalse(controller.isAllowed("google-bot", "/wiki/"));
        Assert.assertFalse(controller.isAllowed("wget", "/"));
    }

}
