package edu.sharif.mir.crawler.scanner;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author Mohammad Milad Naseri (m.m.naseri@gmail.com)
 * @since 1.0 (4/22/12, 16:23)
 */
public class WebResourceScannerTest {

    @Test
    public void resourceWithoutAnchorsTest() throws Exception {
        final ResourceScanner scanner = new WebResourceScanner("http://www.domain.com/page.html", "<a href='#hello'></a>");
        Assert.assertTrue(scanner.getCandidateUrls().isEmpty());
    }

    @Test
    public void resourceWithAbsoluteAnchorsTest() throws Exception {
        final ResourceScanner scanner = new WebResourceScanner("http://www.domain.com/page.html", "<a href='http://www.google.com'>A B C</a>" + 
                "<a href='http://www.kernel.org'>D E F</a>");
        Assert.assertFalse(scanner.getCandidateUrls().isEmpty());
        Assert.assertEquals(2, scanner.getCandidateUrls().size());
        Assert.assertEquals("http://www.google.com", scanner.getCandidateUrls().get(0).toString());
        Assert.assertEquals("http://www.kernel.org", scanner.getCandidateUrls().get(1).toString());
    }

    @Test
    public void resourceWithRelativeAnchorsTest() throws Exception {
        final ResourceScanner scanner = new WebResourceScanner("http://www.domain.com/page1.html", "<a href='abc/page2.html'>A B C</a>" +
                "<a href='page3.html'>D E F</a>");
        Assert.assertFalse(scanner.getCandidateUrls().isEmpty());
        Assert.assertEquals(2, scanner.getCandidateUrls().size());
        Assert.assertEquals("http://www.domain.com/abc/page2.html", scanner.getCandidateUrls().get(0).toString());
        Assert.assertEquals("http://www.domain.com/page3.html", scanner.getCandidateUrls().get(1).toString());
    }

}
