package edu.sharif.mir.crawler.crawler;

import edu.sharif.mir.crawler.crawler.DataBase.CrawlerDataBaseHandler;
import edu.sharif.mir.crawler.crawler.crawler.Crawler;
import edu.sharif.mir.crawler.crawler.crawler.ThreadSafeCrawler;
import edu.sharif.mir.crawler.crawler.url.NoPriorityURL;
import edu.sharif.mir.crawler.crawler.url.PriorityURL;
import edu.sharif.mir.crawler.crawler.url.SimpleURLHandler;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;

/**
 * @author Mohammad Milad Naseri (m.m.naseri@gmail.com)
 * @since 1.0 (4/22/12, 15:34)
 */
public class CrawlerTest {


    public void crawlerTest() throws Exception{
        Collection<PriorityURL> seeds = new ArrayList<PriorityURL>();
        seeds.add(new NoPriorityURL(new URL("http://en.wikipedia.org/wiki/Main%20Page")));

        Class urlHandlerClass = SimpleURLHandler.class;
        Class dataHandlerClass = CrawlerDataBaseHandler.class;
        Crawler crawler = ThreadSafeCrawler.createNewCrawler(dataHandlerClass,urlHandlerClass,"test", seeds,1,1);
        //Crawler crawler = ThreadSafeCrawler.createNewCrawlerWithRandomSeeds(dataHandlerClass,urlHandlerClass,"test",100,1000);
        
        //Crawler crawler = ThreadSafeCrawler.resumeCrawlerFromSmallDataBase(dataHandlerClass,urlHandlerClass,"test",100,1000);
        crawler.crawl();

        /*
        long beginTime = System.currentTimeMillis();
    //    ThreadSafeCrawler crawler = ThreadSafeCrawler.resumeCrawler(dataHandlerClass,urlHandlerClass, "sepehr",50,100);
        Crawler crawler = ThreadSafeCrawler.resumeCrawlerFromLargeDataBase(dataHandlerClass, urlHandlerClass,"crawler", 50, 30000);
        crawler.turnOffTimeScheduling();
        // This is the Free Downloading time of my ISP.
        // ------------------------------------
        Calendar begin = new GregorianCalendar(2012, Calendar.MAY,14,1,5,0);
        Calendar end = new GregorianCalendar(2012,Calendar.MAY,14,7,45,0);
        //crawler.turnOnTimeScheduling(begin, end);
        // -------------------------------------
        crawler.crawl();
        crawler.turnOffTimeScheduling();

        System.out.println("Crawling finished in: " + (float)(System.currentTimeMillis()-beginTime)/(60*1000) + " Minute");
        */
    }

 

}
