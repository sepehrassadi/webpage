package edu.sharif.mir.crawler.crawler.crawler;

import edu.sharif.mir.crawler.crawler.url.PriorityURL;

import java.util.Calendar;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: sepehr
 * Date: 4/29/12
 * Time: 10:30 PM
 * To change this template use File | Settings | File Templates.
 */
public interface Crawler {
    // Set these url as seeds. ( In priority agenda, probably with maximum priority. )
    public void setSeeds(Collection<PriorityURL> seeds);
    // Crawl based on current seeds.
    public void crawl();
    // Crawl with a collection of extra urls.
    public void crawl(Collection<PriorityURL> newUrls);
    // Turn of Time Scheduling
    public void turnOnTimeScheduling(Calendar begin,Calendar end);
    // Turn of Time Scheduling
    public void turnOffTimeScheduling();
}
