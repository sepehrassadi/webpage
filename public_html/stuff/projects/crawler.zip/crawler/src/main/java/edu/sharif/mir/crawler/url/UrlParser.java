package edu.sharif.mir.crawler.url;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

/**
 * @author Mohammad Milad Naseri (m.m.naseri@gmail.com)
 * @since 1.0 (4/22/12, 15:41)
 */
public interface UrlParser {

    Protocol getProtocol();

    String getDomain();

    String getContext();

    String getQueryString();

    String getAnchor();

    URI toURI() throws URISyntaxException;

    URL toURL() throws URISyntaxException, MalformedURLException;

    int getPort();

    String getRoot();
}
