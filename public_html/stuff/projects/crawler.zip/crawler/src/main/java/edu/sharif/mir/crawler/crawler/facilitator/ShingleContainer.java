package edu.sharif.mir.crawler.crawler.facilitator;

import edu.sharif.mir.crawler.content.Shingle;

import java.io.Serializable;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sepehr
 * Date: 4/25/12
 * Time: 11:29 AM
 * To change this template use File | Settings | File Templates.
 */
public class ShingleContainer implements Serializable {
    private final String name;
    private final List<Shingle> list;
    
    public ShingleContainer(String name,List<Shingle> list){
        this.name = name;
        this.list = list;
    }
    
    public String getName(){
        return name;
    }
    public List<Shingle> getShingleList(){
        return list;
    }
}
