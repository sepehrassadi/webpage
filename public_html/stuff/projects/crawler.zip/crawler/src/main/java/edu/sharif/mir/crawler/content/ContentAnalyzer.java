package edu.sharif.mir.crawler.content;

import java.util.List;

/**
 * @author Mohammad Milad Naseri (m.m.naseri@gmail.com)
 * @since 1.0 (4/22/12, 16:40)
 */
public interface ContentAnalyzer {

    List<Shingle> getShingles(String text);

    float getSimilarityRatio(List<Shingle> first, List<Shingle> second);


}
