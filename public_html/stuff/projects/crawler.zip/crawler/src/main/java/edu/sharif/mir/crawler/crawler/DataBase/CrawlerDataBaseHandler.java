package edu.sharif.mir.crawler.crawler.DataBase;

import edu.sharif.ce.mir.dal.DataSource;
import edu.sharif.ce.mir.dal.DataStorage;
import edu.sharif.ce.mir.dal.data.Entity;
import edu.sharif.ce.mir.dal.data.LargeText;
import edu.sharif.ce.mir.dal.data.PrimaryKeyText;
import edu.sharif.ce.mir.dal.impl.MySqlDataStorage;
import edu.sharif.mir.crawler.crawler.crawler.ThreadSafeCrawler;
import edu.sharif.mir.crawler.crawler.url.SimpleURLHandler;
import edu.sharif.mir.crawler.crawler.url.URLHandler;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sepehr
 * Date: 4/24/12
 * Time: 3:52 PM
 * To change this template use File | Settings | File Templates.
 */

public class CrawlerDataBaseHandler extends DataHandler{

    private DataStorage db = null;
    private final DataSource pageDataSource;
    private final DataSource similarityDataSource = new PageSimilarityDataSource();
    private final String name;
    private final int related_hash;

    public CrawlerDataBaseHandler(){
        this("test",0);
    }
    public CrawlerDataBaseHandler(String name,Integer hash){
        super(name);
        
        this.name = name;
        this.related_hash = hash;
        this.pageDataSource = new PageDataSource(related_hash);
        this.db = new MySqlDataStorage("localhost",this.name,"root","password");

    }

    @Override
    public void openConnection(){
        db.connect();
    }
    @Override
    public void closeConnection(){
        db.disconnect();
    }
    @Override
    public void prepareData(){
        // comment this lines to have access to this feature.
       /* if ( true )
            throw new Error("You are going to corrupt all the data gathered till now! Are you sure??");
       */
        createPageTable();
        createSimilarityTable();
    }
    @Override
    public void clearData(){
        // comment this lines to have access to this feature.
       /* if ( true )
            throw new Error("You are going to corrupt all the data gathered till now! Are you sure??");
        */
        db.dropTable(pageDataSource);
        db.dropTable(similarityDataSource);
    }
    private void createPageTable(){
        db.createTable(pageDataSource);
        db.alterPrimaryKey(pageDataSource);
    }
    
    private void createSimilarityTable(){
        db.createTable(similarityDataSource);
        StringBuffer primaryKey = new StringBuffer();
        primaryKey.append("ALTER TABLE ").append(similarityDataSource.getTable()).
        append(" ADD CONSTRAINT ").append(similarityDataSource.getPrimaryKey().getName()).
        append(" PRIMARY KEY ( url1,url2 )");
     /*   StringBuffer foreignKey1 = new StringBuffer();
        foreignKey1.append("ALTER TABLE ").append(similarityDataSource.getTable()).append(" ADD FOREIGN KEY (url1) REFERENCES ").append(pageDataSource.getTable()).append("(").append(pageDataSource.getPrimaryKey().getName()).append(");");
        StringBuffer foreignKey2 = new StringBuffer();
        foreignKey2.append("ALTER TABLE ").append(similarityDataSource.getTable()).append(" ADD FOREIGN KEY (url2) REFERENCES ").append(pageDataSource.getTable()).append("(").append(pageDataSource.getPrimaryKey().getName()).append(");");
     */
        db.executeRawCommand(primaryKey.toString());
      //  db.executeRawCommand(foreignKey1.toString());
      //  db.executeRawCommand(foreignKey2.toString());

    }
    
    public void insertSimilarity(String urlname1,String urlname2,Float sim){
        Entity entity = new Entity(similarityDataSource).set("url1",new PrimaryKeyText(getURLDataBaseName(urlname1))).set("url2",new PrimaryKeyText(getURLDataBaseName(urlname2))).set("similarity", sim);

        db.insert(entity);
    }
    // Before the data base became massively large, this function was used to return all the visited urls.
    // Now it just returns a fraction of data base to be used as seed further on.
    @Override
    public ArrayList<String> getVisitedUrls() {
        StringBuffer command = new StringBuffer();

        // The first command used to get all the data base.
        command.append("SELECT ").append(pageDataSource.getPrimaryKey().getName()).append(" FROM ").append(pageDataSource.getTable());

        // Current Comment used to get just seeds. and added to previous ones.
        command.append(" ORDER BY RAND() LIMIT ").append(ThreadSafeCrawler.DATABASE_SEED_COUNT);

        // An entity should pass to the data base to fill its (desired) field with data.
        Entity entity = new Entity(pageDataSource);
        entity.set(pageDataSource.getPrimaryKey().getName(),new PrimaryKeyText("desired"));
        List<Entity> list = db.executeRawQuery(command.toString(),entity);

        ArrayList<String> ret = new ArrayList<String>();
        System.out.println("Fetched From DataBase");
        for ( Entity ent : list)
            ret.add(ent.get(pageDataSource.getPrimaryKey().getName()).toString());
        return ret;
    }
    
    public boolean isVisitedUrl(String urlName) {
        return ( getUrlData(urlName) != null );
    }

    
    public Entity getUrlData(String urlName){
        Entity ent = new Entity(pageDataSource);
        ent.set(pageDataSource.getPrimaryKey().getName(),new PrimaryKeyText(urlName));
        return db.select(ent);
    }
    
    public List<String> getSimilarCategory(String urlName){
        Entity data = getUrlData(urlName);
        System.out.println(data.get("name"));
        System.out.println(data.get("page_category1"));

        String cat1 = "'"+data.get("page_category1")+"'";
        String cat2 = "'"+data.get("page_category2")+"'";
        String cat3 = "'"+data.get("page_category3")+"'";

        String command = "SELECT name FROM PAGE_TABLE0 WHERE " +
                "(page_category1 = " + cat1 + " or page_category2 = " + cat1 + " or page_category3 = " + cat1 + ") "+
                "OR (page_category1 = " + cat2 + " or page_category2 = " + cat2 + " or page_category3 = " + cat2 + ") "+
                "OR (page_category1 = " + cat3 + " or page_category2 = " + cat3 + " or page_category3 = " + cat3 + ") ;";

                System.out.println(command);

        // An entity should pass to the data base to fill its (desired) field with data.
        Entity entity = new Entity(pageDataSource);
        entity.set(pageDataSource.getPrimaryKey().getName(),new PrimaryKeyText("desired"));
        List<Entity> list = db.executeRawQuery(command,entity);
        ArrayList<String> ret = new ArrayList<String>();
        for ( Entity ent : list)
            ret.add(getURLNormalName(((PrimaryKeyText) ent.get(pageDataSource.getPrimaryKey().getName())).toString()));

        return ret;
    }
    @Override
    public boolean insertData(URLHandler urlHandler){
        String[] cats = getCategories((String)urlHandler.getData(SimpleURLHandler.Url_Category));
        Entity entity = new Entity(pageDataSource).
                set("name", new PrimaryKeyText(getURLDataBaseName((String)urlHandler.getData(SimpleURLHandler.Url_Name)))).
                set("page_title", urlHandler.getData(SimpleURLHandler.Page_Title)).
                set("last_updated",urlHandler.getData(SimpleURLHandler.Last_Updated_Date)).
                set("permanent_link",urlHandler.getData(SimpleURLHandler.Permanent_Link)).
                set("page_content", new LargeText((String)urlHandler.getData(SimpleURLHandler.Url_Content)));

        for ( int i = 0 ; i < cats.length ; i++){
            if ( cats[i] == null)
                break;
            entity = entity.set("page_category"+new Integer(i+1).toString(),cats[i]);
         }


        return db.insert(entity);
     }
    
    private String[] getCategories(String category){
        String array[] = {null,null,null};
        
        if ( category == null)
            return array;
        
        String cat[] = category.split(", ");
        for ( int i = 0 ; i < cat.length && i < array.length ; i++){
            array[i] = cat[i]; 
        }
        return array;
    }
    
    public static String getURLDataBaseName(String urlName){
        if ( urlName.startsWith(SimpleURLHandler.PREFIX_URL))
            return urlName.substring(SimpleURLHandler.PREFIX_URL.length(),urlName.length());
        return urlName;
    }
    public static String getURLNormalName(String urlName){
    //    return SimpleURLHandler.PREFIX_URL + urlName; for Wikipedia not always:D
        return urlName;
    }


}

