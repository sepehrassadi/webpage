package edu.sharif.mir.crawler.url;

/**
 * @author Mohammad Milad Naseri (m.m.naseri@gmail.com)
 * @since 1.0 (4/22/12, 15:41)
 */
public enum Protocol {
    HTTP(80), HTTPS(443), FTP(21), FILE(686);

    private int port;

    Protocol(int port) {
        this.port = port;
    }

    public int getPort() {
        return port;
    }

    public static Protocol getProtocol(String name) {
        if (name == null) {
            throw new IllegalArgumentException();
        }
        name = name.trim().toLowerCase();
        if (name.equals("http")) {
            return HTTP;
        } else if (name.equals("https")) {
            return HTTPS;
        } else if (name.equals("ftp")) {
            return FTP;
        } else if (name.equals("file")) {
            return FILE;
        }
        throw new IllegalArgumentException("Unknown protocol: " + name);
    }
    
}
