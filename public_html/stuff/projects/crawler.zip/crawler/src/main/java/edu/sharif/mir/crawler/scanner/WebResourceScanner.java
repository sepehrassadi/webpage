package edu.sharif.mir.crawler.scanner;

import edu.sharif.mir.crawler.url.UrlDataContainer;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Mohammad Milad Naseri (m.m.naseri@gmail.com)
 * @since 1.0 (4/22/12, 16:23)
 */
public class WebResourceScanner implements ResourceScanner {

    private List<URL> urls = new ArrayList<URL>();
    private URL url = null;
    private String title = null;
    private String permanentLink = null;
    private String category = null;

    public WebResourceScanner(String url, String resource) throws MalformedURLException {
        this.url = new URL(url);
        UrlDataContainer dataContainer = HTMLParser.getDataOfHTML(new StringReader(resource));
        parseURLDataContainer(dataContainer);
    }

    public WebResourceScanner(String url, InputStream resource) throws MalformedURLException {
        this.url = new URL(url);
        UrlDataContainer dataContainer = HTMLParser.getDataOfHTML(new InputStreamReader(resource));
        parseURLDataContainer(dataContainer);
    }

    @Override
    public List<URL> getCandidateUrls() {
        return urls;
    }
    
    public String getTitle(){
        return this.title;
    }

    public String getPermanentLink(){
        return permanentLink;
    }
    
    public String getCategory(){
        return category;
    }

    private void toURL(List<String> address){
        for (String st:address)    {
            try {
                toURL(st);
            } catch (MalformedURLException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        }
    }
    private void toURL(String address) throws MalformedURLException {

        if ( address.contains("#"))
            return;

        if ( address.startsWith("http") || address.startsWith("https")){
            urls.add(new URL(address));
            return;
        }
        if ( address.startsWith("//")){
            urls.add(new URL("http:"+address));
            return;
        }
        if ( address.startsWith("/")){
            urls.add(new URL(getURLRoot()+address));
            return;
        }

        urls.add(new URL(getURLPath() + "/" + address));
    }
    private String getURLRoot() throws MalformedURLException {
        return url.getProtocol() + "://" + url.getHost();
    }

    private String getURLPath() throws MalformedURLException {
        String end = url.getPath();
        end = end.substring(0,end.lastIndexOf("/"));

        return url.getProtocol() + "://" + url.getHost() + end;
        
    }

    private void parseURLDataContainer(UrlDataContainer container){
        toURL(container.getUrls());
        this.title = container.getTitle();
        this.permanentLink = url.getProtocol() + "://" + url.getHost() + container.getPermanentLink();
        this.category = container.getCategory();
    }
   

    
}
