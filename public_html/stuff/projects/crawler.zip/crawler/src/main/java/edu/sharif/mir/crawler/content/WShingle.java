package edu.sharif.mir.crawler.content;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: sepehr
 * Date: 4/23/12
 * Time: 6:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class WShingle extends  Shingle implements Serializable {

    private String arr[];

    public WShingle(ArrayList<String> input){
        arr = new String[input.size()];
        for ( int i = 0 ; i < input.size() ; i++)
            arr[i] = input.get(i);
    }
    
    public int hashCode(){
        return 1;
    }
    
    @Override
    public boolean equals(Object obj) {
        if ( ! (obj instanceof WShingle) )
            return false;
        WShingle shingle = (WShingle)obj;
        if ( shingle.arr.length != this.arr.length)
            return false;
        for ( int i = 0 ; i < this.arr.length ; i++)
            if ( ! this.arr[i].equals(shingle.arr[i]))
                return false;
        return true;  //To change body of implemented methods use File | Settings | File Templates.
    }
    public String toString(){
        String str = "( " + arr[0];
        for ( int i = 1 ; i < arr.length ; i++)
            str = str + ", " + arr[i];
        return str + " )";
    }
}
