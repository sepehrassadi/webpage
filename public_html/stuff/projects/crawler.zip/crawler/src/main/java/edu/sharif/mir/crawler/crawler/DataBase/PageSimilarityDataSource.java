package edu.sharif.mir.crawler.crawler.DataBase;

import edu.sharif.ce.mir.dal.ColumnMetaData;
import edu.sharif.ce.mir.dal.DataSource;
import edu.sharif.ce.mir.dal.data.PrimaryKeyText;
import edu.sharif.ce.mir.dal.util.Collections;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sepehr
 * Date: 4/25/12
 * Time: 12:45 AM
 * To change this template use File | Settings | File Templates.
 */
public class PageSimilarityDataSource implements DataSource {
    // This table needs more handling than the ones data storage provide so need some raw sql command for
    // better performance supporting the foreign keys and double field primary key.

    public static final String TABLE_NAME = "SIMILARITY_TABLE";

    private final ColumnMetaData pk =               new ColumnMetaData("pk",PrimaryKeyText.class,false);
    private final ColumnMetaData name1 =            new ColumnMetaData("url1", PrimaryKeyText.class, false);
    private final ColumnMetaData name2 =            new ColumnMetaData("url2", PrimaryKeyText.class,false);
    private final ColumnMetaData similarity =       new ColumnMetaData("similarity", Float.class,false);

    @Override
    public List<ColumnMetaData> getColumns() {
        return Collections.list(name1,name2,similarity);
    }

    @Override
    public ColumnMetaData getPrimaryKey() {
        return pk;
    }

    @Override
    public String getTable() {
        return TABLE_NAME;
    }
}
