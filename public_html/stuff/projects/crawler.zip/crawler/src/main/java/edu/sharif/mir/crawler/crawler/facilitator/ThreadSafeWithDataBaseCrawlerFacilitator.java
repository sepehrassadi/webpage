package edu.sharif.mir.crawler.crawler.facilitator;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: sepehr
 * Date: 5/10/12
 * Time: 10:48 PM
 * To change this template use File | Settings | File Templates.
 */
public class ThreadSafeWithDataBaseCrawlerFacilitator extends ThreadSafeCrawlerFacilitator{

    private long visitedCount = 0;

    private Set<String> seeds = new HashSet<String>();
    
    private boolean first = true;

    @Override
    public long getCrawledCount() {
        return visitedCount;
    }

    @Override
    public void addToVisitedURL(String url) {
        visitedCount++;
    }

    @Override
    public boolean isVisitedURL(String url) {
       return false;
    }

    
}
