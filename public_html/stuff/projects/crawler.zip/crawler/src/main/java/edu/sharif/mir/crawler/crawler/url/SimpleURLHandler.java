package edu.sharif.mir.crawler.crawler.url;

import edu.sharif.mir.crawler.scanner.WebResourceScanner;
import edu.sharif.mir.crawler.url.SimpleUrlParser;
import edu.sharif.mir.crawler.url.UrlParser;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

/**
 * Created by IntelliJ IDEA.
 * User: sepehr
 * Date: 4/24/12
 * Time: 10:40 AM
 * To change this template use File | Settings | File Templates.
 */

public class SimpleURLHandler extends URLHandler {

    public final static String PREFIX_URL = "http://en.wikipedia.org/wiki/";

    public static final int Url_Name = 0;
    public static final int Page_Title = 1;
    public static final int Last_Updated_Date = 2;
    public static final int Permanent_Link = 3;
    public static final int Url_Content = 4;
    public static final int Url_Category = 5;

    private static final int RELATED_HASH = 0;


    private UrlParser urlParser;
    private WebResourceScanner webScanner;
    private String content = null;
    private Date date = null;
    private List<PriorityURL> candidateURLs = null;

    public SimpleURLHandler(String url) throws MalformedURLException {
        this(new URL(url));
    }

    public SimpleURLHandler(URL url) throws MalformedURLException{
        super(url);

        urlParser = new SimpleUrlParser(url);
        content = downloadContent();
        date = downloadLastUpdated();
        webScanner = new WebResourceScanner(urlParser.toString(),content);
        candidateURLs = getRelatedURL();
        
    }

    @Override
    public Object getData(int dataNumber) {

        switch(dataNumber){
            case SimpleURLHandler.Url_Name: return getURLName();
            case SimpleURLHandler.Page_Title: return getTitle();
            case SimpleURLHandler.Last_Updated_Date: return getLastDayOfUpdate();
            case SimpleURLHandler.Permanent_Link: return getPermanentLink();
            case SimpleURLHandler.Url_Content: return getContent();
            case SimpleURLHandler.Url_Category: return getCategory();
        }
        return null;
    }

    @Override
    public List<PriorityURL> getCandidateUrls(){
        return candidateURLs;
    }

    @Override
    public URL getUrl() {
        try {
            return this.urlParser.toURL();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return null;
    }


    private String getURLName() {
        return urlParser.toString();
    }


    private Date getLastDayOfUpdate() {
        return date;
    }


    private String getPermanentLink() {
        return webScanner.getPermanentLink();
    }


    private String getTitle(){
        return webScanner.getTitle();
    }


    private String getContent(){
        return content;
    }

    private String getCategory() {
        return webScanner.getCategory();
    }

    private List<PriorityURL> getRelatedURL(){
        List<PriorityURL> array = new ArrayList<PriorityURL>();
        for (URL url: webScanner.getCandidateUrls())
            if ( isRelated(url))
                array.add(new NoPriorityURL(url));
        return array;
    }
    
    private boolean isRelated(URL url){
        // This was added to the source, so that two crawler can be used together.
        //return url.toString().startsWith(PREFIX_URL) && ( url.toString().substring(PREFIX_URL.length(),url.toString().length()).hashCode() % TOTAL_HASH == RELATED_HASH );
        return url.toString().startsWith(PREFIX_URL);
    }
    private Date downloadLastUpdated(){
        try {
            return getLastUpdated(urlParser.toURL());
        } catch (URISyntaxException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String downloadContent(){
        String content = null;
        try {
            content = getContentOfUrl(urlParser.toURL());
        } catch (URISyntaxException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return content;
    }

    public static String inputStreamToString(InputStream stream){
        StringBuffer buffer = new StringBuffer();
        Scanner sc = new Scanner(stream);
        while (sc.hasNext())
           buffer.append(sc.nextLine()+"\n");
        sc.close();
        return buffer.toString();
    }

    public static String getContentOfUrl(URL url){
        Object ob = null;

        try {
            ob = url.getContent();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if ( ob instanceof InputStream)
            return inputStreamToString((InputStream)ob);

        return null;
    }

    public static Date getLastUpdated(URL url){
        URLConnection connection = null;
        try {
            connection = url.openConnection();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return new Date(connection.getLastModified());
    }
}
