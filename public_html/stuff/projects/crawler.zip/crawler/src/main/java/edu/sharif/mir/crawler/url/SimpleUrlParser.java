package edu.sharif.mir.crawler.url;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

/**
 * @author Mohammad Milad Naseri (m.m.naseri@gmail.com)
 * @since 1.0 (4/22/12, 15:42)
 */
public class SimpleUrlParser implements UrlParser {

    private final URL url;

    public SimpleUrlParser(URL url) {
        this(url.toString());
    }

    public SimpleUrlParser(Protocol protocol, String domain, Integer port, String context, String queryString, String anchor) {
        this(protocol + "://" + domain + ":" + port + "/" + context + "?" + queryString + "#" + anchor);

    }
    
    public SimpleUrlParser(String url)  {
        this.url = SimpleUrlParser.standardize(url);
        
    }
    private static URL standardize(String url){
        URL temp = null;
        try {
            temp = new URL(url);
            return temp;
        } catch (MalformedURLException e) {
            return null;
        }

    }
    @Override
    public Protocol getProtocol() {
        return Protocol.getProtocol(this.url.getProtocol());
    }

    @Override
    public String getDomain() {
        return this.url.getHost();
    }

    @Override
    public String getContext() {
       String path =  this.url.getPath();

       return path == "" ? "/" : path;
    }

    @Override
    public String getQueryString() {
        return this.url.getQuery();
    }

    @Override
    public String getAnchor() {
        return this.url.getRef();
    }

    @Override
    public URI toURI() throws URISyntaxException {
        return new URI(this.toString());
    }

    @Override
    public URL toURL() throws URISyntaxException, MalformedURLException {
        return url;
    }

    @Override
    public int getPort() {
        if ( url.getPort() != (-1))
            return url.getPort();
        return this.getProtocol().getPort();
    }

    @Override
    public String getRoot() {
        return this.getProtocol().toString().toLowerCase() +"://"+this.url.getHost()+":"+this.getPort()+"/";
    }

    @Override
    public String toString() {
        String end = url.getPath();
        return url.getProtocol() + "://" + url.getHost() + end;
    }

}
