package edu.sharif.mir.crawler.content;

/**
 * @author Mohammad Milad Naseri (m.m.naseri@gmail.com)
 * @since 1.0 (4/22/12, 16:41)
 */
public abstract class Shingle {
    
    public abstract boolean equals(Object obj);

}
