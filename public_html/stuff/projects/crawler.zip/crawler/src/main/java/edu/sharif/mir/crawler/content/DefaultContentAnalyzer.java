package edu.sharif.mir.crawler.content;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author Mohammad Milad Naseri (m.m.naseri@gmail.com)
 * @since 1.0 (4/22/12, 16:42)
 */
public class DefaultContentAnalyzer implements ContentAnalyzer {
    public static int Shingle_Count = 2;
    
    @Override
    public List<Shingle> getShingles(String text) {
        String array[] = text.split(" ");
        List<Shingle> list = new ArrayList<Shingle>();
        
        for (int i = 0 ; i < array.length - Shingle_Count ; i++){
            ArrayList<String> tuple = new ArrayList<String>();
            for ( int j = 0 ; j < Shingle_Count ; j++){
                tuple.add(array[i+j]);
            }
            list.add(new WShingle(tuple));
        }
        return list;
    }

    @Override
    public float getSimilarityRatio(List<Shingle> first, List<Shingle> second) {
        Set<Shingle> fset = new HashSet<Shingle>();
        Set<Shingle> sset = new HashSet<Shingle>();
        
        fset.addAll(first);
        sset.addAll(second);
        int intersectCount = 0;
        
        for ( Shingle sh : fset){

            if ( sset.contains(sh)) {
                intersectCount++;
            }
        }
        int unionCount = fset.size() + sset.size() - intersectCount;
        return (float)intersectCount/unionCount;
    }

}
