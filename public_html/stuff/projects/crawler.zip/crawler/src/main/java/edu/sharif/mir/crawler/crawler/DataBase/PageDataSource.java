package edu.sharif.mir.crawler.crawler.DataBase;

import edu.sharif.ce.mir.dal.ColumnMetaData;
import edu.sharif.ce.mir.dal.DataSource;
import edu.sharif.ce.mir.dal.data.LargeText;
import edu.sharif.ce.mir.dal.data.PrimaryKeyText;
import edu.sharif.ce.mir.dal.util.Collections;

import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sepehr
 * Date: 4/24/12
 * Time: 3:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class PageDataSource implements DataSource {

    public static final String TABLE_NAME = "PAGE_TABLE";

    private final ColumnMetaData name =             new ColumnMetaData("name", PrimaryKeyText.class, false);
    private final ColumnMetaData title =            new ColumnMetaData("page_title", String.class,false);
    private final ColumnMetaData last_updated =     new ColumnMetaData("last_updated", Date.class,false);
    private final ColumnMetaData permanent_link =   new ColumnMetaData("permanent_link", String.class,false);
    private final ColumnMetaData page_content =     new ColumnMetaData("page_content", LargeText.class,false);
    private final ColumnMetaData category1 =     new ColumnMetaData("page_category1",String.class);
    private final ColumnMetaData category2 =     new ColumnMetaData("page_category2",String.class);
    private final ColumnMetaData category3 =     new ColumnMetaData("page_category3",String.class);
    
    private final List<ColumnMetaData> columns = Collections.list(name,title,last_updated,permanent_link,page_content,category1,category2,category3);
    private final int related_hash;
    public PageDataSource(int hash){
           related_hash = hash;
    }
    @Override
    public List<ColumnMetaData> getColumns() {
        return columns;
    }

    @Override
    public ColumnMetaData getPrimaryKey() {
        return name;
    }

    @Override
    public String getTable() {
        return TABLE_NAME+related_hash;
    }
}
