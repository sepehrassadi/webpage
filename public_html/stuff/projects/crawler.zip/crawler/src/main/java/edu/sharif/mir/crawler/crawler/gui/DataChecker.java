package edu.sharif.mir.crawler.crawler.gui;

import edu.sharif.ce.mir.dal.data.Entity;
import edu.sharif.mir.crawler.content.ContentAnalyzer;
import edu.sharif.mir.crawler.content.DefaultContentAnalyzer;
import edu.sharif.mir.crawler.content.Shingle;
import edu.sharif.mir.crawler.crawler.DataBase.CrawlerDataBaseHandler;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.StringReader;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sepehr
 * Date: 5/1/12
 * Time: 12:59 PM
 * To change this template use File | Settings | File Templates.
 */
public class DataChecker{
    private JPanel panel1;


    private JFormattedTextField formattedTextField2;
    private JButton searchButton;
    private JTextPane textPane1;
    private JTextArea pageTitle;
    private JTextArea lastUpdated;
    private JTextArea permanentLink;
    private JTextArea categories;
    private JTabbedPane tabedPane;
    private JButton checkSimilarityButton;
    private JFormattedTextField url1;
    private JFormattedTextField url2;
    private JTextPane urlPane2;
    private JTextPane urlPane1;
    private JTextArea similarityPane;
    private JTextArea title1;
    private JTextArea title2;
    private JButton searchCategory;
    private JPanel categoryChecker;
    private JFormattedTextField urlCategory;
    private JTextPane textPaneCategory;

    public static void main(String[] args) {
        JFrame frame = new JFrame("DataChecker");
        frame.setContentPane(new DataChecker("crawler").tabedPane);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setResizable(false);
        frame.setVisible(true);
    }

    private CrawlerDataBaseHandler dbHandler = null;
    public DataChecker(){



    }
    public DataChecker(String name) {
        dbHandler = new CrawlerDataBaseHandler(name,0);
        dbHandler.openConnection();
        textPane1.setContentType("text/html");
        textPaneCategory.setContentType("text/html");
        searchButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                 String data = null;
                try{
                    Entity en = dbHandler.getUrlData(CrawlerDataBaseHandler.getURLDataBaseName(formattedTextField2.getText()));
                    data = HTMLRenderer.getHTMLContent(new StringReader(en.get("page_content").toString()));
                    pageTitle.setText(en.get("page_title").toString());
                    lastUpdated.setText(en.get("last_updated").toString());
                    permanentLink.setText(en.get("permanent_link").toString());
                    categories.setText(en.get("page_category1") + ", " + en.get("page_category2") + ", " + en.get("page_category3"));
                }catch (Exception e){
                    pageTitle.setText("");
                    lastUpdated.setText("");
                    permanentLink.setText("");
                    categories.setText("");
                    data = "<html> <head></head> <body> Page Is Not In DataBase! </body> </html>";
                }

                textPane1.setText(data);

            }
        });
        checkSimilarityButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String data = null;
                try{
                    Entity en1 = dbHandler.getUrlData(CrawlerDataBaseHandler.getURLDataBaseName(url1.getText()));
                    Entity en2 = dbHandler.getUrlData(CrawlerDataBaseHandler.getURLDataBaseName(url2.getText()));
                    ContentAnalyzer analyzer = new DefaultContentAnalyzer();
                    List<Shingle> list1 = analyzer.getShingles(en1.get("page_content").toString());
                    List<Shingle> list2 = analyzer.getShingles(en2.get("page_content").toString());
                    float sim = analyzer.getSimilarityRatio(list1,list2);

                    title1.setText(en1.get("page_title").toString());
                    title2.setText(en2.get("page_title").toString());

                    
                    urlPane1.setText(en1.get("page_content").toString());
                    urlPane2.setText(en2.get("page_content").toString());
                    similarityPane.setText(""+sim);

                }catch(Exception e){
                    System.err.println("Error! Error! Error!:D");
                }
            }
        });
        searchCategory.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String data = null;
                String ret = "<html>\n<head></head>\n<body>\n#\n</body>\n</html>";
                try{
                    data = urlCategory.getText();
                    StringBuffer buffer = new StringBuffer("<ul>\n");
                    List<String> similars = dbHandler.getSimilarCategory(CrawlerDataBaseHandler.getURLDataBaseName(urlCategory.getText()));
                    for ( String str: similars)
                        buffer.append("<li> ").append(str).append(" </li><br/><br/>\n");
                    buffer.append("</ul>");
                    textPaneCategory.setText(ret.replace("#",buffer.toString()));
                    
                }catch(Exception e){
                    textPaneCategory.setText(ret.replace("#","No Similar Page based on Category"));
                }
            }
        });

    }


}
