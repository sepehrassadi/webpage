package edu.sharif.mir.crawler.scanner;

import edu.sharif.mir.crawler.url.UrlDataContainer;

import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.parser.ParserDelegator;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

/**
 * User: sepehr
 * Date: 4/24/12
 * Time: 12:04 AM
 */

public class HTMLParser extends HTMLEditorKit.ParserCallback {
    private List<String> urls = new ArrayList<String>();
    
    private boolean readTitle = false;
    
    private String title = null;
    
    private String permanentLink = null;

    private StringBuffer category = new StringBuffer();

    private HTMLParser(){
    }
    
    public void handleStartTag(HTML.Tag t,
                               MutableAttributeSet a, int pos) {

        // The only links we are concerned about are in HREF.
        if ( t == HTML.Tag.TITLE) {
            readTitle = true;
            return;
        }

        if ( t != HTML.Tag.A )
            return;
        if( a.getAttribute(HTML.Attribute.HREF) == null )
             return;
        if ( a.getAttribute(HTML.Attribute.TITLE) != null){

            if ( a.getAttribute(HTML.Attribute.TITLE).equals("Permanent link to this revision of the page"))
                permanentLink = a.getAttribute(HTML.Attribute.HREF).toString();

            if ( a.getAttribute(HTML.Attribute.TITLE).toString().startsWith("Category:") && a.getAttribute(HTML.Attribute.LANG) == null)
                category.append(a.getAttribute(HTML.Attribute.TITLE).toString().split(":")[1]+", ");
        }
        String address = a.getAttribute(HTML.Attribute.HREF).toString();
        urls.add(address);
        
    }
    public void handleText(char[] data,int size){
        if ( readTitle ){
            title = new String(data);
            readTitle = false;
        }
    }
    
    private List<String> getUrlsName(){
        return urls;
    }

    public static List<String> getUrlsOfHTML(Reader reader) {
        try {
            HTMLParser parser = new HTMLParser();
            new ParserDelegator().parse(reader,parser,true);
            return parser.getUrlsName();
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }

    public static UrlDataContainer getDataOfHTML(Reader reader){
        try {
            HTMLParser parser = new HTMLParser();
            new ParserDelegator().parse(reader,parser,true);
            return new UrlDataContainer(parser.getUrlsName(),parser.title,parser.permanentLink,parser.category.toString());
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }
}
