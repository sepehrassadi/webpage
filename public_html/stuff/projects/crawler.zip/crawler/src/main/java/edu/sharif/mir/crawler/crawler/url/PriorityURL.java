package edu.sharif.mir.crawler.crawler.url;

import java.net.URL;

/**
 * Created by IntelliJ IDEA.
 * User: sepehr
 * Date: 4/29/12
 * Time: 10:12 PM
 * To change this template use File | Settings | File Templates.
 */
public interface PriorityURL {
    
    public URL getURL();
    public int getPriority();
}
