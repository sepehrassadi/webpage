package edu.sharif.mir.crawler.scanner;

import java.net.URL;
import java.util.List;

/**
 * @author Mohammad Milad Naseri (m.m.naseri@gmail.com)
 * @since 1.0 (4/22/12, 16:12)
 */
public interface ResourceScanner {

    List<URL> getCandidateUrls();

}
