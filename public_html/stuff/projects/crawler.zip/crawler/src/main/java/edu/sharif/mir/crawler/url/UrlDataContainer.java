package edu.sharif.mir.crawler.url;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sepehr
 * Date: 4/24/12
 * Time: 12:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class UrlDataContainer {

    private List<String> urls;
    private String title;
    private String permanentLink;
    private String category;
    
    public UrlDataContainer(List<String> urls,String title,String permanentLink,String category){
        this.urls = urls;
        this.title = title;
        this.permanentLink = permanentLink;
        this.category = category;
    }

    public List<String> getUrls(){
        return urls;
    }
    
    public String getTitle(){
        return title;
    }

    public String getPermanentLink(){
        return permanentLink;
    }
    
    public String getCategory(){
        return category;
    }
   
}
