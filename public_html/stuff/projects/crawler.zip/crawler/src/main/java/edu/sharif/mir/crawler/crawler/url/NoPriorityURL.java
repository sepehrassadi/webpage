package edu.sharif.mir.crawler.crawler.url;

import java.io.Serializable;
import java.net.URL;

/**
 * Created by IntelliJ IDEA.
 * User: sepehr
 * Date: 4/29/12
 * Time: 10:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class NoPriorityURL implements  PriorityURL,Serializable {

    private final URL url;

    public NoPriorityURL(URL url){
        this.url = url;
    }

    @Override
    public URL getURL() {
        return this.url;
    }

    @Override
    public int getPriority() {
        return 0;
    }
}
