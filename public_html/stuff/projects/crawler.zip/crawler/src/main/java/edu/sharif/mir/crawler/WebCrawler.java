package edu.sharif.mir.crawler;

import java.net.URL;

/**
 * @author Mohammad Milad Naseri (m.m.naseri@gmail.com)
 * @since 1.0 (4/22/12, 16:30)
 */
public interface WebCrawler {

    public void crawl(URL url);

}
