package edu.sharif.mir.crawler.crawler.gui;

import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.parser.ParserDelegator;
import java.io.IOException;
import java.io.Reader;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: sepehr
 * Date: 5/1/12
 * Time: 10:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class HTMLRenderer extends HTMLEditorKit.ParserCallback {
    private StringBuffer buffer = new StringBuffer();
    private StringBuffer useFullData = new StringBuffer().append("<html>\n<head>\n</head>\n<body>\n");
    private int countBad = 0;
    private int middleDiv = 0;
    
    private boolean begin = false;
    private Set<HTML.Tag> useLess = new HashSet<HTML.Tag>();
    
    private HTMLRenderer(){
        useLess.add(HTML.Tag.META);
        useLess.add(HTML.Tag.SCRIPT);
    }
    
    public void handleStartTag(HTML.Tag t,
                               MutableAttributeSet a, int pos) {

        if ( t.equals(HTML.Tag.DIV) && begin)
            middleDiv++;
        if ( t == HTML.Tag.DIV && a.getAttribute(HTML.Attribute.ID) != null && a.getAttribute(HTML.Attribute.ID).equals("bodyContent")){
            begin = true;
        }
        
        
        if ( useLess.contains(t)){
            countBad++;
            return;
        }
        if ( countBad == 0)
            buffer.append("<" + t + " " + a + ">\n");
        if ( begin )
            useFullData.append("<" + t + " " + a + ">\n");
    }
    public void handleSimpleTag(HTML.Tag t, MutableAttributeSet a, int pos){
        if ( useLess.contains(t))
            return;

        if ( begin )
            useFullData.append("<" + t + " " + a + "/>\n");

        buffer.append("<" + t + " " + a + "/>\n");
    }
    public void handleEndTag(HTML.Tag t, int pos){
        if ( begin && t.equals(HTML.Tag.DIV) && middleDiv == 0) {
            begin = false;
            useFullData.append("</body>\n</html>");
        }

        if ( t.equals(HTML.Tag.DIV) && begin)
            middleDiv--;

        if ( countBad == 0)
            buffer.append("</" + t +">\n");

        if ( countBad == 0 && begin)
            useFullData.append("</" + t +">\n");

        if ( useLess.contains(t))
            countBad--;

      }
    public void handleText(char[] data,int size){
        if ( countBad == 0)
            buffer.append(new String(data).replace("\"","\'")+"\n");
        if ( begin && countBad == 0)
            useFullData.append(new String(data).replace("\"","\'")+"\n");

    }
    
    private String getRenderedHTML(){
        return buffer.toString(); 
    }
    private String getContentHTML(){
        return useFullData.toString();
    }
    public static String renderHTML(Reader reader) {
        try {
            HTMLRenderer renderer = new HTMLRenderer();
            new ParserDelegator().parse(reader,renderer,true);
            return renderer.getRenderedHTML();
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }
    public static String getHTMLContent(Reader reader) {
        try {
            HTMLRenderer renderer = new HTMLRenderer();
            new ParserDelegator().parse(reader,renderer,true);
            return renderer.getContentHTML();
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return null;
    }
}
