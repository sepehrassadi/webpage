package Compiler;

public class StackPointer {
	public String toString() {
		return "X";
	}
}
