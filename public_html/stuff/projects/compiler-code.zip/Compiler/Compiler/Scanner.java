package Compiler;

import java.io.*;

/**
 * This is the template of class 'scanner'. You should place your own 'scanner
 * class here and your scanner should match this interface.
 * 
 */

/*
 * This class is based on the DFA designed for the scanner and the notations are
 * used the same in both.
 */

public class Scanner {

	// List of all variables needed for sending to code generator.
	private String currentToken = null;
	private String cv = null;
	private int icv = 0;
	private double rcv = 0.0;
	private boolean inDCL = false;
	private boolean structDCL = false;
	// These two needed for handling the symbolTable. Note that in my compiler
	// symbolTable is passed to scanner via code generator.

	// public Hashtable<String, Descriptor> symbolTable = null ;
	private SymbolTable symbolTable = null;
	private Descriptor stp = null;
	public VariableType varType;

	// List of all variables needed for sending to parser.
	private int lineNumber = 1;

	// List of all variables needed in this class.
	private java.util.Scanner in;
	private String buffer = null;
	private int bufferPointer = 0;
	private char ch;

	// List of all predefined words in language.
	public final static String languageTokens[] = { "boolean", "break",
			"continue", "else", "false", "float", "for", "if", "int","char",
			"readfloat", "readint", "return", "string", "struct", "true",
			"void", "writetext", "writefloat", "writeint" };

	Scanner(String filename) throws Exception {
		File f = new File(filename);
		if (!f.exists())
			throw new Exception("File does not exist: " + f);
		if (!f.isFile())
			throw new Exception("Should not be a directory: " + f);
		if (!f.canRead())
			throw new Exception("Can not read input file: " + f);
		// ...
		in = new java.util.Scanner(f);
		buffer = in.nextLine();
		ch = nextChar();
	}

	public final String printError(int line, String errorType) {
		return String.format("Scanner Error @ line: " + line + " " + errorType);
	}

	public char nextChar() throws Exception {
		if (bufferPointer == -1)// $ should just be printed once, otherwise
								// it is an error that should be handled.
			throw new Exception(printError(getLineNumber(),
					"Expected } at the end of input "));
		if (bufferPointer < buffer.length()) {
			char temp = buffer.charAt(bufferPointer++);
			if (temp == '\n') // here when reading the input we explicitly
								// increase the line number.
				lineNumber++;
			return temp;
		}
		if (in.hasNext()) {
			buffer = in.nextLine();
			bufferPointer = 0;
			lineNumber++; // when reading another buffer the line is increasing
							// again.
			return '\n';
		}
		bufferPointer = -1;
		return '$'; // $ is the character for end of file.
	}

	public String getCV() {
		return cv;
	}

	public int getICV() {
		return icv;
	}

	public double getRCV() {
		return rcv;
	}

	public Descriptor getSTP() {
		return stp;
	}
	public void setSTP(Descriptor stp){
		this.stp = stp;
	}
	public int getLineNumber() {
		return lineNumber;
	}

	public void setSybmolTable(SymbolTable symbolTable) {
		this.symbolTable = symbolTable;
	}

	public void setINDCL(boolean inDCL) {
		this.inDCL = inDCL;
	}

	public void setStructDCL(boolean structDCL) {
		this.structDCL = structDCL;
	}

	private boolean isChar(char ch) { // This is the definition of Sigma.
		return ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || ch == '_');
	}

	private boolean isDigit(char ch) { // This is the definition of Digit.
		return ((ch >= '0' && ch <= '9'));
	}

	private boolean isHexDigit(char ch) { // This is the definition of Hex
											// Digit.
		return (isDigit(ch) || (ch >= 'A' && ch <= 'F') || (ch >= 'a' && ch <= 'f'));
	}

	private int toDigit(char ch) {
		return (int) ch - (int) '0';
	}

	private String typeDeclare(String ret, DescriptorType type)
			throws Exception {
	//	tempDSCP.type = type; // 1 means id at current_time 2 means sturct_id.
		if (symbolTable.setDescriptor(ret, stp)) // case of defined
													// earlier.
			throw new Exception(printError(getLineNumber(),
					"redeclaration of variable " + ret + "."));
		return "id";
	}

	private String stringID(StringBuffer ans) throws Exception {
		while (isChar(ch) || isDigit(ch)) {
			ans.append(ch);
			ch = nextChar();
		}
		String ret = ans.toString();
		// Finding the id in the symbolTable. Strategy based on inDCL variable.
		if (inDCL) { // case of being in middle of declaration.
			return typeDeclare(ret, DescriptorType.SIMPLE_ID); // means id at
																// current_time.
		} else if (structDCL) {
			return typeDeclare(ret, DescriptorType.STRUCT_ID); // means
																// struct_id at
																// current_time.
		} else { // case of not being in middle of declaration.
			stp = symbolTable.getDescriptor(ret);
			if (stp == null) // case of not defined earlier.
				throw new Exception(printError(getLineNumber(), ret
						+ " was not declared in this scope."));
		}
		if (stp.type == DescriptorType.KEYWORD) // means keyword at
												// current_time.
			return ret;
		else if (stp.type == DescriptorType.SIMPLE_ID || stp.type == DescriptorType.ARRAY_ID || stp.type == DescriptorType.METHOD_ID || stp.type == DescriptorType.STRUCT_VARIABLE_ID) // means ~keyword &&
														// ~struct_id at
		// current_time
		{
			cv = ret;
			return "id";
		} else // means struct_id at current_time
		{
			cv = ret;
			return "struct_id";
		}
	}

	public String floatLiteral(StringBuffer ans) throws Exception {
		rcv = icv;
		int power = 1;
		while (isDigit(ch)) {
			ans.append(ch);
			rcv = rcv + toDigit(ch) / Math.pow(10, power++); // RCV is set here.
			ch = nextChar();

		}
		cv = ans.toString();
		return "float_literal";
	}

	public String hexLiteral(StringBuffer ans) throws Exception {
		ch = nextChar();
		ans.deleteCharAt(0);
		while (isHexDigit(ch)) {
			ans.append(ch);
			ch = nextChar();
		}
		cv = ans.toString();
		return "hex_literal";
	}

	public String readToken() throws Exception {
		while (ch == ' ' || ch == '\n' || ch == '\t') {// Jumping over useless
														// characters.
			ch = nextChar();
		}

		StringBuffer ans = new StringBuffer();

		if (isChar(ch)) { // case of String id.
			return stringID(ans);
		}
		if (isDigit(ch)) { // case of Number constant.
			if (ch == '0') { // Hex_literal begin with 0x.
				ans.append(ch);
				ch = nextChar();
				if (ch == 'x') { // case of Hex_literal
					return hexLiteral(ans);
				}
			}
			icv = 0;
			while (isDigit(ch)) { // case of integer constants.
				ans.append(ch);
				icv = icv * 10 + toDigit(ch); // ICV is set here.
				ch = nextChar();
			}
			if (ch == '.') { // case of real constants.
				ans.append(".");
				ch = nextChar();
				return floatLiteral(ans);
			}
			cv = ans.toString();
			return "int_literal";
		}
		if (ch == '.') { // case of real constants.
			ans.append(".");
			ch = nextChar();
			if (isDigit(ch))
				return floatLiteral(ans);
			else
				return ans.toString();
		}
		switch (ch) {
		case '/': // don't forget!! it may serve as division operator too.
			ch = nextChar();
			if (ch == '/') { // case of "//comment\n" => One line comment.
				while (ch != '\n')
					ch = nextChar();
				ch = nextChar();
				return NextToken();
			} else if (ch == '*') { // case of "/*comment*/ => Multiple line
									// comment.
				ch = nextChar();
				while (true) {
					while (ch != '*')
						ch = nextChar();
					ch = nextChar();

					if (ch == '/') {
						ch = nextChar();
						return NextToken();
					}
				}
			}
			return "/";
		case '"': // case of string constant.
			ch = nextChar();
			while (ch != '\"') {
				if (ch == '\\') {
					ch = nextChar();
					ans.append("\\" + ch);
					ch = nextChar();
					continue;
				}
				ans.append(ch);
				ch = nextChar();
			}
			ch = nextChar();
			cv = ans.toString();
			return "string_literal";
		case '\'':// case of character constant.
			ch = nextChar();
			ans.append(ch);
			if (ch == '\\') {
				ch = nextChar();
				ans.append(ch);
			}
			ch = nextChar();
			if (ch == '\'') {
				ch = nextChar();
				cv = ans.toString();
				return "char_literal";
			} else
				throw new Exception(printError(getLineNumber(),
						"expected character " + "'" + " here"));
		case '(':// cases of non-continues-one-character tokens.
		case ')':
		case '{':
		case '}':
		case ';':
		case '+':
		case '*':
		case '%':
		case '-':
		case ',':
		case '[':
			ans.append(ch);
			ch = nextChar();
			return ans.toString();
		case '!': // cases of one-or-two character tokens.
		case '>':
		case '<':
		case '=':
			ans.append(ch);
			ch = nextChar();
			if (ch == '=') {
				ans.append(ch);
				ch = nextChar();
			}
			return ans.toString();
		case ']':
			ans.append(ch);
			ch = nextChar();
			while (ch == ' ' || ch == '\t' || ch == '\n')
				ch = nextChar();
			if (ch == '[') {
				ans.append(ch);
				ch = nextChar();
			}
			return ans.toString();
		case '&': // cases of two-character tokens.
			ch = nextChar();
			if (ch == '&') {
				ch = nextChar();
				return "&&";
			} else
				throw new Exception(printError(getLineNumber(),
						"expected character " + "&" + " here"));
		case '|':
			ch = nextChar();
			if (ch == '|') {
				ch = nextChar();
				return "||";
			} else
				throw new Exception(printError(getLineNumber(),
						"expected character " + "|" + " here"));
		case '$':
			return "$";
		default:
			throw new Exception(printError(getLineNumber(),
					"Undefiend character here: " + ch + "."));
			// return "someToken";

		}
	}

	public String NextToken() {
		// the real work of scanner is in readToken. here this method is for
		// finishing the last parts.
		try {
			currentToken = readToken();
		} catch (Exception e) {
			System.err.println(e.getMessage());
	//		e.printStackTrace();
			System.exit(-1);
		}
		return currentToken;
	}

	public String getCurrentToken() {
		return currentToken;
	}

}
