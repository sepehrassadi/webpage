package Compiler;

import java.util.Scanner;


public class MicroOps 
{
	private static Scanner sc = new Scanner(System.in);
	private static Object threeOpIntInt(String integer1, String integer2, String opCode)
	{
		Integer o1 = Integer.valueOf(integer1);
		Integer o2 = Integer.valueOf(integer2);
		if(opCode == "+")
			return o1 + o2;	
		else if(opCode == "-")
			return o1 - o2;	
		else if(opCode == "*")
			return o1 * o2;	
		else if(opCode == "/")
			return o1 / o2;	
		else if(opCode == "%")
			return o1 % o2;	
		else if(opCode == "&&")
			return o1 & o2;	
		else if(opCode == "||")
			return o1 | o2;	
		else if(opCode == "<")
			return o1 < o2;	
		else if(opCode == ">")
			return o1 > o2;	
		else if(opCode == "<=")
			return o1 <= o2;	
		else if(opCode == ">=")
			return o1 >= o2;	
		else if(opCode == "==")
			return o1 == o2;	
		else if(opCode == "!=")
			return o1 != o2;
		return null;
	}
	private static Object threeOpIntFloat(String integer, String flt, String opCode)
	{
		Integer o1 = Integer.valueOf(integer);
		Float o2 = Float.valueOf(flt);
		if(opCode == "+")
			return o1 + o2;	
		else if(opCode == "-")
			return o1 - o2;	
		else if(opCode == "*")
			return o1 * o2;	
		else if(opCode == "/")
			return o1 / o2;	
		else if(opCode == "%")
			return o1 % o2;	
		else if(opCode == "&&")
			throw new RuntimeException("Operand && is not defined for int and float");	
		else if(opCode == "||")
			throw new RuntimeException("Operand || is not defined for int and float");	
		else if(opCode == "<")
			return o1 < o2;	
		else if(opCode == ">")
			return o1 > o2;	
		else if(opCode == "<=")
			return o1 <= o2;	
		else if(opCode == ">=")
			return o1 >= o2;	
		else if(opCode == "==")
			return Float.valueOf(o1) == o2;	
		else if(opCode == "!=")
			return Float.valueOf(o1) != o2;
		return null;
	}
	private static Object threeOpFloatInt(String flt, String integer, String opCode)
	{
		Float o1 = Float.valueOf(flt);
		Integer o2 = Integer.valueOf(integer);
		if(opCode == "+")
			return o1 + o2;	
		else if(opCode == "-")
			return o1 - o2;	
		else if(opCode == "*")
			return o1 * o2;	
		else if(opCode == "/")
			return o1 / o2;	
		else if(opCode == "%")
			return o1 % o2;	
		else if(opCode == "&&")
			throw new RuntimeException("Operand && is not defined for int and float");	
		else if(opCode == "||")
			throw new RuntimeException("Operand || is not defined for int and float");	
		else if(opCode == "<")
			return o1 < o2;	
		else if(opCode == ">")
			return o1 > o2;	
		else if(opCode == "<=")
			return o1 <= o2;	
		else if(opCode == ">=")
			return o1 >= o2;	
		else if(opCode == "==")
			return Float.valueOf(o2) == o1;	
		else if(opCode == "!=")
			return Float.valueOf(o2) != o1;
		return null;
	}
	private static Object threeOpFloatFloat(String flt1, String flt2, String opCode)
	{
		Float o1 = Float.valueOf(flt1);
		Float o2 = Float.valueOf(flt2);
		if(opCode == "+")
			return o1 + o2;	
		else if(opCode == "-")
			return o1 - o2;	
		else if(opCode == "*")
			return o1 * o2;	
		else if(opCode == "/")
			return o1 / o2;	
		else if(opCode == "%")
			return o1 % o2;	
		else if(opCode == "&&")
			throw new RuntimeException("Operand && is not defined for float and float");	
		else if(opCode == "||")
			throw new RuntimeException("Operand || is not defined for float and float");	
		else if(opCode == "<")
			return o1 < o2;	
		else if(opCode == ">")
			return o1 > o2;	
		else if(opCode == "<=")
			return o1 <= o2;	
		else if(opCode == ">=")
			return o1 >= o2;	
		else if(opCode == "==")
			return o2 == o1;	
		else if(opCode == "!=")
			return o2 != o1;
		return null;
	}
	private static Object threeOpBoolBool(String bool1, String bool2, String opCode)
	{
		Boolean o1 = Boolean.valueOf(bool1);
		Boolean o2 = Boolean.valueOf(bool2);
		if(opCode == "+")
			throw new RuntimeException("Operand && is not defined for float and float");
		else if(opCode == "-")
			throw new RuntimeException("Operand && is not defined for float and float");
		else if(opCode == "*")
			throw new RuntimeException("Operand && is not defined for float and float");
		else if(opCode == "/")
			throw new RuntimeException("Operand && is not defined for float and float");
		else if(opCode == "%")
			throw new RuntimeException("Operand && is not defined for float and float");
		else if(opCode == "&&")
			return o1 && o2;
		else if(opCode == "||")
			return o1 || o2;
		else if(opCode == "<")
			throw new RuntimeException("Operand && is not defined for float and float");	
		else if(opCode == ">")
			throw new RuntimeException("Operand && is not defined for float and float");
		else if(opCode == "<=")
			throw new RuntimeException("Operand && is not defined for float and float");
		else if(opCode == ">=")
			throw new RuntimeException("Operand && is not defined for float and float");
		else if(opCode == "==")
			return o2.equals(o1);
		else if(opCode == "!=")
			return o2.equals(o1);
		return null;
	}
	public static Object threeOperands(Object obj1, Object obj2, Instruction inst)
	{
		String opCode = inst.getInfo().getOpCode();
		String A = obj1.toString();
		String B = obj2.toString();
		switch(inst.getOperands()[0].getType())
		{
		case 'i':
		{
			switch(inst.getOperands()[1].getType())
			{
			case 'i':
				return threeOpIntInt(A, B, opCode);
			case 'f':
				return threeOpIntFloat(A, B, opCode);
			case 'b':
				throw new RuntimeException("Operand " + opCode + " is not defined for int and boolean");	
			case 'c':
			{
				String temp = Integer.valueOf((int)Character.valueOf(B.charAt(0))).toString();
				return threeOpIntInt(A, temp, opCode);
			}
			}
			break;
		}
		case 'f':
		{
			switch(inst.getOperands()[1].getType())
			{
			case 'i':
				return threeOpFloatInt(A, B, opCode);
			case 'f':
				return threeOpFloatFloat(A, B, opCode);
			case 'b':
				throw new RuntimeException("Operand " + opCode + " is not defined for float and boolean");	
			case 'c':
			{
				String temp = Integer.valueOf((int)Character.valueOf(B.charAt(0))).toString();
				return threeOpFloatInt(A, temp, opCode);
			}
			}
			break;
		}
		case 'b':
		{
			switch(inst.getOperands()[1].getType())
			{
			case 'i':
				throw new RuntimeException("Operand " + opCode + " is not defined for boolean and int");	
			case 'f':
				throw new RuntimeException("Operand " + opCode + " is not defined for boolean and float");	
			case 'b':
				return threeOpBoolBool(A, B, opCode);	
			case 'c':
				throw new RuntimeException("Operand " + opCode + " is not defined for boolean and character");	
			}
			break;
		}
		case 'c':
		{
			switch(inst.getOperands()[1].getType())
			{
			case 'i':
			{
				String temp = Integer.valueOf((int)Character.valueOf(A.charAt(0))).toString();
				return threeOpIntInt(temp, B, opCode);
			}
			case 'f':
			{
				String temp = Integer.valueOf((int)Character.valueOf(A.charAt(0))).toString();
				return threeOpIntFloat(temp, B, opCode);
			}
			case 'b':
				throw new RuntimeException("Operand " + opCode + " is not defined for character and boolean");
			case 'c':
			{
				String tempA = Integer.valueOf((int)Character.valueOf(A.charAt(0))).toString();
				String tempB = Integer.valueOf((int)Character.valueOf(B.charAt(0))).toString();
				return Character.valueOf((char)(Integer.valueOf(threeOpIntInt(tempA, tempB, opCode).toString())).intValue());
			}
			}
			break;
		}
		}
		return null;
	}
	public static Object twoOperands(Object operand1, Object operand2, Instruction inst, Register pc) 
	{
		String opCode = inst.getInfo().getOpCode();
		String A = operand1.toString();
		String B = (operand2 == null) ? null : operand2.toString();
		if(opCode == "!")
		{
			switch(inst.getOperands()[0].getType())
			{
			case 'i':
				return ~Integer.valueOf(A).intValue();
			case 'f':
				throw new RuntimeException("Operand " + opCode + " is not defined for float");
			case 'b':
				return !Boolean.valueOf(A).booleanValue();
			case 'c':
				return ~Integer.valueOf((int)Character.valueOf(A.charAt(0)));
			}
		}
		else if(opCode == "u-")
		{
			switch(inst.getOperands()[0].getType())
			{
			case 'i':
				return -Integer.valueOf(A).intValue();
			case 'f':
				return -Float.valueOf(A).floatValue();
			case 'b':
				throw new RuntimeException("Operand " + opCode + " is not defined for boolean");
			case 'c':
				return -Integer.valueOf((int)Character.valueOf(A.charAt(0)));
			}			
		}
		else if(opCode == ":=")
		{
			return operand1;
		}
		else if(opCode == "jz")
		{
			switch(inst.getOperands()[0].getType())
			{
			case 'i':
			{
				if(Integer.valueOf(A).intValue() == 0)
					pc.value = Integer.valueOf(B);
				else
					pc.value = pc.value + 1;
				break;
			}
			case 'f':
			{
				if(Float.valueOf(A).floatValue() == 0)
					pc.value = Integer.valueOf(B);
				else
					pc.value = pc.value + 1;
				break;
			}
			case 'b':
			{
				if(!Boolean.valueOf(A).booleanValue())
					pc.value = Integer.valueOf(B);
				else
					pc.value = pc.value + 1;
				break;
			}
			case 'c':
			{
				if(Integer.valueOf((int)Character.valueOf(A.charAt(0))) == 0)
					pc.value = Integer.valueOf(B);
				else
					pc.value = pc.value + 1;
				break;
			}

			}			
			
		}
		return null;
	}
	public static Object oneOperand(Object operand1, Instruction inst, Register pc, Register sp) 
	{
		String opCode = inst.getInfo().getOpCode();
		String A = (operand1 == null) ? null : operand1.toString();
		if(opCode == "jmp")
		{
			pc.value = Integer.valueOf(A);
			return null;
		}
		else if(opCode == "wi")
		{
			System.out.println(A);
			return null;
		}
		else if(opCode == "wf")
		{
			System.out.println(A);
			return null;
		}
		else if(opCode == "wt")
		{
			System.out.println(A);
			return null;
		}
		else if(opCode == "ri")
		{
			Integer retVal = new Integer(sc.nextInt());
			return retVal;
		}
		else if(opCode == "rf")
		{
			Float retVal = new Float(sc.nextFloat());
			return retVal;
		}
		else if(opCode == ":=pc")
		{
			return new Integer(pc.value.intValue());
		}
		else if(opCode == ":=sp")
		{
			return new Integer(sp.value.intValue());
		}
		else if(opCode == "sp:=")
		{
			sp.value = Integer.valueOf(A);
			return null;
		}
		return null;
	}
}
