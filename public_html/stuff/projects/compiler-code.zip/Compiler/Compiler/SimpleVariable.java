package Compiler;

public class SimpleVariable extends Variable {
	
	public SimpleVariable(){
		
	}
	public SimpleVariable(int address, int size) {
		setAddress(address);
		setSize(size);
	}
	private int address = -1;
	private int size = -1;
	public int getAddress() {
		return address;
	}
	public void setAddress(int address) {
		this.address = address;
	}
	public int getSize() { // based on size.
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	
}
