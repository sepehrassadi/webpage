package Compiler;

public class Memory {
	public byte[] memory;
	public Register sp;
	public Register pc;

	public Memory(int size, Register pc, Register sp) {
		memory = new byte[size];
		this.sp = sp;
		this.pc = pc;
	}

	public byte[] getMemory() {
		return memory;
	}

	private byte[] getByteAFromMemory(int address, String addressMode, int size) {
		int absoluteAddress = getExactAddress(address, addressMode);
		byte[] barray = new byte[size];
		for (int i = 0; i < barray.length; i++)
			barray[i] = memory[absoluteAddress + i];
		return barray;
	}

	private void setByteArrayToMemory(int address, String addressMode,
			byte[] data) {
		int absoluteAddress = getExactAddress(address, addressMode);
		for (int i = 0; i < data.length; i++)
			memory[absoluteAddress + i] = data[i];
	}

	public int getInt(int address, String addressMode) {
		return TypeConvert.byteAToInt(getByteAFromMemory(address, addressMode,
				VM.INT_SIZE));
	}

	public void setInt(int data, int address, String addressMode) {
		setByteArrayToMemory(address, addressMode, TypeConvert.intToByteA(data));
	}

	public float getFloat(int address, String addressMode) {
		return TypeConvert.byteAToFloat(getByteAFromMemory(address,
				addressMode, VM.FLOAT_SIZE));
	}

	public void setFloat(float data, int address, String addressMode) {
		setByteArrayToMemory(address, addressMode,
				TypeConvert.floatToByteA(data));
	}

	public boolean getBoolean(int address, String addressMode) {
		return TypeConvert.byteAToBoolean(getByteAFromMemory(address,
				addressMode, VM.BOOLEAN_SIZE));
	}

	public void setBoolean(boolean data, int address, String addressMode) {
		setByteArrayToMemory(address, addressMode,
				TypeConvert.booleanToByteA(data));
	}

	public char getChar(int address, String addressMode) {
		return TypeConvert.byteAToChar(getByteAFromMemory(address, addressMode,
				VM.CHAR_SIZE));
	}

	public void setChar(char data, int address, String addressMode) {
		setByteArrayToMemory(address, addressMode,
				TypeConvert.charToByteA(data));
	}

	private int getIndirectAddress(int address) {
		int ps = VM.POINTER_SIZE;
		int retVal = 0;
		for (int i = 0; i < ps; i++)
			retVal = (retVal << 8) | (int) memory[address + i];
		return retVal;
	}

	private int getExactAddress(int address, String addressMode) {
		
		if (addressMode.equals(VM.AM_GLOBALDIRECT))
			return address;
		if (addressMode.equals(VM.AM_GLOBALINDIRECT))
			return getIndirectAddress(address+sp.value.intValue());
		if (addressMode.equals(VM.AM_LOCALDIREC))
			return address + sp.value.intValue();
		if (addressMode.equals(VM.AM_LOCALINDIRECT))
			return sp.value.intValue()
					+ getIndirectAddress(address + sp.value.intValue());
		return -1;
	}

	// public static void main(String[] args)
	// {
	// byte[] bytes = new byte[]{0, 0, 96, 64};
	// float f = TypeConvert.byteAToFloat(bytes);
	// System.out.println(f);
	// bytes = TypeConvert.floatToByteA(f);
	// System.out.println(" " + bytes[0] + bytes[1] + bytes[2] + bytes[3]);
	// }

	public Object fetch(MachineOperand operand) {
		int address = -1;
		if (!operand.getAddressMode().equals(VM.AM_IMMEDIATE))
			address = Integer.valueOf(operand.getValue()).intValue();

		switch (operand.getType()) {
		case 'i':
			return (address < 0) ? Integer.valueOf(operand.getValue())
					.intValue() : getInt(address, operand.getAddressMode());
		case 'f':
			return (address < 0) ? Float.valueOf(operand.getValue())
					.floatValue() : this.getFloat(address,
					operand.getAddressMode());
		case 'b':
			try {
				if (address < 0) {
					int temp = Integer.valueOf(operand.getValue());
					return temp != 0;
				}
			} catch (Exception ex) {
			}
			return (address < 0) ? Boolean.valueOf(operand.getValue())
					.booleanValue() : this.getBoolean(address,
					operand.getAddressMode());
		case 'c':
			return (address < 0) ? operand.getValue().charAt(0) : this.getChar(
					address, operand.getAddressMode());
		}
		return null;
	}

	public void callback(Object data, MachineOperand operand) {
		// System.out.println("you should implement callback to wriet " + result
		// + " in " + operand.getValue());
		if (operand.getAddressMode().equals(VM.AM_IMMEDIATE))
			throw new RuntimeException(
					"Your destination address for callback cannot be immediate");
		int address = Integer.valueOf(operand.getValue());
		String addressMode = operand.getAddressMode();
		switch (operand.getType()) {
		case 'i': {
			if (data instanceof Integer)
				this.setInt(((Integer) data).intValue(), address, addressMode);
			else if (data instanceof Float)
				this.setInt(((Float) data).intValue(), address, addressMode);
			else if (data instanceof Boolean)
				this.setInt(((Boolean) data).booleanValue() ? 1 : 0, address,
						operand.getAddressMode());
			else if (data instanceof Character)
				this.setInt((int) ((Character) data).charValue(), address,
						addressMode);
			break;
		}
		case 'f': {
			if (data instanceof Integer)
				this.setFloat(((Integer) data) + 0F, address, addressMode);
			else if (data instanceof Float)
				this.setFloat((Float) data, address, addressMode);
			else if (data instanceof Boolean)
				this.setFloat(((Boolean) data).booleanValue() ? 1F : 0F,
						address, operand.getAddressMode());
			else if (data instanceof Character)
				this.setFloat(((int) ((Character) data).charValue()) + 1F,
						address, addressMode);
			break;
		}
		case 'b': {
			if (data instanceof Integer)
				this.setBoolean(((Integer) data) != 0, address, addressMode);
			else if (data instanceof Float)
				this.setBoolean(((Float) data) != 0F, address, addressMode);
			else if (data instanceof Boolean)
				this.setBoolean((Boolean) data, address,
						operand.getAddressMode());
			else if (data instanceof Character)
				this.setBoolean(((int) ((Character) data).charValue()) != 0,
						address, addressMode);
			break;
		}
		case 'c': {
			if (data instanceof Integer)
				this.setChar((char) (((Integer) data) % 255), address,
						addressMode);
			else if (data instanceof Float)
				this.setChar((char) (((Float) data).intValue() % 255), address,
						addressMode);
			else if (data instanceof Boolean)
				this.setChar(((Boolean) data) ? (char) 1 : (char) 0, address,
						operand.getAddressMode());
			else if (data instanceof Character)
				this.setChar(((Character) data).charValue(), address,
						addressMode);
			break;
		}
		}
	}
}
