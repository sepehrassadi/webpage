package Compiler;

public abstract class Variable {
	public abstract int getAddress();
	public abstract void setAddress(int address);
	public abstract int getSize();
	public abstract void setSize(int size);
	public Variable(int address,int size){
		setAddress(address);
		setSize(size);
	}
	public Variable(){
		
	}
}
