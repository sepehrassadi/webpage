package Compiler;

import java.util.Stack;

public class SymbolTableElement { // This class define the entry of symbol
									// table. contains stack for supporting
									// blocking.
	private Stack<Descriptor> stack = new Stack<Descriptor>(); // each Block may
																// has
																// descriptor in
																// this stack.
	private Stack<Integer> level = new Stack<Integer>(); // define the last
															// level in which
															// the last
															// descriptor is
															// defined.

	public Descriptor getDescriptor() {
		return stack.lastElement();
	}

	public boolean pushDescriptor(Descriptor descriptor, int currLevel) {
		if (!stack.isEmpty() && stack.lastElement().type == DescriptorType.KEYWORD) // overwriting is
																// just for
																// variables not
																// keywords.
			return true;
		if (level.isEmpty() || level.lastElement().intValue() < currLevel) {
			stack.push(descriptor);
			level.push(currLevel);
			return false;
		}
		return true;
	}

	public void popDescriptor(int currLevel) {
		if ( level.isEmpty())
			return;
		if (level.lastElement().intValue() == currLevel) {
			level.pop();
			stack.pop();
		}
	}
	public Descriptor peekDescriptor(int currLevel){
		if ( level.isEmpty())
			return null;
		if ( level.lastElement().intValue() == currLevel)
			return stack.peek();
		else return null;
	}	
	public boolean isEmpty() {
		return stack.isEmpty();
	}

}
