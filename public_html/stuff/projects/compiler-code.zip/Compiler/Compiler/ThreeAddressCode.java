package Compiler;

public class ThreeAddressCode {
	private String operator;
	private Operand operand1,operand2,operand3;
	private int operandCount = 0;
	public ThreeAddressCode(String operator,Operand operand1,Operand operand2,Operand operand3){
		this.operator = operator;
		this.operand1 = operand1;
		this.operand2 = operand2;
		this.operand3 = operand3;
		operandCount = 3;
	}
	public ThreeAddressCode(String operator,Operand operand1,Operand operand2){
		this.operator = operator;
		this.operand1 = operand1;
		this.operand2 = operand2;
		operandCount = 2;
	}
	public ThreeAddressCode(String operator,Operand operand1){
		this.operator = operator;
		this.operand1 = operand1;
		operandCount = 1;
	}
	public void setOperand2Address(String address){
		operand2.address = address;
	}
	public void setOperand1Address(String address){
		operand1.address = address;
	}
	public boolean isJump(){
		return operator.equals("jmp");
	}
	public boolean isJumpZero(){
		return operator.equals("jz");
	}
	public boolean isNop(){
		return operator.equals("nop");
	}
	public boolean isX(){
		return operator.equals("X");
	}
	public String toString(){
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(operator+" ");
		if ( operandCount == 3 )
			return String.format("%s %s %s %s",operator,operand2,operand3,operand1);
		if ( operandCount == 2 )
			return String.format("%s %s %s", operator,operand1,operand2);
		if ( operandCount == 1 )
			return String.format("%s %s", operator,operand1);
		else 
			return operator;
/*		if ( operand2 != null )
		stringBuilder.append(operand2+" ");
		if ( operand3 != null)
			stringBuilder.append(operand3+" ");
		stringBuilder.append(operand1);
*/	//	return String.format("%s %s %s %s", operator,operand1,operand2,operand3);
//		return stringBuilder.toString();
	}
}
