package Compiler;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Date;
import java.util.Scanner;

public class VM {
	public static int MAX_MEM_SIZE = 1000;
	public static int POINTER_SIZE = 4;

	public static int INT_SIZE = 4;
	public static int FLOAT_SIZE = 4;
	public static int BOOLEAN_SIZE = 1;
	public static int STRING_SIZE = -1;
	public static int CHAR_SIZE = 2;

	public static char OPR_INT = 'i';
	public static char OPR_FLOAT = 'f';
	public static char OPR_BOOLEAN = 'b';
	public static char OPR_STRING = 's';
	public static char OPR_CHAR = 'c';

	public static String AM_GLOBALDIRECT = "gd";
	public static String AM_GLOBALINDIRECT = "gi";
	public static String AM_LOCALDIREC = "ld";
	public static String AM_LOCALINDIRECT = "li";
	public static String AM_IMMEDIATE = "im";

	Register pc = null;
	Register sp = null;
	Memory memory = null;
	CodeSegment csegment = null;

	public VM(String[] code) {
		pc = new Register(0);
		sp = new Register(0);
		memory = new Memory(VM.MAX_MEM_SIZE, pc, sp);
		csegment = new CodeSegment(code);
		if (code.length == 0)
			pc = new Register(-1);
	}

	@SuppressWarnings("deprecation")
	public void start() {
		System.out.println("Simulation started at time: "
				+ new Date().toGMTString());
		System.out.println("---------------------------------------------");
		Register temp_debug = new Register(0);
		while (pc.value < csegment.size()) {
			temp_debug.value = pc.value;
		//	System.out.println(pc.value);
			try {
				pc.value = runAnInstruction();
			} catch (Exception ex) {
				throw new RuntimeException(ex.getMessage() + "(in line "
						+ (temp_debug.value + 1) + ")");
			}
		}
		System.out.println("---------------------------------------------");
		System.out.println("Simulation finished at time: "
				+ new Date().toGMTString());
	}

	private Integer runAnInstruction() {
		Instruction inst = csegment.getInstruction(pc);
		String opCode = inst.getInfo().getOpCode();
		MachineOperand[] operands = inst.getOperands(); /*
														 * Description of
														 * operands of current
														 * inst
														 */
		int fCount = inst.getInfo().getOperandsToFetchCount();
		Object[] fOperands = new Object[fCount]; /*
												 * Array of operands that should
												 * be fetched
												 */
		for (int i = 0; i < fCount; i++)
			fOperands[i] = memory.fetch(operands[i]);
		
		if ( inst.getInfo().getOpCode().equals("wt")){ // completely unlawful!
			fCount = 1;
			fOperands = new Object[1];
			fOperands[0] = inst.getOperands()[0].getValue();
		}
		Object result = null;
		if (inst.getInfo().getNumberOfOperands() == 3) {
			result = MicroOps.threeOperands(fOperands[0], fOperands[1], inst);
			memory.callback(result, operands[2]);
			
		} else if (inst.getInfo().getNumberOfOperands() == 2) {
			Object o1 = (fOperands.length > 0) ? fOperands[0] : null;
			Object o2 = (fOperands.length > 1) ? fOperands[1] : null;
			result = MicroOps.twoOperands(o1, o2, inst, pc);
			if (result != null)
				memory.callback(result, operands[1]);
		} else if (inst.getInfo().getNumberOfOperands() == 1) {
			Object o1 = (fOperands.length > 0) ? fOperands[0] : null;
			result = MicroOps.oneOperand(o1, inst, pc, sp);
			if (result != null)
				memory.callback(result, operands[0]);
		} else if (inst.getInfo().getNumberOfOperands() == 0) {
			throw new RuntimeException("This is unimplemented");
		}
		if (inst.getInfo().getPcIncrement())
			return pc.value + 1;
		else
			return pc.value;
	}

	public static void main(String[] args) throws FileNotFoundException {
		String address = Program.DefaultOutputFile;
		
		if ( args.length == 1) {
			address=args[0];
		}
		File f = new File(address);
		Scanner sc = new Scanner(f);
		StringBuilder buffer = new StringBuilder("");
		while (sc.hasNext())
			buffer.append(sc.nextLine() + "\n");
		
		String[] code = buffer.toString().split("\n");
		
		VM vm = new VM(code);
		try {
			vm.start();
		} catch (Exception ex) {
			System.err.println("Simulation Stoped with Error: "
					+ ex.getMessage());
			System.exit(-1);
		}
		// Printing the whole memory in Integer way.
		for (int i = 0; i < VM.MAX_MEM_SIZE; i += 4)
			System.out
					.print(TypeConvert.byteAToInt(new byte[] {
							vm.memory.getMemory()[i],
							vm.memory.getMemory()[i + 1],
							vm.memory.getMemory()[i + 2],
							vm.memory.getMemory()[i + 3] }) + " ");
		System.out.println("==>+"+vm.sp.value);

	}
}
