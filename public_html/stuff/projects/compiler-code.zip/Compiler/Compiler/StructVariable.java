package Compiler;

public class StructVariable extends Variable {
	private int address = -1;
	private int size = -1;
	private StructDescriptor des;
	
	public StructVariable(StructDescriptor des,int address,int size){
		this.des = des;
		setAddress(address);
		setSize(size);
	}
	public SymbolTable getSymbolTable() throws Exception{
		return des.symbolTable;
	}
	public int getAddress() {
		return address;
	}
	public void setAddress(int address) {
		this.address = address;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public String getStructureType(){
		return des.getName();
	}
}
