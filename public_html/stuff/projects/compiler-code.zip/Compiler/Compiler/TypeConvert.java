package Compiler;


public class TypeConvert 
{
	public static int byteAToInt(byte[] data)
	{
		if(data.length != 4)
			throw new RuntimeException("your input data of byte[] should have a length of 4");
		return (int)(
	            (0xff & data[3]) << 0  |
	            (0xff & data[2]) << 8  |
	            (0xff & data[1]) << 16   |
	            (0xff & data[0]) << 24
	            );
	}
	
	public static byte[] intToByteA(int data)
	{
		return new byte[] {
		        (byte)((data >> 24) & 0xff),
		        (byte)((data >> 16) & 0xff),
		        (byte)((data >> 8) & 0xff),
		        (byte)((data >> 0) & 0xff),
		    };
	}
	
	public static float byteAToFloat(byte[] data)
	{
		if(data.length != 4)
			throw new RuntimeException("your input data of byte[] should have a length of 4");
		return Float.intBitsToFloat(byteAToInt(data));
	}
	
	public static byte[] floatToByteA(float data)
	{
		return intToByteA(Float.floatToRawIntBits(data));
	}
	
	public static boolean byteAToBoolean(byte[] data)
	{
		return (data == null || data.length == 0) ? false : data[0] != 0x00;
	}
	
	public static byte[] booleanToByteA(boolean data)
	{
		return new byte[]{(byte)(data ? 0x01 : 0x00)};
	}
	
	public static char byteAToChar(byte[] data)
	{
		if (data == null || data.length != 2) 
			return 0x0;
	    return (char)(
	            (0xff & data[0]) << 8   |
	            (0xff & data[1]) << 0
	            );	
	}
	
	public static byte[] charToByteA(char data)
	{
		return new byte[] {
		        (byte)((data >> 8) & 0xff),
		        (byte)((data >> 0) & 0xff),
		};
	}
	
	public static String byteAToString(byte[] data)
	{
		return (data == null) ? null : new String(data);
	}
	
	public static byte[] stringToByteA(String data)
	{
		return (data == null) ? null : data.getBytes();
	}
}
