package Compiler;


public class Program 
{
	static String DefaultSymbolTablePath = "/Users/sepehr/Desktop/Compiler/temp.npt";
	static String DefaultInputFile = "/Users/sepehr/Desktop/Compiler/test.txt";
    static String DefaultOutputFile = "/Users/sepehr/Desktop/Compiler/out.txt";

	public static void main(String[] args)
	{
		System.out.println("Hello");
		String stPath = DefaultSymbolTablePath, inputPath = DefaultInputFile,
			outputPath = DefaultOutputFile;
		
		String[] symbols = null;
		PTBlock[][] parseTable = null;
		if (/*args.Length != 0 &&*/ args.length != 2)
        {
            System.out.println("Wrong parameters passed.");
            System.out.println("Use the following format:");
            System.out.println("Compiler.exe inputfilename.L outputfilename.Lm");
            //return;
            System.out.println("Using defaults: ");
            System.out.println("Input: " + DefaultInputFile);
            System.out.println("Output: " + DefaultOutputFile);
            System.out.println("ParseTable: " + DefaultSymbolTablePath);
        }
        else
        {
	        inputPath = args[0];
	        outputPath = args[1];
        }
        if (!FileExists(stPath) || !FileExists(inputPath))
        {
        	System.out.println("File not found: " + stPath + " or " + inputPath);
            return;
        }

        try
        {
    		int rowSize, colSize;
    		String[] tmpArr;
    		PTBlock block;
    		
    		try
    		{
    			java.io.FileInputStream fis = new java.io.FileInputStream(new java.io.File(stPath));
    			java.util.Scanner sc = new java.util.Scanner(fis);
    			
    			tmpArr = sc.nextLine().trim().split(" ");
    			rowSize = Integer.parseInt(tmpArr[0]);
    			colSize = Integer.parseInt(tmpArr[1]);
    			String SL = sc.nextLine();
    			// This is the line creates an array of symbols depending on the parse table read.
    			symbols = SL.trim().split(" ");
    			parseTable = new PTBlock[rowSize][colSize];
    			for (int i = 0; i < rowSize; i++)
    			{
    				if (!sc.hasNext())
    					throw new Exception("Invalid .npt file");
    	
    				tmpArr = sc.nextLine().trim().split(" ");
    	
    				//PGen generates some unused rows!
    				if (tmpArr.length == 1)
    				{
    					System.out.println("Anomally in .npt file, skipping one line");
    					continue;
    				}
    	
    				if (tmpArr.length != colSize * 3)
    					throw new Exception("Ivalid line in .npt file");
    					for (int j = 0; j < colSize; j++)
    				{
    					block = new PTBlock();
    					block.setAct(Integer.parseInt((tmpArr[j * 3])));
    					block.setIndex(Integer.parseInt(tmpArr[j * 3 + 1]));
    					block.setSem(tmpArr[j * 3 + 2]);
    					parseTable[i][j] = block;
    				}
    	
    			}
    		}
    		catch (Exception e)
    		{
    			e.printStackTrace();
    		}

        }
        catch (Exception ex)
        {
            System.out.println("Compile Error -> " + ex.getMessage());
            return;
        }

		Parser parser = new Parser(inputPath, symbols, parseTable);

        try
        {
            parser.Parse();
        }
        catch (Exception ex)
        {
            System.out.println("Compile Error -> " + ex.getMessage());
            //return;
        }
        parser.WriteOutput(outputPath);
	}

	static boolean FileExists(String path)
	{
		java.io.File f = new java.io.File(path);
		boolean b = f.exists();
		if (!b)
			System.out.println("ERROR: File not found: {0}" + path);

		return b;
	}


}
