package Compiler;

public class VirtualMachine {
	public static int MAX_MEMORY_SIZE = (1000*1000);
	private Byte memory[] = new Byte[MAX_MEMORY_SIZE];
	
	private int readInt(int address){ // it is little endian.
		String temp = "";
		for ( int i = 0 ; i < 4 ; i++)
			temp+=memory[address+i];
		return Integer.parseInt(temp);
	}
	private void writeInt(int address,int value){
		
	}
	public void run(){
		
	}
}
