package Compiler;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Stack;
import java.util.Map.Entry;

public class CodeGenerator {
	Scanner scanner; // This was my way of informing CG about Constant Values
						// detected by Scanner, you can do whatever you like
	private SymbolTable symbolTable = new SymbolTable();
	// Define any variables needed for code generation

	// Stacks:

	private Stack<Object> semanticStack = new Stack<Object>();
	// This is the stack that need to place nearly everything in it.
	private Stack<Integer> forStack = new Stack<Integer>();
	// These are send to stack as a pack instead of one object.
	private ArrayList<ThreeAddressCode> incompleteLabel = null;
	private ArrayList<ThreeAddressCode> iteratorCode = null;

	private ArrayList<ThreeAddressCode> codeList = new ArrayList<ThreeAddressCode>();

	// Array of code.
	private int address = 4; // address of first empty space. // first global
								// space is reserved!
	private Stack<Integer> memoryAddress = new Stack<Integer>();
	private int tempCount = 0; // address the number of temporary.

	// None Recursive Variable used here.
	private String bufferType = null;
	private VariableType currentVariableType = null;
	private StructDescriptor structDescriptor = null;
	private MethodDescriptor currentMethodDeclare = null;
	// private MethodDescriptor currentMethodCall = null;
	private Descriptor currentDescriptor = null;
	private ArrayList<StructDescriptor> structDefined = new ArrayList<StructDescriptor>();
	private ArrayList<Descriptor> argumentPassed = null;
	private int mainPC = -1;
	private boolean shouldHasReturn = false;
	private boolean hasReturn = false;
	private ArrayList<Integer> returnMain = new ArrayList<Integer>(); 
	// Array
	private int arraySize = 0;
	private static int ERROR_VECTOR = 2;

	private HashMap<String, CodeGeneratorCommand> command = new HashMap<String, CodeGeneratorCommand>();

	public CodeGenerator(Scanner scanner) {
		this.scanner = scanner;
		initializeSymbolTable();
		initializeCode();
		initializeCommands();
	}

	private void initializeCommands() {
		command.put("@typedef", CodeGeneratorCommand.TYPE_DEF);
		command.put("@nextdef", CodeGeneratorCommand.NEXT_DEF);
		command.put("@endTypedef", CodeGeneratorCommand.END_TYPE_DEF);
		command.put("@beginArrayDefine",
				CodeGeneratorCommand.BEGIN_ARRAY_DEFINE);
		command.put("@setUB", CodeGeneratorCommand.SET_UB);
		command.put("@setNext", CodeGeneratorCommand.SET_NEXT);
		command.put("@endArrayDefine", CodeGeneratorCommand.END_ARRAY_DEFINE);
		command.put("@beginArrayCall", CodeGeneratorCommand.BEGIN_ARRAY_CALL);
		command.put("@indexOfArray", CodeGeneratorCommand.INDEX_OF_ARRAY);
		command.put("@nextArrayCall", CodeGeneratorCommand.NEXT_ARRAY_CALL);
		command.put("@endArrayCall", CodeGeneratorCommand.END_ARRAY_CALL);
		command.put("@beginStructSTP", CodeGeneratorCommand.BEGIN_STRUCT_STP);
		command.put("@newST", CodeGeneratorCommand.NEW_ST);
		command.put("@addStructVariable",
				CodeGeneratorCommand.ADD_STRUCT_VARIABLE);
		command.put("@endST", CodeGeneratorCommand.END_ST);
		command.put("@newBlock", CodeGeneratorCommand.NEW_BLOCK);
		command.put("@endBlock", CodeGeneratorCommand.END_BLOCK);
		command.put("@push", CodeGeneratorCommand.PUSH);
		command.put("@pushConstant", CodeGeneratorCommand.PUSH_CONSTANT);
		command.put("@inRecord", CodeGeneratorCommand.IN_RECORD);
		command.put("@pushStruct", CodeGeneratorCommand.PUSH_STRUCT);
		command.put("@pushConditionAddress",
				CodeGeneratorCommand.PUSH_CONDITION_ADDRESS);
		command.put("@newFor", CodeGeneratorCommand.NEW_FOR);
		command.put("@insertX", CodeGeneratorCommand.INSERT_X);
		command.put("@removeX", CodeGeneratorCommand.REMOVE_X);
		command.put("@jumpLoop", CodeGeneratorCommand.JUMP_LOOP);
		command.put("@jumpBreak", CodeGeneratorCommand.JUMP_BREAK);
		command.put("@completeFor", CodeGeneratorCommand.COMPLETE_FOR);
		command.put("@assign", CodeGeneratorCommand.ASSIGN);
		command.put("@or", CodeGeneratorCommand.OR);
		command.put("@and", CodeGeneratorCommand.AND);
		command.put("@equal", CodeGeneratorCommand.EQUAL);
		command.put("@notEqual", CodeGeneratorCommand.NOT_EQUAL);
		command.put("@bigger", CodeGeneratorCommand.BIGGER);
		command.put("@smaller", CodeGeneratorCommand.SMALLER);
		command.put("@biggerEqual", CodeGeneratorCommand.BIGGER_EQUAL);
		command.put("@smallerEqual", CodeGeneratorCommand.SMALLER_EQUAL);
		command.put("@add", CodeGeneratorCommand.ADD);
		command.put("@sub", CodeGeneratorCommand.SUB);
		command.put("@div", CodeGeneratorCommand.DIV);
		command.put("@mul", CodeGeneratorCommand.MUL);
		command.put("@mod", CodeGeneratorCommand.MOD);
		command.put("@not", CodeGeneratorCommand.NOT);
		command.put("@minus", CodeGeneratorCommand.MINUS);
		command.put("@openWriteBufferInt",
				CodeGeneratorCommand.OPEN_WRITE_BUFFER_INT);
		command.put("@openWriteBufferFloat",
				CodeGeneratorCommand.OPEN_WRITE_BUFFER_FLOAT);
		command.put("@openTextBuffer", CodeGeneratorCommand.OPEN_TEXT_BUFFER);
		command.put("@write", CodeGeneratorCommand.WRITE);
		command.put("@assignText", CodeGeneratorCommand.ASSIGN_TEXT);
		command.put("@openReadBufferInt",
				CodeGeneratorCommand.OPEN_READ_BUFFER_INT);
		command.put("@openReadBufferFloat",
				CodeGeneratorCommand.OPEN_READ_BUFFER_FLOAT);
		command.put("@read", CodeGeneratorCommand.READ);
		command.put("@jumpZero", CodeGeneratorCommand.JUMP_ZERO);
		command.put("@completeJZ", CodeGeneratorCommand.COMPLETE_JZ);
		command.put("@jump", CodeGeneratorCommand.JUMP);
		command.put("@completeJump", CodeGeneratorCommand.COMPLETE_JUMP);
		command.put("@newMethod", CodeGeneratorCommand.NEW_METHOD);
		command.put("@setArgName", CodeGeneratorCommand.SET_ARG_NAME);
		command.put("@nextArg", CodeGeneratorCommand.NEXT_ARG);
		command.put("@endMethodDef", CodeGeneratorCommand.END_METHOD_DEF);
		command.put("@assignReturn", CodeGeneratorCommand.ASSIGN_RETURN);
		command.put("@jumpReturnVoid", CodeGeneratorCommand.JUMP_RETURN_VOID);
		command.put("@jumpReturn", CodeGeneratorCommand.JUMP_RETURN);
		command.put("@endMethod", CodeGeneratorCommand.END_METHOD);
		command.put("@methodCall", CodeGeneratorCommand.METHOD_CALL);
		command.put("@nextArgCall", CodeGeneratorCommand.NEXT_ARG_CALL);
		command.put("@assignSet", CodeGeneratorCommand.ASSIGN_SET);
		command.put("@checkFinishJump", CodeGeneratorCommand.CHECK_FINISH_JUMP);
		command.put("@pushMethod", CodeGeneratorCommand.PUSH_METHOD);
		command.put("@pop", CodeGeneratorCommand.POP);
		command.put("NoSem", CodeGeneratorCommand.NO_SEM);
	}

	private void initializeSymbolTable() {
		Descriptor d = new Descriptor();
		for (int i = 0; i < Scanner.languageTokens.length; i++) {
			symbolTable.setDescriptor(Scanner.languageTokens[i], d);
		}
		for (int i = 0; i < structDefined.size(); i++)
			symbolTable.setDescriptor(structDefined.get(i).getName(),
					structDefined.get(i));
		scanner.setSybmolTable(symbolTable);
	}

	private void initializeCode() { // 0.main sp, 1.main pc, 2.array write
									// 3.jump end.
		ThreeAddressCode code = new ThreeAddressCode("sp:=", new Operand("-1",
				"im"));
		codeList.add(code);
		code = new ThreeAddressCode("jmp", getOperand(createJumpDescriptor()));
		codeList.add(code);
		code = new ThreeAddressCode("wt", new Operand(
				"Array Index Out Of Bound", "im", VariableType.STRING));
		codeList.add(code);
		code = new ThreeAddressCode("jmp", getOperand(createJumpDescriptor()));
		codeList.add(code);
		code = new ThreeAddressCode("wt",new Operand("PC has fall end of the method","im",VariableType.STRING));
		codeList.add(code);
		code = new ThreeAddressCode ("jmp",getOperand(createJumpDescriptor()));
		codeList.add(code);
	}

	private void finishCode() {
		ThreeAddressCode code = codeList.get(0); // sp;
		code.setOperand1Address(address + "");
		code = codeList.get(1);
		code.setOperand1Address(mainPC + "");
		code = codeList.get(3);
		code.setOperand1Address(codeList.size() + "");
		code = codeList.get(5);
		code.setOperand1Address(codeList.size()+"");
		for ( int i = 0 ; i < returnMain.size();i++){
			codeList.get(returnMain.get(i)).setOperand1Address(codeList.size()+"");
		}
	}

	private int getSimpleSize(VariableType type) {
		switch (type) {
		case INT:
		case FLOAT:
			return 4;
		case CHAR:
			return 2;
		case BOOLEAN:
			return 1;
		default:
			return 0;
		}
	}

	private VariableType getType(String currentToken) {
		if (currentToken.contains("int"))
			return VariableType.INT;
		else if (currentToken.contains("float"))
			return VariableType.FLOAT;
		else if (currentToken.contains("char"))
			return VariableType.CHAR;
		else if (currentToken.contains("boolean"))
			return VariableType.BOOLEAN;
		else if (currentToken.contains("void"))
			return VariableType.VOID;
		else
			return VariableType.STRUCT_ID;
	}

	public Variable createSimpleVariable(VariableType type) {
		int size = getSimpleSize(type);
		address += size;
		return new SimpleVariable(address - size, size);
	}

	public Variable createStructVariable(Descriptor des) throws Exception {
		if (des.type != DescriptorType.STRUCT_ID)
			throw new Exception(getErrorMsg("Expected a Struct variable"));
		StructDescriptor structDescriptor = (StructDescriptor) des;
		int size = structDescriptor.getSize();
		address += size;
		return new StructVariable((StructDescriptor) structDescriptor.clone(),
				address - size, size);
	}

	private String encodeDescriptor(Descriptor des) {
		String temp = "";
		if (des.isLocal())
			temp += "l";
		else
			temp += "g";
		if (des.isDirect())
			temp += "d";
		else
			temp += "i";
		return temp;
	}

	private Operand getOperand(Descriptor des) { // *change if you want to
													// change address showing
		if (des.type == DescriptorType.CONSTANT)
			return new Operand(des.getName(), "im", des.varType); // * assume
																	// they are
																	// int for
																	// now.
		else if (des.type == DescriptorType.ARRAY_ID)
			return new Operand(des.getVariable().getAddress() + "", "im"); // are
																			// always
																			// int.
		else {

	
			return new Operand(des.getVariable().getAddress() + "",
					encodeDescriptor(des), des.varType);
		}
	}

	private Descriptor getTemp(VariableType type) {
		Descriptor temp = new Descriptor();
		temp.setLocal(); // no Expression is done in global part so every
							// temporary variable is defined locally.
		temp.setVariable(createSimpleVariable(type));
		temp.setName("temp" + ++tempCount);
		temp.varType = type;
		return temp;
	}

	private Descriptor getArrayElement(VariableType type) {
		Descriptor temp = new Descriptor();
		temp.setLocal();
		temp.setVariable(createSimpleVariable(VariableType.INT));
		temp.setName("tempArray" + ++tempCount);
		temp.varType = type;
		return temp;
	}

	private void createTwoOperand(String operator) throws Exception {
		Descriptor right2 = (Descriptor) semanticStack.pop();
		Descriptor right1 = (Descriptor) semanticStack.pop();
		// Error Handler:
		if (right1.varType != right2.varType)
			throw new Exception(getErrorMsg("Operands do not match"));
		// if ( right1.type != DescriptorType.SIMPLE_ID || right2.type !=
		// DescriptorType.SIMPLE_ID)
		// throw new Exception(getErrorMsg("Operation is not defined"));
		Descriptor temp = getTemp(right1.varType);
		ThreeAddressCode code = new ThreeAddressCode(operator,
				getOperand(temp), getOperand(right1), getOperand(right2));
		codeList.add(code);
		semanticStack.push(temp);
	}

	private void createOneOperand(String operator) {
		Descriptor right1 = (Descriptor) semanticStack.pop();
		Descriptor temp = getTemp(right1.varType);
		ThreeAddressCode code = new ThreeAddressCode(operator,
				getOperand(right1), getOperand(temp));
		codeList.add(code);
		semanticStack.push(temp);
	}

	private void createOneOperandStatement(String operator) {
		Descriptor right = (Descriptor) semanticStack.pop();
		ThreeAddressCode code = new ThreeAddressCode(operator,
				getOperand(right));
		codeList.add(code);
	}

	private Descriptor createConstant(String amount) {
		Descriptor des = new Descriptor();
		des.setName(amount);
		des.type = DescriptorType.CONSTANT;
		return des;
	}

	private Descriptor createJumpDescriptor() {

		Descriptor jumpAddress = new Descriptor();
		jumpAddress.type = DescriptorType.CONSTANT;
		jumpAddress.setName("-1");
		return jumpAddress;
	}

	private void writeText(String operator) {
		ThreeAddressCode code = new ThreeAddressCode(operator, new Operand(
				scanner.getCV(), "im", VariableType.STRING));
		codeList.add(code);
	}

	private Descriptor createVariable(Variable var) {
		Descriptor stp = new Descriptor();
		stp.type = DescriptorType.SIMPLE_ID;
		stp.varType = currentVariableType;
		stp.setVariable(var);
		return stp;
	}

	private Descriptor createStructVariableDescriptor(Variable var) {
		Descriptor stp = new Descriptor();
		stp.type = DescriptorType.STRUCT_VARIABLE_ID;
		stp.varType = VariableType.STRUCT_ID;
		stp.setVariable(var);
		return stp;
	}

	private StructDescriptor createStructDescriptor() {
		StructDescriptor stp = new StructDescriptor();
		stp.type = DescriptorType.STRUCT_ID;
		stp.varType = null;
		return stp;
	}

	private void createAssignCode(Descriptor lhs, Descriptor rhs)
			throws Exception {
		if (rhs.varType != lhs.varType)
			throw new Exception(getErrorMsg("Two sides do not match"));
		ThreeAddressCode code = new ThreeAddressCode(":=", getOperand(rhs),
				getOperand(lhs));
		codeList.add(code);
	}

	private void checkIndexOfArray(Descriptor index, int UB) {
		Descriptor temp = getTemp(VariableType.INT);
		ThreeAddressCode code = new ThreeAddressCode(">=", getOperand(temp),
				getOperand(index), getOperand(createConstant("0")));
		codeList.add(code);
		code = new ThreeAddressCode("jz", getOperand(temp),
				getOperand(createConstant(ERROR_VECTOR + "")));
		codeList.add(code);
		code = new ThreeAddressCode("<", getOperand(temp), getOperand(index),
				getOperand(createConstant(UB + "")));
		codeList.add(code);
		code = new ThreeAddressCode("jz", getOperand(temp),
				getOperand(createConstant(ERROR_VECTOR + "")));
		codeList.add(code);
	}

	public void Generate(String sem) {
		try {
			generate(sem);
		} catch (Throwable e) {
			if (e.getMessage() == null)
				System.err.println(getErrorMsg("unknown error"));
			else
				System.err.println(e.getMessage());
		//	e.printStackTrace();
			System.exit(-1);
		}
	}

	private String getErrorMsg(String msg) {
		return String.format("Semantic Error: on token {%s} @ line %d %s",
				scanner.getCurrentToken(), scanner.getLineNumber(), msg);
	}

	@SuppressWarnings("unchecked")
	private void generate(String sem) throws Exception {
		CodeGeneratorCommand command = this.command.get(sem);

		// Definitions and SymbolTable Tasks
		if (command == null || command == CodeGeneratorCommand.NO_SEM)
			return;
		switch (command) {
		case TYPE_DEF: {
			scanner.setINDCL(true);
			// Pass the Symbol Table information needed for creating the type.
			currentVariableType = getType(scanner.getCurrentToken());
			currentDescriptor = scanner.getSTP();
			if (currentDescriptor.type == DescriptorType.STRUCT_ID) {
				scanner.setSTP(createStructVariableDescriptor(createStructVariable(currentDescriptor)));
			} else {
				scanner.setSTP(createVariable(createSimpleVariable(currentVariableType)));
			}
			return;
		}
		case NEXT_DEF: {
			if (currentDescriptor.type == DescriptorType.STRUCT_ID) {
				scanner.setSTP(createStructVariableDescriptor(createStructVariable(currentDescriptor)));
			} else {
				scanner.setSTP(createVariable(createSimpleVariable(currentVariableType)));
			}
			return;

		}
		case END_TYPE_DEF: {
			scanner.setINDCL(false);
			return;

		}
		case BEGIN_ARRAY_DEFINE: {
			Descriptor stp = scanner.getSTP();
			stp.type = DescriptorType.ARRAY_ID;
			address -= getSimpleSize(currentVariableType); // it was added
															// before in typedef
															// and now should be
															// removed.
			stp.setVariable(new ArrayVariable());
			stp.varType = currentVariableType;
			arraySize = 0;
			return;

		}
		case SET_UB: {
			Descriptor stp = scanner.getSTP();
			ArrayVariable var = (ArrayVariable) stp.getVariable();
			var.setUB(scanner.getICV());
			arraySize = (arraySize == 0 ? scanner.getICV() : arraySize
					* scanner.getICV());
			return;

		}
		case SET_NEXT:
			return;
		case END_ARRAY_DEFINE: {
			Descriptor stp = scanner.getSTP();
			ArrayVariable var = (ArrayVariable) stp.getVariable();
			arraySize = arraySize * getSimpleSize(currentVariableType);
			var.setSize(arraySize);
			var.setAddress(address);
			address += (arraySize);
			return;
		}
		case BEGIN_ARRAY_CALL: {
			// Descriptor stp = (Descriptor) semanticStack.pop();
			Descriptor stp = scanner.getSTP();
			Descriptor temp = getTemp(VariableType.INT);
			Descriptor zero = createConstant("0");
			createAssignCode(temp, zero);
			semanticStack.push(0); // counter for iterating on arrays
									// dimensions.
			semanticStack.push(temp);
			semanticStack.push(stp);
			return;
		}
		case INDEX_OF_ARRAY: {
			Descriptor index = (Descriptor) semanticStack.pop();
			if (index.varType != VariableType.INT)
				throw new Exception(
						getErrorMsg("Index must be an integer value"));
			Descriptor stp = (Descriptor) semanticStack.pop();
			Descriptor temp = (Descriptor) semanticStack.pop();

			Integer it = (Integer) semanticStack.pop();
			if (stp.type != DescriptorType.ARRAY_ID)
				throw new Exception(
						getErrorMsg("Token must belong to an array"));

			checkIndexOfArray(index,
					((ArrayVariable) stp.getVariable()).getUB(it));
			Descriptor variableSize = createConstant(getSimpleSize(stp.varType)
					+ "");
			Descriptor temp1 = getTemp(VariableType.INT);
			ThreeAddressCode code = null;
			code = new ThreeAddressCode("*", getOperand(temp1),
					getOperand(index), getOperand(variableSize));
			codeList.add(code);
			code = new ThreeAddressCode("+", getOperand(temp),
					getOperand(temp), getOperand(temp1));
			codeList.add(code);

			semanticStack.push(it++); // number of dimension passed.
			semanticStack.push(temp);
			semanticStack.push(stp);
			return;
		}
		case NEXT_ARRAY_CALL: {
			Descriptor stp = (Descriptor) semanticStack.pop();
			Descriptor temp = (Descriptor) semanticStack.pop();
			int index = (Integer) semanticStack.pop() + 1;
			if (index >= ((ArrayVariable) stp.getVariable()).getDimension())
				throw new Exception(getErrorMsg("Out of Dimension"));

			ArrayVariable variable = (ArrayVariable) stp.getVariable();
			Descriptor constant = createConstant(variable.getUB(index) + "");
			ThreeAddressCode code = new ThreeAddressCode("*", getOperand(temp),
					getOperand(temp), getOperand(constant));
			codeList.add(code);

			semanticStack.push(index);
			semanticStack.push(temp);
			semanticStack.push(stp);
			return;
		}
		case END_ARRAY_CALL: {
			Descriptor stp = (Descriptor) semanticStack.pop();
			Descriptor temp = (Descriptor) semanticStack.pop(); // placed here
																// from
																// beginning.
			int it = (Integer) semanticStack.pop() + 1;
			if (it != ((ArrayVariable) stp.getVariable()).getDimension())
				throw new Exception(getErrorMsg("Lack of Dimension"));
			Descriptor ans = getArrayElement(VariableType.INT);// getArrayElement(stp.varType);
			Descriptor constant = createConstant(stp.getVariable().getAddress()
					+ "");
			ThreeAddressCode code = new ThreeAddressCode("+", getOperand(ans),
					getOperand(temp), getOperand(constant));
			codeList.add(code);
			if (!stp.isLocal())
				ans.setGlobal();
			ans.varType = stp.varType;
			ans.setInDirect(); // it should be indirect after putting on stack
								// not before it!
			semanticStack.push(ans);
			return;
		}
		case BEGIN_STRUCT_STP: {
			scanner.setStructDCL(true);
			structDescriptor = createStructDescriptor();
			scanner.setSTP(structDescriptor);
			return;

		}
		case NEW_ST: {
			scanner.setStructDCL(false);
			semanticStack.push(symbolTable);
			symbolTable = new SymbolTable();
			symbolTable.currLevel++; // for making the variable get local.
			initializeSymbolTable();

			scanner.setSybmolTable(symbolTable);
			memoryAddress.push(address);
			address=0;
			return;
		}
		case ADD_STRUCT_VARIABLE:
			return;
		case END_ST: {
			structDescriptor.symbolTable = (SymbolTable) symbolTable.clone();
			structDescriptor.setSize(address);
			structDefined.add(structDescriptor); // add this one to currently
													// defined structures so
													// they can be used
													// afterward in other
													// structs.

			symbolTable = (SymbolTable) semanticStack.pop();
			scanner.setSybmolTable(symbolTable);
			address = memoryAddress.pop();
			 	// No need to use stack, we don't have recursive
							// structure definition.

			return;
		}
		case NEW_BLOCK: {
			symbolTable.newBlock();
			return;
		}
		case END_BLOCK: {
			symbolTable.endBlock();
			return;
		}
		case PUSH: {
			if (scanner.getSTP().type == DescriptorType.SIMPLE_ID)
				semanticStack.push(scanner.getSTP());
			return;
		}
		case PUSH_CONSTANT: {
			Descriptor des = new Descriptor();
			des.setName(scanner.getCV());
			des.type = DescriptorType.CONSTANT;
			des.varType = getType(scanner.getCurrentToken());
			semanticStack.push(des);
			return;
		}
		case IN_RECORD: {
			Descriptor des = scanner.getSTP();
			semanticStack.push(des);
			// semanticStack.push(des);// (Descriptor) semanticStack.peek();

			if (des.type != DescriptorType.STRUCT_VARIABLE_ID)
				throw new Exception(
						getErrorMsg(" Is not convinient with type other than struct"));
			StructVariable variable = (StructVariable) des.getVariable();
			semanticStack.push(symbolTable);
			symbolTable = variable.getSymbolTable();
			scanner.setSybmolTable(symbolTable);
			return;
		}
		case PUSH_STRUCT: {

			Descriptor des = scanner.getSTP();
			Variable variable = des.getVariable();

			symbolTable = (SymbolTable) semanticStack.pop();
			scanner.setSybmolTable(symbolTable);

			Descriptor structDes = (Descriptor) semanticStack.pop();
			StructVariable structVar = (StructVariable) structDes.getVariable();
			variable.setAddress(variable.getAddress() + structVar.getAddress());
			semanticStack.push(des);
			return;
		}
		case PUSH_CONDITION_ADDRESS: {
			forStack.push(codeList.size());
			return;
		}
		case NEW_FOR: {
			Descriptor condition = (Descriptor) semanticStack.pop();
			Descriptor jumpAddress = createJumpDescriptor();
			ThreeAddressCode code = new ThreeAddressCode("jz",
					getOperand(condition), getOperand(jumpAddress));
			semanticStack.push(incompleteLabel);
			incompleteLabel = new ArrayList<ThreeAddressCode>();
			semanticStack.push(iteratorCode);
			iteratorCode = new ArrayList<ThreeAddressCode>();
			forStack.push(codeList.size()); // instruction.
			codeList.add(code);
			return;
		}
		case INSERT_X: {
			ThreeAddressCode code = new ThreeAddressCode("X", null);
			codeList.add(code);
			return;
		}
		case REMOVE_X: {
			int i = codeList.size() - 1;
			while (!codeList.get(i).isX()) {
				iteratorCode.add(codeList.get(i));
				codeList.remove(i--);
			}
			if (codeList.get(i).isX()) {
				codeList.remove(i);
			}
			return;
		}
		case JUMP_LOOP: {
			int pc2 = forStack.pop();
			int pc1 = forStack.peek();
			forStack.push(pc2);
			Descriptor constant = createConstant(pc1 + "");
			ThreeAddressCode code = new ThreeAddressCode("jmp",
					getOperand(constant));
			codeList.add(code);
			return;
		}
		case JUMP_BREAK: {
			ThreeAddressCode code = new ThreeAddressCode("jmp",
					getOperand(createJumpDescriptor()));
			codeList.add(code);
			incompleteLabel.add(code);
			return;
		}
		case COMPLETE_FOR: {
			for (int i = iteratorCode.size() - 1; i >= 0; i--)
				codeList.add(iteratorCode.get(i));
			int pc2 = forStack.pop();
			int pc1 = forStack.pop();
			ThreeAddressCode code = new ThreeAddressCode("jmp",
					getOperand(createJumpDescriptor()));
			code.setOperand1Address(pc1 + "");
			codeList.add(code);

			code = codeList.get(pc2);
			code.setOperand2Address(codeList.size() + "");

			pc2 = codeList.size();
			for (int i = 0; i < incompleteLabel.size(); i++)
				incompleteLabel.get(i).setOperand1Address(pc2 + "");

			iteratorCode = (ArrayList<ThreeAddressCode>) semanticStack.pop();
			incompleteLabel = (ArrayList<ThreeAddressCode>) semanticStack.pop();
			return;
		}
		case ASSIGN: {
			Descriptor rhs = (Descriptor) semanticStack.pop();
			Descriptor lhs = (Descriptor) semanticStack.pop();
			createAssignCode(lhs, rhs);
			return;
		}
		case OR: {

			createTwoOperand("||");
			return;
		}
		case AND: {
			createTwoOperand("&&");
			return;
		}
		case EQUAL: {
			createTwoOperand("==");
			return;
		}
		case NOT_EQUAL: {
			createTwoOperand("!=");
			return;
		}
		case BIGGER: {

			createTwoOperand(">");
			return;
		}
		case SMALLER: {

			createTwoOperand("<");
			return;
		}
		case BIGGER_EQUAL: {

			createTwoOperand(">=");
			return;
		}
		case SMALLER_EQUAL: {

			createTwoOperand("<=");
			return;
		}
		case ADD: {

			createTwoOperand("+");
			return;
		}
		case SUB: {

			createTwoOperand("-");
			return;
		}
		case DIV: {

			createTwoOperand("/");
			return;
		}
		case MUL: {

			createTwoOperand("*");
			return;
		}
		case MOD: {

			createTwoOperand("%");
			return;
		}
		case NOT: {

			createOneOperand("!");
			return;
		}
		case MINUS: {

			createOneOperand("u-");
			return;
		}
		case OPEN_WRITE_BUFFER_INT: {

			bufferType = "i";
			return;
		}
		case OPEN_WRITE_BUFFER_FLOAT: {
			bufferType = "f";
			return;
		}
		case OPEN_TEXT_BUFFER: {

			bufferType = "t";
			return;
		}
		case WRITE: {

			createOneOperandStatement("w" + bufferType);
			return;
		}
		case ASSIGN_TEXT: {

			writeText("wt");
			return;
		}
		case OPEN_READ_BUFFER_INT: {
			bufferType = "i";
			return;
		}
		case OPEN_READ_BUFFER_FLOAT: {
			bufferType = "f";
			return;
		}
		case READ: {

			createOneOperandStatement("r" + bufferType);
			return;
		}
		case JUMP_ZERO: {
			Descriptor condition = (Descriptor) semanticStack.pop();
			Descriptor jumpAddress = createJumpDescriptor();
			ThreeAddressCode code = new ThreeAddressCode("jz",
					getOperand(condition), getOperand(jumpAddress));

			semanticStack.push(codeList.size()); // Address of incomplete
													// instruction.
			codeList.add(code);
			return;
		}
		case COMPLETE_JZ: {
			int pc = (Integer) semanticStack.pop();
			ThreeAddressCode code = codeList.get(pc);
			ThreeAddressCode nop = new ThreeAddressCode("nop", null);
			if (scanner.getCurrentToken().equals("else"))
				codeList.add(nop);
			code.setOperand2Address(codeList.size() + "");
			return;
		}
		case JUMP: {
			Descriptor jumpAddress = createJumpDescriptor();
			int currentPC = codeList.size();
			ThreeAddressCode code = new ThreeAddressCode("jmp",
					getOperand(jumpAddress));
			codeList.set(currentPC - 1, code); // Address of NOP
			semanticStack.push(currentPC - 1);
			return;
		}
		case COMPLETE_JUMP: {
			int pc = (Integer) semanticStack.pop();
			ThreeAddressCode code = codeList.get(pc);
			code.setOperand1Address(codeList.size() + "");
			return;
		}
		case NEW_METHOD: {
			scanner.setINDCL(false);

			currentMethodDeclare = new MethodDescriptor();
			currentMethodDeclare.setName(scanner.getSTP().getName());
			currentMethodDeclare.setReturnVariable(scanner.getSTP()
					.getVariable());
			currentMethodDeclare.setMethodPC(codeList.size());
			currentMethodDeclare.type = DescriptorType.METHOD_ID;
			currentMethodDeclare.varType = scanner.getSTP().varType;
			shouldHasReturn = currentMethodDeclare.varType != VariableType.VOID;
			symbolTable.changeDescriptor(currentMethodDeclare.getName(),
					currentMethodDeclare);

			symbolTable.newBlock();

			address -= scanner.getSTP().getVariable().getSize(); // was given
																	// before it
																	// is known
																	// as
																	// method.
			scanner.setSTP(currentMethodDeclare);
			memoryAddress.push(address);
			address = 12; // first:sp second:pc is taken before. third:
							// temporary get for sp.
			if (currentMethodDeclare.getName().equals("main")) {
				address = 0; // main doesn't have such things because it cann't
								// be called.
				mainPC = codeList.size();
			}
			return;
		}
		case SET_ARG_NAME: {
			currentMethodDeclare.arguments.add(scanner.getSTP());
			return;

		}
		case NEXT_ARG: {
			scanner.setINDCL(false);
			return;

		}
		case END_METHOD_DEF: {
			scanner.setINDCL(false);
			return;

		}
		case ASSIGN_RETURN:
			return;
		case JUMP_RETURN_VOID: {
			if (currentMethodDeclare.varType != VariableType.VOID) {
				throw new Exception(getErrorMsg("Must Return a value"));
			}
			ThreeAddressCode code = new ThreeAddressCode("jmp", new Operand(
					"4", "ld", VariableType.INT));
			codeList.add(code);
			return;

		}
		case JUMP_RETURN: {
			Descriptor returnValue = (Descriptor) semanticStack.pop();
			if (currentMethodDeclare.varType == VariableType.VOID) {
				throw new Exception(getErrorMsg("Must not Return a value"));
			}
			hasReturn = true;
			if (currentMethodDeclare.getName().equals("main")) {
				ThreeAddressCode code = new ThreeAddressCode("jmp",getOperand(createJumpDescriptor()));
				returnMain.add(codeList.size());
				codeList.add(code);
				return;
			}

			ThreeAddressCode code = new ThreeAddressCode(":=",
					getOperand(returnValue), new Operand("0", "gd",
							currentMethodDeclare.varType));
			codeList.add(code);
			code = new ThreeAddressCode("jmp", new Operand("4", "ld",
					VariableType.INT));
			codeList.add(code);
			return;
		}
		case END_METHOD: {
			currentMethodDeclare.symbolTable = (SymbolTable) symbolTable
					.clone();
			symbolTable.endBlock();
			address = memoryAddress.pop();
			if (hasReturn != shouldHasReturn)
				throw new Exception("This method needs at least on return");
			hasReturn = shouldHasReturn = false;
			// Doing this just to be sure for cases that user forgot to use
			// return in void functions.
			if (currentMethodDeclare.varType == VariableType.VOID) {
				ThreeAddressCode code = new ThreeAddressCode("jmp",
						new Operand("4", "ld", VariableType.INT));
				codeList.add(code);
			}else{ // A good code must never reach here
				ThreeAddressCode code = new ThreeAddressCode("jmp",getOperand(createConstant(4+"")));
				codeList.add(code);
			}
			return;
		}
		case METHOD_CALL: {
			// semanticStack.pop(); // it is a shit!!! waste 2 hours of me!
			semanticStack.push(argumentPassed);
			argumentPassed = new ArrayList<Descriptor>();
			MethodDescriptor currentMethodCall = (MethodDescriptor) scanner
					.getSTP();
			semanticStack.push(currentMethodCall);
			return;

		}
		case NEXT_ARG_CALL: {
			MethodDescriptor currentMethodCall = (MethodDescriptor) semanticStack
					.peek();
			if (argumentPassed.size() >= currentMethodCall.arguments.size())
				throw new Exception(
						getErrorMsg("Too many argument passed to method"));
			return;
		}
		case ASSIGN_SET: {
			Descriptor rhs = (Descriptor) semanticStack.pop();
			Descriptor lhs = getTemp(rhs.varType);
			createAssignCode(lhs, rhs);
			argumentPassed.add(lhs);
			return;
		}
		case CHECK_FINISH_JUMP: {
			MethodDescriptor currentMethodCall = (MethodDescriptor) semanticStack
					.pop();
			if (argumentPassed.size() != currentMethodCall.arguments.size())
				throw new Exception(getErrorMsg("Lack of some argument"));
			// Setting Stack elements.
			Descriptor returnSP = getTemp(VariableType.INT); // first SP.
			ThreeAddressCode code = new ThreeAddressCode(":=sp",
					getOperand(returnSP));
			codeList.add(code);

			Descriptor returnPC = createConstant((codeList.size() + 4 + argumentPassed
					.size()) + "");
			// Second
			// PC.
			Descriptor tempPC = getTemp(VariableType.INT);
			createAssignCode(tempPC, returnPC);
			Descriptor tempSP = getTemp(VariableType.INT);
			code = new ThreeAddressCode("+", getOperand(tempSP),
					getOperand(returnSP),
					getOperand(createConstant((address - 12) + "")));
			codeList.add(code);
			// Setting Arguments:
			for (int i = 0; i < argumentPassed.size(); i++) {
				createAssignCode(getTemp(argumentPassed.get(i).varType),
						argumentPassed.get(i));
			}
			code = new ThreeAddressCode("sp:=", getOperand(tempSP));
			codeList.add(code);

			Descriptor jumpPC = createConstant(currentMethodCall.getMethocPC()
					+ "");
			code = new ThreeAddressCode("jmp", getOperand(jumpPC));
			codeList.add(code);

			code = new ThreeAddressCode("sp:=", new Operand("0", "ld",
					VariableType.INT));
			codeList.add(code);

			argumentPassed = (ArrayList<Descriptor>) semanticStack.pop();
			semanticStack.push(currentMethodCall);
			return;
		}
		case PUSH_METHOD: {
			MethodDescriptor currentMethodCall = (MethodDescriptor) semanticStack
					.pop();
			Descriptor temp = getTemp(currentMethodCall.varType);

			ThreeAddressCode code = new ThreeAddressCode(":=", new Operand("0", // normally
																				// it
																				// is
																				// 8
																				// but
																				// we
																				// get
																				// a
																				// temp
																				// above.
					"gd", currentMethodCall.varType), getOperand(temp));
			codeList.add(code);
			semanticStack.push(temp);
			return;
		}
		case POP: {
			semanticStack.pop();
			return;
		}
		case NO_SEM:
			return;
		default:

		}

	}

	public void FinishCode() // You may need this
	{
		if (mainPC == -1)
			try {
				throw new Exception("Main didn't declared in this program");
			} catch (Exception e) {
				e.printStackTrace();
			}
		finishCode();
	}

	public void WriteOutput(String outputName) {
		// Can be used to print the generated code to output
		// I used this because in the process of compiling, I stored the
		// generated code in a structure
		// If you want, you can output a code line just when it is generated
		// (strongly NOT recommended!!)
		// symbolTable.printBlock();
		File f = new File(outputName);
		FileWriter writer = null;
		StringBuilder builder = new StringBuilder();
		try {
			writer = new FileWriter(f);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (int i = 0; i < codeList.size(); i++)
			builder.append(codeList.get(i) + "\n");
		System.out.println(builder);
		try {
			writer.write(builder.toString());
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
