package Compiler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class SymbolTable {
	private HashMap<String, SymbolTableElement> symbolTable = new HashMap<String, SymbolTableElement>();
	public int currLevel = 0;

	public Descriptor getDescriptor(String name) {
		SymbolTableElement element = symbolTable.get(name);
		if (element == null)
			return null;
		else
			return element.getDescriptor();
	}
	@SuppressWarnings("unchecked")
	protected Object clone() throws CloneNotSupportedException {
		SymbolTable sym = new SymbolTable(); 
		sym.currLevel = currLevel;
		sym.symbolTable = (HashMap<String, SymbolTableElement>) symbolTable.clone();
		return sym;
	}
	public void changeDescriptor(String name,Descriptor descriptor){
		SymbolTableElement element = symbolTable.get(name);
		element.popDescriptor(currLevel);
		element.pushDescriptor(descriptor, currLevel);
	}
	public boolean setDescriptor(String name, Descriptor descriptor) {
		descriptor.setName(name);
		if ( currLevel > 0 )
			descriptor.setLocal();
		
		SymbolTableElement element = symbolTable.get(name);
		if (element == null) { // case the name isn't used before any how.
			element = new SymbolTableElement();
			element.pushDescriptor(descriptor, currLevel);
			symbolTable.put(name, element);
			return false;
		} else
			return element.pushDescriptor(descriptor, currLevel);
		/*
		 * case the name is defined earlier and we just want to check whether it
		 * is defined in this scope or not.
		 */
	}

	public void newBlock() {
		currLevel++;
	}
	public void printBlock(){
		Collection<Entry<String,SymbolTableElement>> set = symbolTable.entrySet();
		Iterator<Entry<String,SymbolTableElement>> iter = set.iterator();
		while (iter.hasNext()) {
			Entry<String,SymbolTableElement> temp = iter.next();
			if ( temp.getValue().getDescriptor().type != DescriptorType.KEYWORD){
				System.out.println(temp.getKey() + " " +  temp.getValue().getDescriptor().type);
		//		System.out.println(temp.getValue().getDescriptor().getVariable().getAddress());
		//		System.out.println(temp.getValue().getDescriptor().getVariable().getSize());
			}
		}
	}
	public ArrayList<Descriptor> getLastLevel(){
		Collection<Entry<String,SymbolTableElement>> set = symbolTable.entrySet();
		Iterator<Entry<String,SymbolTableElement>> iter = set.iterator();
		ArrayList<Descriptor> array = new ArrayList<Descriptor>();
		while (iter.hasNext()) {
			Entry<String,SymbolTableElement> temp = iter.next();
			Descriptor hoy = temp.getValue().peekDescriptor(currLevel);
			System.out.println(hoy.getName());
			if ( hoy != null && hoy.type == DescriptorType.SIMPLE_ID || hoy.type == DescriptorType.STRUCT_VARIABLE_ID)
				array.add(hoy);
		}
		return array;
	}
	public void endBlock() {
		Collection<Entry<String,SymbolTableElement>> set = symbolTable.entrySet();
		Iterator<Entry<String,SymbolTableElement>> iter = set.iterator();
		while (iter.hasNext()) {
			Entry<String,SymbolTableElement> temp = iter.next();
			temp.getValue().popDescriptor(currLevel);
		//	if ( temp.getValue().isEmpty())
			//	symbolTable.remove(temp.getKey());
		}
		currLevel--;
	}
}
