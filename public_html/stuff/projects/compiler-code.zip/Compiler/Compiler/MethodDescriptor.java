package Compiler;

import java.util.ArrayList;

public class MethodDescriptor extends Descriptor{
	private Variable retVariable;
	public SymbolTable symbolTable;
	public ArrayList<Descriptor> arguments = new ArrayList<Descriptor>();
	private int currentPC = 0;
	public int getMethocPC(){
			return currentPC;
	}
	public void setMethodPC(int pc){
		currentPC = pc;
	}
	public Variable getReturnVariable(){
		return retVariable;
	}
	public void setReturnVariable(Variable variable){
		this.retVariable = variable;
	}
	
}
