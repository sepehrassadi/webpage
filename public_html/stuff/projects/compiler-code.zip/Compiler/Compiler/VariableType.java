package Compiler;

public enum VariableType {
	INT,FLOAT,STRING,CHAR,BOOLEAN,STRUCT_ID,VOID,NONE
}
