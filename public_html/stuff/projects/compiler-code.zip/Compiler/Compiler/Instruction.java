package Compiler;

import java.util.ArrayList;


class InstructionInfo
{
	private String operatorName;
	private String opCode;
	private int numberOfOperands;
	private int operandsToFetchCount;
	private boolean pcIncrement;
	public InstructionInfo(String operatorName, String opCode, int numberOfOperands, int operandsToFetchCount, boolean pcIncrement)
	{
		this.operatorName = operatorName;
		this.opCode = opCode;
		this.numberOfOperands = numberOfOperands;
		this.operandsToFetchCount = operandsToFetchCount;
		this.pcIncrement = pcIncrement;
	}
	public String getOperatorName() 
	{
		return operatorName;
	}
	public boolean getPcIncrement()
	{
		return this.pcIncrement;
	}
	public String getOpCode() 
	{
		return opCode;
	}
	public int getNumberOfOperands() 
	{
		return numberOfOperands;
	}
	public int getOperandsToFetchCount() 
	{
		return operandsToFetchCount;
	}
}

class MachineOperand
{
	private String addressMode;
	private char type;
	private String value;
	public MachineOperand(String addressMode, char type, String value) 
	{
		this.addressMode = addressMode;
		this.type = type;
		this.value = value;
	}
	public String getAddressMode() 
	{
		return addressMode;
	}
	public char getType() 
	{
		return type;
	}
	public String getValue() 
	{
		return value;
	}
}
public class Instruction 
{
	public static ArrayList<InstructionInfo> isa = new ArrayList<InstructionInfo>(10);
	
	private InstructionInfo info = null;
	private MachineOperand[] operands = null;
	
	public Instruction(String instruction)
	{
		compile(instruction);
	}

	static 
	{
		isa.add(new InstructionInfo("Add", 					"+"		, 3, 2, true));
		isa.add(new InstructionInfo("Subtract", 			"-"		, 3, 2, true));
		isa.add(new InstructionInfo("Multiply", 			"*"		, 3, 2, true));
		isa.add(new InstructionInfo("Divide", 				"/"		, 3, 2, true));
		isa.add(new InstructionInfo("Mod", 					"%"		, 3, 2, true));
		isa.add(new InstructionInfo("Logical And", 			"&&"	, 3, 2, true));
		isa.add(new InstructionInfo("Logical Or", 			"||"	, 3, 2, true));
		isa.add(new InstructionInfo("Less Than", 			"<"		, 3, 2, true));
		isa.add(new InstructionInfo("Greater Than", 		">"		, 3, 2, true));
		isa.add(new InstructionInfo("Less Than Equal", 		"<="	, 3, 2, true));
		isa.add(new InstructionInfo("Greater Than Equal", 	">="	, 3, 2, true));
		isa.add(new InstructionInfo("Equal", 				"=="	, 3, 2, true));
		isa.add(new InstructionInfo("Not Equal", 			"!="	, 3, 2, true));
		isa.add(new InstructionInfo("Logical Not", 			"!"		, 2, 1, true));
		isa.add(new InstructionInfo("Unary Minus", 			"u-"	, 2, 1, true));
		isa.add(new InstructionInfo("Assignment", 			":="	, 2, 1, true));
		isa.add(new InstructionInfo("Jump Zero", 			"jz"	, 2, 2, false));
		isa.add(new InstructionInfo("Jump", 				"jmp"	, 1, 1, false));
		isa.add(new InstructionInfo("Write Integer", 		"wi"	, 1, 1, true));
		isa.add(new InstructionInfo("Write Float", 			"wf"	, 1, 1, true));
		isa.add(new InstructionInfo("Write Text", 			"wt"	, 1, 0, true));
		isa.add(new InstructionInfo("Read Integer", 		"ri"	, 1, 0, true));
		isa.add(new InstructionInfo("Read Float", 			"rf"	, 1, 0, true));
		isa.add(new InstructionInfo("PC Value", 			":=pc"	, 1, 0, true));
		isa.add(new InstructionInfo("SP Value", 			":=sp"	, 1, 0, true));
		isa.add(new InstructionInfo("Assign SP", 			"sp:="	, 1, 1, true));
		isa.add(new InstructionInfo("Return", 				"ret"	, 0, 0, false)); // It is not needed!
	}

	private void compile(String instruction) 
	{
		String[] inst_parts = instruction.split(" ");
		int l = Instruction.isa.size();
		InstructionInfo temp = null;
		String[] operand_parts;
		for(int i = 0; i < l; i++)
		{
			temp = Instruction.isa.get(i);
		//	System.out.println(temp.getOpCode() + " " + inst_parts[0]);
			if(!temp.getOpCode().equals(inst_parts[0]))
				continue;
	/*		if(temp.getNumberOfOperands() != inst_parts.length - 1)
				throw new RuntimeException("This instruction has incorrect number of operands:\n\t" + instruction);
	*/		this.info = temp;
			if ( this.info.getOpCode().equals("wt")){
				operands = new MachineOperand[1];
				String tempOut = instruction.substring(8);
				operands[0] = new MachineOperand(VM.AM_IMMEDIATE,VM.OPR_STRING, tempOut);
				break;
			}
			operands = new MachineOperand[info.getNumberOfOperands()];
			for(int j = 0; j < info.getNumberOfOperands(); j++)
			{
				operand_parts = inst_parts[j + 1].split("_");
				operands[j] = new MachineOperand(operand_parts[0], operand_parts[1].charAt(0), operand_parts[2]);
			}
			break;
		}
	}

	public InstructionInfo getInfo() 
	{
		return info;
	}

	public MachineOperand[] getOperands() 
	{
		return operands;
	}
}
