package Compiler;

import java.util.ArrayList;

public class ArrayVariable extends Variable{

	private int address = -1;
	private int size = -1;
	private ArrayList<Integer> upperBounds = new ArrayList<Integer>();

	
	public void setUB(int ub){
		upperBounds.add(ub);
	}
	public int getUB(int index){
		return upperBounds.get(index);
	}
	public int getAddress() {
		return address;
	}
	public void setAddress(int address) {
		this.address = address;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public int getDimension(){
		return upperBounds.size();
	}

}
