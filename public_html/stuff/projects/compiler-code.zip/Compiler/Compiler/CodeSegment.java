package Compiler;


public class CodeSegment 
{
	Instruction[] instructions = null;
	public CodeSegment(String[] code)
	{
		Compile(code);
	}

	private void Compile(String[] code) 
	{
		instructions = new Instruction[code.length];
		for(int i = 0; i < code.length; i++)
			instructions[i] = new Instruction(code[i]);
	}
	public Instruction getInstruction(Register pc)
	{
		return instructions[pc.value.intValue()];
	}
	
	public int size()
	{
		return instructions.length;
	}
}
class Register
{
	public Integer value;
	public Register(int value)
	{
		this.value = new Integer(value);
	}
}
