package Compiler;

public class Operand {
	public String address = " ";
	public String addressingMode = " ";
	public String type = "i";
	
	public Operand(String address,String addressingMode,VariableType varType){
		this.address = address;
		this.addressingMode = addressingMode;
		setType(varType);
	}
	public Operand(String address,String addressingMode){
		this.address = address;
		this.addressingMode = addressingMode;
	}
	public void setType(VariableType varType){
		switch (varType){
		case INT:
			type = "i";
			break;
		case FLOAT:
			type = "f";
			break;
		case CHAR:
			type = "c";
			break;
		case BOOLEAN:
			type = "b";
			break;
		case STRING:
			type = "s";
			break;
			default:
		}
	}
	public String toString(){
		return String.format("%s_%s_%s",addressingMode,type,address);
	}
}
