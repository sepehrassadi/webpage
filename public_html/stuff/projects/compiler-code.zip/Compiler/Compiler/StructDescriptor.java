package Compiler;

public class StructDescriptor extends Descriptor {
	
	public SymbolTable symbolTable = null;
	private int size = -1;
	
	public void setSize(int size){
		this.size = size;
	}
	public int getSize(){
		return size;
	}
	public Variable getVariable() {
		return null;
	}

	public void setVariable(Variable variable) {
	}

	public void setLocal() {
	}

	public void setInDirect() {
	}

	public boolean isLocal() {
		return false;
	}

	public boolean isDirect() {
		return false;
	}
	public Object clone() throws CloneNotSupportedException {
		StructDescriptor temp = new StructDescriptor();
		temp.setVariable(getVariable());
		temp.setName(getName());
		temp.type = type;
		temp.varType = varType;
		temp.symbolTable = (SymbolTable) symbolTable.clone();
		return temp;
	}
	
}
