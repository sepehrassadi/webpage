package Compiler;

public class Descriptor {

	public DescriptorType type = DescriptorType.KEYWORD;
	public VariableType varType = VariableType.INT;
	 
	private String name;
	private boolean isLocal = false;
	private boolean isDirect = true;
	private Variable variable = null;
	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public Variable getVariable() {
		return variable;
	}
	
	public void setVariable(Variable variable) {
		this.variable = variable;
	}
	public void setLocal(){
		isLocal = true;
	}
	public void setGlobal(){
		isLocal = false;
	}
	public void setInDirect(){
		isDirect = false;
	}
	public boolean isLocal(){
		return isLocal;
	}
	public boolean isDirect(){
		return isDirect;
	}
	
}
